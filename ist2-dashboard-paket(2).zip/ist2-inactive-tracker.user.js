// ==UserScript==
// @name         IST2 Inactive Picker Tracker v2
// @namespace    http://tampermonkey.net/
// @version      2.45
// @description  IST2 Pick Workforce - inactive takip + FANS mesaj + dashboard + kisi detay + grafik (v2.10: dunku/stale inactive satirlari filtrelenir; v2.11: kisi detayinda haftalik Percent to Goal rate gosterilir; v2.12: 7 gunluk gecmis arsivi + goruntuleyici eklendi)
// @author       Quick
// @match        https://picking-console.eu.picking.aft.a2z.com/fc/IST2/pick-workforce*
// @match        https://picking-console.eu.picking.aft.a2z.com/fc/IST2/*
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @connect      fans-dub.amazon.com
// @connect      internal-cdn.amazon.com
// @connect      badgephotos.corp.amazon.com
// @connect      phonetool.amazon.com
// @connect      api.github.com
// @updateURL    https://raw.githubusercontent.com/ist2ops/dashboard/main/ist2-inactive-tracker.user.js
// @downloadURL  https://raw.githubusercontent.com/ist2ops/dashboard/main/ist2-inactive-tracker.user.js
// @run-at       document-idle
// @noframes
// ==/UserScript==

(function () {
    'use strict';

    // ==================== CONFIG ====================
    const SCAN_INTERVAL_MS = 5 * 60 * 1000; // 5 dakika (v2.29: 2 dk denemesi geri alindi)
    // Bir tarama = kac dakika idle. Tarama araligi degisince otomatik uyar.
    const MIN_PER_SNAP = SCAN_INTERVAL_MS / 60000;
    // Ayni idle blogunun devami sayilmasi icin izin verilen bosluk (1 tarama kacsa da kopmaz)
    const SNAP_GAP_MS = SCAN_INTERVAL_MS * 2 + 30 * 1000;
    const REPORT_INTERVAL_MS = 30 * 60 * 1000; // 30 dakikada bir rapor güncelle
    const INACTIVE_MSG_THRESHOLD_MS = 0; // v2.13: eşik kaldırıldı, inactive görülür görülmez mesaj hazır
    const AUTO_REFRESH_DEFAULT_MS = 60 * 1000; // Varsayılan: 60 sn sayfa yenileme
    // v2.14: 3 vardiya (08-16 / 16-00 / 00-08) otomatik algilanir, sabit SHIFT_START yok
    const SHIFT_BOUNDARY_HOURS = [0, 8, 16]; // her vardiya 8 saat

    // v2.44: her vardiyanin sabit mola saatleri. Vardiya basladiginda bu araliklar
    // otomatik olarak mola listesine eklenir -- elle girmek gerekmez. Anahtar =
    // vardiyanin baslangic saati (SHIFT_BOUNDARY_HOURS ile ayni).
    //   yemek 40 dk, cay 20 dk
    const SHIFT_BREAKS = {
        8:  [['10:30', '11:10'], ['14:05', '14:25']],   // sabah  08:00-16:00
        16: [['19:15', '19:55'], ['22:05', '22:25']],   // aksam  16:00-00:00
        0:  [['03:30', '04:10'], ['06:05', '06:25']]    // gece   00:00-08:00
    };
    function getShiftBounds(refDate) {
        const h = refDate.getHours();
        let startHour = 0;
        for (const b of SHIFT_BOUNDARY_HOURS) {
            if (h >= b) startHour = b;
        }
        const start = new Date(refDate);
        start.setHours(startHour, 0, 0, 0);
        const end = new Date(start);
        end.setHours(start.getHours() + 8, 0, 0, 0);
        return { start, end };
    }
    function fmtHM(d) {
        return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    }
    function shiftLabel(refDate) {
        const b = getShiftBounds(refDate || now());
        return fmtHM(b.start) + ' – ' + fmtHM(b.end);
    }
    const FLOORS = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'HRV'];
    // ⚡ Takip edilecek katlar — sadece bu katlardaki inactive'ler izlenir, mesaj atılır, raporlanır
    const TRACKED_FLOORS = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'HRV'];
    // Bu is tipini (process path) yapan kisiler hic takip edilmez
    const EXCLUDED_PROCESSES = ['PPConsolidationFlowPick1'];
    // Pick bölümü manager'ları — bu listedeki manager'lar "Bizim Ekip",
    // diğerleri "Diğer Bölüm" (Stow, Ship vs.) olarak raporlanır
    const PICK_MANAGERS = ['Turkoglu,Ece'];
    // Diğer bölüm manager'ları (etiket için)
    const MANAGER_LABELS = {
        'Turkoglu,Ece': '🟢 Pick',
        'Susam,Zeynep Dilsad': '🔶 Stow',
        'Beyaz,Firat': '🔶 Ship',
        'Akbuga,Turgut Murat': '🔶 Stow'
    };

    const FANS_SENDER = 'baslmuha';
    const FANS_URL = 'https://fans-dub.amazon.com/'; // From alanı
    const BADGE_PHOTO_URL = 'https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=';
    function badgeImg(login, size = 28) { return `<img src="${BADGE_PHOTO_URL}${login}" style="width:${size}px; height:${size}px; border-radius:50%; object-fit:cover; border:2px solid rgba(255,255,255,0.15); vertical-align:middle;" onerror="this.style.display='none'" />`; }


    // ==================== GITHUB GIST DASHBOARD ====================
    // v2.31: TOKEN ARTIK SCRIPT ICINDE DEGIL.
    // Public repo'ya token'li script konursa GitHub secret scanning onu
    // otomatik iptal ediyor (eski 401 Bad credentials sebebi buydu).
    // Token tarayicida saklanir; panelden "Token" butonuyla bir kez girilir.
    const GIST_TOKEN_KEY = 'itp_gist_token';
    const GIST_ID    = '2c83f09073d462622563534f4ca7cff1';
    const GIST_FILE  = 'ist2_dashboard_data.json';
    let gistSendCount = 0;
    let gistAuthFailed = false;

    function getGistToken() {
        try { return localStorage.getItem(GIST_TOKEN_KEY) || ''; } catch (e) { return ''; }
    }

    function setGistToken(t) {
        try { localStorage.setItem(GIST_TOKEN_KEY, (t || '').trim()); } catch (e) { }
        gistAuthFailed = false;
    }

    function promptGistToken() {
        const cur = getGistToken();
        const masked = cur ? cur.slice(0, 7) + '...' + cur.slice(-4) : '(bos)';
        const t = prompt(
            'GitHub Gist token (sadece "gist" yetkisi yeterli).\n' +
            'Bos birakip OK derseniz mevcut token korunur, "sil" yazarsaniz temizlenir.\n\n' +
            'Mevcut: ' + masked, '');
        if (t === null) return;
        if (t.trim() === '') return;
        if (t.trim().toLowerCase() === 'sil') {
            setGistToken('');
            alert('Token temizlendi. Dashboard gonderimi duracak.');
            return;
        }
        setGistToken(t);
        alert('Token kaydedildi. Bir sonraki taramada dashboard guncellenecek.');
        sendToGist();
    }

    function sendToGist() {
        if (standDown) return; // v2.33: eski kopya dashboard'a yazmasin
        const GIST_TOKEN = getGistToken();
        if (!GIST_TOKEN) {
            console.warn('[Gist] Token yok \u2014 panelden "\ud83d\udd11 Token" ile gir. Gonderim atlandi.');
            return;
        }
        if (gistAuthFailed) {
            console.warn('[Gist] Token gecersiz (401) \u2014 yeni token girilene kadar gonderim duruyor.');
            return;
        }
        const _keys = Object.keys(trackerData);
        if (!_keys.length) {
            console.warn('[Gist] trackerData boş, gönderim iptal.');
            return;
        }

        const floorStatsG = {};
        const mgrStatsG = {};
        const pickersG = [];

        for (const [userId, data] of Object.entries(trackerData)) {
            if (!data) continue;

            let floor = data.currentFloor;
            if (!floor && data.snapshots && data.snapshots.length > 0) {
                var lastSnap = data.snapshots[data.snapshots.length - 1];
                floor = extractFloor(lastSnap.location);
            }
            if (!floor) floor = 'N/A';
            if (!TRACKED_FLOORS.includes(floor)) continue;

            let idle = data.totalIdleMinutes || data.totalInactiveMinutes || data.idleMinutes || 0;
            if (idle <= 0) continue;

            var manager = data.manager || 'N/A';
            var name = data.name || userId;
            var location = data.lastLocation || '';
            if (!location && data.snapshots && data.snapshots.length > 0) {
                location = data.snapshots[data.snapshots.length - 1].location || '';
            }
            var floorChangeCnt = (typeof floorChanges !== 'undefined' && floorChanges[userId]) ? floorChanges[userId].length : 0;

            // ===== SNAPSHOT DETAY HESAPLAMA =====
            var idlePeriods = [];
            var locationStats = {};
            var idleDistribution = {};
            var katChangesArr = [];

            // v2.36: periyotlar gercek Last Activity araliklarindan gelir
            try {
                var hm = function (d) {
                    return new Date(d).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                };
                var perList = computeIdlePeriods(userId);
                for (var pi = 0; pi < perList.length; pi++) {
                    var P = perList[pi];
                    idlePeriods.push({
                        start: hm(P.startTime),
                        end: hm(P.endTime),
                        duration: P.durationMin,
                        ongoing: !!P.ongoing,
                        location: P.location || '',
                        scanTimes: (P.snapTimes || []).map(hm)
                    });
                    var ploc = P.location || 'Bilinmiyor';
                    locationStats[ploc] = (locationStats[ploc] || 0) + P.durationMin;
                    var pd = P.durationMin, bucket;
                    if (pd <= 5) bucket = '5 dk';
                    else if (pd <= 10) bucket = '10 dk';
                    else if (pd <= 15) bucket = '15 dk';
                    else if (pd <= 20) bucket = '20 dk';
                    else if (pd <= 30) bucket = '25-30 dk';
                    else bucket = '30+ dk';
                    idleDistribution[bucket] = (idleDistribution[bucket] || 0) + 1;
                }
            } catch (ePer) { console.warn('[Gist] idlePeriods hata:', ePer); }

            // 4. Kat değişimleri
            if (typeof floorChanges !== 'undefined' && floorChanges[userId] && floorChanges[userId].length > 0) {
                for (var ki = 0; ki < floorChanges[userId].length; ki++) {
                    var fc = floorChanges[userId][ki];
                    var fcTime = fc.time ? new Date(fc.time).toLocaleTimeString('tr-TR', {hour:'2-digit', minute:'2-digit'}) : '';
                    var fcTi = (function () { try { return transitInfo(data, new Date(fc.time).getTime()); } catch (e) { return null; } })();
                    katChangesArr.push({
                        time: fcTime,
                        from: fc.fromFloor || '',
                        to: fc.toFloor || '',
                        fromLoc: fc.fromLocation || '',
                        toLoc: fc.toLocation || '',
                        afterMin: fcTi ? fcTi.minutes : null,
                        stillOpen: fcTi ? !!fcTi.open : null
                    });
                }
            }

            pickersG.push({
                login: userId,
                name: name,
                weeklyRate: (typeof data.weeklyRate === 'number') ? data.weeklyRate : null,
                photo: (function () { try { return photoOf(userId); } catch (e) { return null; } })(),
                floor: floor,
                manager: manager,
                idleMin: idle,
                location: location,
                floorChanges: floorChangeCnt,
                floorIdle: (function () {
                    try {
                        return computeFloorIdle(userId).map(function (f) {
                            return {
                                floor: f.floor,
                                min: f.minutes,
                                ranges: f.ranges.map(function (r) {
                                    return {
                                        start: new Date(r.start).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
                                        end: new Date(r.end).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
                                        min: r.min
                                    };
                                })
                            };
                        });
                    } catch (e) { return []; }
                })(),
                msgSent: !!(typeof messagedUsers !== 'undefined' && messagedUsers[userId]),
                processPath: data.processPath || '',
                idlePeriods: idlePeriods,
                locationStats: locationStats,
                idleDistribution: idleDistribution,
                katChanges: katChangesArr,
                // v2.45: 3D haritanin gercek son okutma zamanini kullanabilmesi icin ham epoch (ms)
                lastActivityMs: (function () {
                    try {
                        if (!data.snapshots || !data.snapshots.length) return 0;
                        var _la = parseLastActivityTime(data.snapshots[data.snapshots.length - 1].lastActivity);
                        return _la ? +_la : 0;
                    } catch (e) { return 0; }
                })()
            });

            if (!floorStatsG[floor]) floorStatsG[floor] = { totalIdleMin: 0, pickerCount: 0 };
            floorStatsG[floor].totalIdleMin += idle;
            floorStatsG[floor].pickerCount++;

            if (!mgrStatsG[manager]) mgrStatsG[manager] = { totalIdleMin: 0, pickerCount: 0 };
            mgrStatsG[manager].totalIdleMin += idle;
            mgrStatsG[manager].pickerCount++;
        }

        pickersG.sort(function(a, b) { return b.idleMin - a.idleMin; });

        var nowG = new Date();
        var payload = {
            lastUpdate: nowG.toISOString(),
            shift: shiftLabel(nowG),
            date: nowG.toLocaleDateString('tr-TR'),
            scanCount: scanCount,
            totalPicker: pickersG.length,
            totalIdleMin: pickersG.reduce(function(s, p) { return s + p.idleMin; }, 0),
            msgSentCount: (typeof messagedUsers !== 'undefined') ? Object.keys(messagedUsers).length : 0,
            stillInactiveCount: (typeof stillInactiveAfterMsg !== 'undefined') ? Object.keys(stillInactiveAfterMsg).length : 0,
            floorStats: floorStatsG,
            pickers: pickersG,
            mgrStats: mgrStatsG,
            // v2.41: dashboard eski bir kopyanin yazdigini gorebilsin
            scriptVersion: (function () { try { return ITP_VERSION; } catch (e) { return '?'; } })(),
            dataSource: (function () { try { return lastRowSource; } catch (e) { return '?'; } })()
        };

        GM_xmlhttpRequest({
            method: 'PATCH',
            url: 'https://api.github.com/gists/' + GIST_ID,
            headers: {
                'Authorization': 'token ' + GIST_TOKEN,
                'Content-Type': 'application/json',
                'Accept': 'application/vnd.github.v3+json'
            },
            data: JSON.stringify({
                files: { 'ist2_dashboard_data.json': { content: JSON.stringify(payload, null, 2) } }
            }),
            onload: function(r) {
                if (r.status === 200) {
                    gistSendCount++;
                    console.log('[Gist] ✅ Dashboard güncellendi (' + gistSendCount + '. gönderim)');
                } else if (r.status === 401 || r.status === 403) {
                    gistAuthFailed = true;
                    console.error('[Gist] \u274c Token gecersiz (' + r.status + '). Panelden "\ud83d\udd11 Token" ile yenisini gir.', r.responseText);
                    addLogEntry('\ud83d\udd11', 'Gist token gecersiz (' + r.status + ') \u2014 yeni token gerekiyor');
                } else {
                    console.error('[Gist] ❌ Hata:', r.status, r.responseText);
                }
            },
            onerror: function(e) { console.error('[Gist] ❌ İstek hatası:', e); }
        });
    }

    // v2.38: gist gonderimi artik arka plan zamanlayicisindan (bgTick) tetiklenir
    console.log('[Gist] 🚀 GitHub Dashboard aktif — https://ist2ops.github.io/dashboard');

    // ==================== STATE ====================
    let trackerData = {};
    let scanCount = 0;
    let scanTimer = null;
    let reportTimer = null;
    let isTracking = false;
    let lastScanTime = null;

    // FANS mesaj takibi
    // messagedUsers[userId] = { sentAt: Date, floor: string, name: string, messageText: string }
    let messagedUsers = {};

    // Mesaj atılmasına rağmen inactive olanlar
    // stillInactiveAfterMsg[userId] = { name, floor, msgSentAt, checkedAt, idleSinceMsg (dk), location }
    let stillInactiveAfterMsg = {};

    // Kat bazlı mesaj gönderme filtresi — hangi katlara mesaj gönderilsin
    let enabledMsgFloors = new Set(TRACKED_FLOORS);

    // Otomatik mesaj gönderme toggle'ı
    let autoMessageEnabled = false;

    // Kat değişimi takibi
    // floorChanges[userId] = [{ time, fromFloor, toFloor, fromLocation, toLocation }]
    let floorChanges = {};

    // Auto-refresh state
    let autoRefreshTimer = null;
    let nextRefreshAt = 0;      // v2.38: duvar saati — sayac degil
    let autoRefreshEnabled = false;
    let autoRefreshIntervalMs = AUTO_REFRESH_DEFAULT_MS;
    let autoRefreshCountdown = 0;
    let countdownTimer = null;

    // ==================== HELPERS ====================
    function now() { return new Date(); }

    function timeStr(d) {
        return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }

    function todayAt(hhmm) {
        const [h, m] = hhmm.split(':').map(Number);
        const d = new Date();
        d.setHours(h, m, 0, 0);
        return d;
    }

    function extractFloor(location) {
        if (!location) return 'N/A';
        const match = location.match(/^P-?(\d)/i);
        if (match) return 'P' + match[1];
        // v2.40: HRV katinin lokasyon/alan kodunda sayili kat prefixi yok
        if (/HRV/i.test(location)) return 'HRV';
        return 'N/A';
    }

    function formatMinutes(mins) {
        if (mins < 60) return mins + ' dk';
        const h = Math.floor(mins / 60);
        const m = mins % 60;
        return h + ' sa ' + m + ' dk';
    }

    // "2026-10-12 13:24 GMT+0300" / "...GMT+03:00" gibi metinleri gercek Date'e cevirir.
    // Site bu kolonda GERCEK son aktivite zamanini veriyor; script'in kendi
    // gozlem suresi (firstInactiveSeen) degil, BU deger esik kontrolu icin kullanilmali.
    function parseLastActivityTime(text) {
        if (!text) return null;
        // v2.40: API ham epoch veriyor (ondalikli SANIYE). Date / number da kabul et.
        if (text instanceof Date) return isNaN(text.getTime()) ? null : text;
        if (typeof text === 'number') {
            if (!isFinite(text) || text <= 0) return null;
            const ms = text > 1e12 ? text : text * 1000;
            const dn = new Date(ms);
            return isNaN(dn.getTime()) ? null : dn;
        }
        const m = String(text).trim().match(
            /(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?\s*GMT\s*([+-]\d{2}):?(\d{2})?/i
        );
        if (!m) return null;
        const [, date, hh, mm, ss, offH, offM] = m;
        const iso = `${date}T${hh.padStart(2, '0')}:${mm}:${ss || '00'}${offH}:${offM || '00'}`;
        const d = new Date(iso);
        return isNaN(d.getTime()) ? null : d;
    }


    // ==================== IDLE MOTORU (v2.36) ====================
    // Idle suresi ARTIK tarama sayisindan hesaplanmiyor.
    // Kaynak: konsol tablosundaki "Last Activity Time" kolonu.
    //   - Kisi Inactive (kirmizi) iken o kolonda SON OKUTMA saati durur.
    //   - Kisi yeniden okutup Active (yesil) olunca o saat guncellenir.
    //   - Iki okutma arasindaki bosluk = GERCEK idle suresi.
    // Bu sayede script 40 dk kapali kalsa bile sure dogru cikar.
    //
    // entry.idleRuns = [{ s, e, open, cutMs, effMin, snaps:[ms], segs:[{floor,loc,from,to}] }]
    //   s    = idle baslangici  (Last Activity Time)
    //   e    = idle bitisi      (yeni okutma saati; hala inactive ise son tarama ani)
    //   open = periyot hala acik mi (kisi henuz okutmadi)

    function overlapMs(a1, a2, b1, b2) {
        return Math.max(0, Math.min(a2, b2) - Math.max(a1, b1));
    }

    // v2.37: Picker'lar vardiyaya sonradan basliyor; o ana kadar "Last Activity
    // Time" DUNDEN kalma bir deger gosteriyor. Boyle bir degeri idle baslangici
    // kabul etmek saatlerce yanlis idle uretiyor. Kural: bu vardiyanin
    // basindan ONCE baslayan periyot hic sayilmaz. Kisi yesile dondugunde
    // Last Activity bugune guncellenir ve sayim o andan itibaren baslar.
    function shiftStartMs(refMs) {
        return getShiftBounds(new Date(refMs || Date.now())).start.getTime();
    }
    function runIsBeforeShift(r) {
        return r && r.s < shiftStartMs(r.e || Date.now());
    }

    function newRun(laMs, scanMs, row) {
        return {
            s: laMs,
            e: Math.max(laMs, scanMs),
            open: true,
            cutMs: 0,
            snaps: [scanMs],
            segs: [{ floor: extractFloor(row.location), loc: row.location || '', from: laMs, to: scanMs }]
        };
    }

    // Eski kayitlari (v2.35 ve oncesi) snapshot'lardan idleRuns'a cevir:
    // ayni "Last Activity Time" degerine sahip ardisik snapshot'lar tek periyottur.
    function ensureIdleRuns(entry) {
        if (!entry) return [];
        if (entry.idleRuns) return entry.idleRuns;
        const runs = [];
        (entry.snapshots || []).forEach(function (sn) {
            if (sn.isFloorChange) return;
            const la = parseLastActivityTime(sn.lastActivity);
            if (!la) return;
            const sMs = la.getTime();
            const tMs = new Date(sn.time).getTime();
            if (sMs < shiftStartMs(tMs)) return;   // dunden / onceki vardiyadan kalma
            const last = runs[runs.length - 1];
            if (last && last.s === sMs) {
                last.e = Math.max(last.e, tMs);
                if (last.snaps[last.snaps.length - 1] !== tMs) last.snaps.push(tMs);
                const sg = last.segs[last.segs.length - 1];
                if (sg && sg.loc === (sn.location || '')) sg.to = Math.max(sg.to, tMs);
                else last.segs.push({ floor: extractFloor(sn.location), loc: sn.location || '', from: tMs, to: tMs });
            } else {
                // yeni okutma gelmis: onceki periyot tam o anda kapanir
                if (last && sMs > last.s) { last.e = Math.max(last.s, sMs); last.open = false; }
                runs.push(newRun(sMs, tMs, sn));
                runs[runs.length - 1].open = false;
            }
        });
        if (runs.length) runs[runs.length - 1].open = true;
        entry.idleRuns = runs;
        return runs;
    }

    // Her taramada her satir icin cagrilir — ACTIVE satirlar da dahil.
    // Active satir onemli: kisi yesile dondugunde acik periyot tam o okutma
    // saatinde kapanir, "son tarama ani" degil.
    function updateIdleRuns(entry, row, scanMs) {
        const runs = ensureIdleRuns(entry);
        const la = parseLastActivityTime(row.lastActivity);
        const laMs = la ? la.getTime() : null;
        let open = runs.length && runs[runs.length - 1].open ? runs[runs.length - 1] : null;

        // Yeni okutma geldi -> acik periyot tam o anda kapanir
        if (open && laMs !== null && laMs > open.s) {
            open.e = Math.max(open.s, laMs);
            open.open = false;
            open = null;
        }

        if (!String(row.status || '').includes('inactive') || laMs === null) return;
        // Vardiya basindan onceki son aktivite -> bu kisi daha ise baslamamis
        if (laMs < shiftStartMs(scanMs)) return;

        if (open && open.s === laMs) {
            open.e = Math.max(open.e, scanMs);
            if (open.snaps[open.snaps.length - 1] !== scanMs) open.snaps.push(scanMs);
            const sg = open.segs[open.segs.length - 1];
            if (sg && sg.loc === (row.location || '')) sg.to = Math.max(sg.to, scanMs);
            else open.segs.push({ floor: extractFloor(row.location), loc: row.location || '', from: scanMs, to: scanMs });
        } else {
            runs.push(newRun(laMs, scanMs, row));
        }
    }


    // ==================== HAFTALIK RATE (Percent to Goal) ====================
    // Individual Scorecard raporundan son 7 gunluk "Percent to Goal" degerini ceker.
    // Ayni-origin oldugu icin GM_xmlhttpRequest/@connect gerekmiyor, duz fetch yeterli
    // (sayfanin kendi oturum cookie'leri credentials:'include' ile otomatik gidiyor).
    const employeeIdCache = {};      // login -> employeeId
    const weeklyRateCache = {};      // 'login|days' -> { value, fetchedAt }
    const RATE_CACHE_TTL_MS = 15 * 60 * 1000; // 15 dk

    async function resolveEmployeeId(login) {
        if (employeeIdCache[login]) return employeeIdCache[login];
        try {
            const resp = await fetch(`/api/fcs/IST2/employee-identity/employee-login/${encodeURIComponent(login)}`, { credentials: 'include' });
            if (!resp.ok) return null;
            const data = await resp.json();
            if (!data || !data.employeeId) return null;
            employeeIdCache[login] = data.employeeId;
            return data.employeeId;
        } catch (e) {
            console.warn('[ITP] employeeId cozumleme hatasi:', login, e);
            return null;
        }
    }

    // v2.27: BUGUNUN (o gunun) Percent to Goal degerini dondurur.
    // v2.21: basarisiz sonuc ARTIK CACHE'LENMIYOR (eskiden bir kez null donunce
    // 15 dk boyunca "bulunamadi" gosteriyordu) + hata sebebi dondurulur.
    // Donus: { value: number|null, reason: string|null }
    // days = 1 -> bugun (tabloda gosterilen), 7 -> haftalik (kisi detayinda)
    async function fetchRateDetailed(login, days) {
        days = days || 1;
        const ck = login + '|' + days;
        const cached = weeklyRateCache[ck];
        if (cached && cached.value !== null && (Date.now() - cached.fetchedAt) < RATE_CACHE_TTL_MS) {
            return { value: cached.value, reason: null };
        }

        let empId = employeeIdCache[login];
        if (!empId) {
            try {
                const r1 = await fetch('/api/fcs/IST2/employee-identity/employee-login/' + encodeURIComponent(login), { credentials: 'include' });
                if (!r1.ok) {
                    console.warn('[ITP] rate: employeeId HTTP', r1.status, login);
                    return { value: null, reason: 'id HTTP ' + r1.status };
                }
                const j1 = await r1.json();
                empId = j1 && (j1.employeeId || (j1.data && j1.data.employeeId));
                if (!empId) {
                    console.warn('[ITP] rate: employeeId cevapta yok', login, j1);
                    return { value: null, reason: 'id yok' };
                }
                employeeIdCache[login] = empId;
            } catch (e) {
                console.warn('[ITP] rate: employeeId istegi hatasi', login, e);
                return { value: null, reason: 'id hatasi' };
            }
        }

        // v2.28: days=1 -> bugun 00:00; days=7 -> 7 gun once 00:00
        const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
        dayStart.setDate(dayStart.getDate() - (days - 1));
        const toSec = Math.floor(Date.now() / 1000);
        const fromSec = Math.floor(dayStart.getTime() / 1000);
        const url = '/api/fcs/IST2/reports/individual-scorecard/picker/' + empId +
            '/pickprocess/Rollup/destination/Rollup/pickarea/Rollup/granularity/day/from/' + fromSec + '/to/' + toSec;
        try {
            const r2 = await fetch(url, { credentials: 'include' });
            if (!r2.ok) {
                console.warn('[ITP] rate: scorecard HTTP', r2.status, login);
                return { value: null, reason: 'HTTP ' + r2.status };
            }
            const j2 = await r2.json();
            const fsd = j2 && j2.scorecardData && j2.scorecardData.fullScorecardData;
            let pct = fsd ? fsd.percentToGoal : null;

            // Yedek 1: string gelmis olabilir
            if (typeof pct === 'string' && pct.trim() !== '') pct = Number(pct);

            // Yedek 2: rollup bos ise gunluk vektorden hesapla
            if (typeof pct !== 'number' || isNaN(pct)) {
                const vec = j2 && j2.scorecardData && j2.scorecardData.fullScorecardDataVector;
                if (Array.isArray(vec) && vec.length > 0) {
                    let sumAct = 0, sumExp = 0;
                    vec.forEach(function (d) {
                        if (typeof d.actualPickDuration === 'number') sumAct += d.actualPickDuration;
                        if (typeof d.expectedPickDuration === 'number') sumExp += d.expectedPickDuration;
                    });
                    if (sumAct > 0) pct = (sumExp / sumAct) * 100;
                }
            }

            if (typeof pct !== 'number' || isNaN(pct)) {
                console.warn('[ITP] rate: percentToGoal bulunamadi', login, j2);
                return { value: null, reason: 'veri yok' };
            }

            const value = Math.round(pct);
            weeklyRateCache[ck] = { value: value, fetchedAt: Date.now() };
            return { value: value, reason: null };
        } catch (e) {
            console.warn('[ITP] rate: scorecard istegi hatasi', login, e);
            return { value: null, reason: 'istek hatasi' };
        }
    }

    // v2.23: Takip edilen kisilerin haftalik rate'ini arka planda doldurur.
    // Deger entry.weeklyRate'e yazilir; modal onu dogrudan basar (async DOM
    // yarisi olmaz) ve dashboard paketine de bu alan gider.
    let rateRefreshRunning = false;

    async function refreshWeeklyRates(force) {
        if (rateRefreshRunning) return;
        rateRefreshRunning = true;
        try {
            const todo = Object.keys(trackerData).filter(function (login) {
                const entry = trackerData[login];
                if (!entry) return false;
                const fresh = entry.weeklyRateAt && (Date.now() - entry.weeklyRateAt) < RATE_CACHE_TTL_MS;
                return force || !fresh || typeof entry.weeklyRate !== 'number';
            });
            let updated = 0;
            const CONCURRENCY = 5; // konsolu bogmamak icin 5'li paralel
            let cursor = 0;
            async function worker() {
                while (cursor < todo.length) {
                    const login = todo[cursor++];
                    const entry = trackerData[login];
                    if (!entry) continue;
                    const r = await fetchDayRateDetailed(login);
                    entry.weeklyRateAt = Date.now();
                    if (r.value !== null && r.value !== undefined) {
                        entry.weeklyRate = r.value;
                        entry.weeklyRateReason = null;
                        updated++;
                    } else {
                        entry.weeklyRateReason = r.reason || 'bilinmiyor';
                    }
                }
            }
            await Promise.all(Array.from({ length: Math.min(CONCURRENCY, todo.length) }, worker));
            if (updated > 0) {
                saveStateToStorage();
                console.log('[ITP] haftalik rate guncellendi: ' + updated + ' kisi');
            }
        } catch (e) {
            console.warn('[ITP] rate yenileme hatasi:', e);
        } finally {
            rateRefreshRunning = false;
        }
    }


    // ==================== v2.27: GUNLUK RATE SERISI ====================
    // Kisi detayinda "gun gun" rate gostermek icin son 7 gunun vektorunu getirir.
    const dailyRateCache = {}; // login -> { days:[{date,pct,actual,expected}], fetchedAt }

    // v2.32: vektordeki tarih alani guvenilmez oldugu icin (hepsi ayni gune
    // dusuyordu) her gun AYRI sorgulanir. Tarih bizim gonderdigimiz araliktan
    // geldigi icin %100 dogru. Tek kisi icin 7 paralel istek, modal acilisinda.
    async function getEmployeeId(login) {
        if (employeeIdCache[login]) return employeeIdCache[login];
        try {
            const r = await fetch('/api/fcs/IST2/employee-identity/employee-login/' + encodeURIComponent(login), { credentials: 'include' });
            if (!r.ok) return null;
            const j = await r.json();
            const id = j && (j.employeeId || (j.data && j.data.employeeId));
            if (id) employeeIdCache[login] = id;
            return id || null;
        } catch (e) { return null; }
    }

    async function fetchRateForDay(empId, dayStart) {
        const from = Math.floor(dayStart.getTime() / 1000);
        const dayEnd = new Date(dayStart.getTime());
        dayEnd.setHours(23, 59, 59, 0);
        const to = Math.floor(Math.min(dayEnd.getTime(), Date.now()) / 1000);
        if (to <= from) return null;
        const url = '/api/fcs/IST2/reports/individual-scorecard/picker/' + empId +
            '/pickprocess/Rollup/destination/Rollup/pickarea/Rollup/granularity/day/from/' + from + '/to/' + to;
        try {
            const r = await fetch(url, { credentials: 'include' });
            if (!r.ok) return null;
            const j = await r.json();
            const sc = j && j.scorecardData;
            const fsd = sc && sc.fullScorecardData;
            let pct = fsd ? fsd.percentToGoal : null;
            if (typeof pct === 'string' && pct.trim() !== '') pct = Number(pct);
            let act = fsd ? (fsd.actualPickDuration || 0) : 0;
            let exp = fsd ? (fsd.expectedPickDuration || 0) : 0;
            if ((typeof pct !== 'number' || isNaN(pct)) && act > 0) pct = (exp / act) * 100;
            if (typeof pct !== 'number' || isNaN(pct)) return null;
            return { pct: Math.round(pct), actual: act, expected: exp };
        } catch (e) { return null; }
    }

    async function fetchDailyRateSeries(login, days) {
        days = days || 7;
        const c = dailyRateCache[login];
        if (c && c.n === days && (Date.now() - c.fetchedAt) < RATE_CACHE_TTL_MS) return c.days;

        const empId = await getEmployeeId(login);
        if (!empId) return [];

        // Eskiden -> yeniye dogru gun listesi
        const list = [];
        for (let k = days - 1; k >= 0; k--) {
            const d = new Date();
            d.setHours(0, 0, 0, 0);
            d.setDate(d.getDate() - k);
            list.push(d);
        }

        const results = await Promise.all(list.map(function (d) {
            return fetchRateForDay(empId, d).then(function (r) {
                return {
                    dateObj: d,
                    date: d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }),
                    dayName: d.toLocaleDateString('tr-TR', { weekday: 'short' }),
                    pct: r ? r.pct : null,
                    actual: r ? r.actual : 0,
                    expected: r ? r.expected : 0
                };
            });
        }));

        const out = results.filter(function (x) { return x.pct !== null; });
        dailyRateCache[login] = { days: out, n: days, fetchedAt: Date.now() };
        return out;
    }

    // ==================== v2.27: ROZET FOTOGRAFI ====================
    // Dashboard github.io'dan acildigi icin kurum ici foto URL'si <img> ile
    // yuklenemez (cookie gitmez). Bu yuzden foto burada (yetkili sayfada)
    // cekilip 64px JPEG data-URL'e cevrilir ve gist paketine gomulur.
    const PHOTO_STORAGE_KEY = 'itp_badge_photos_v1';
    const PHOTO_TTL_MS = 7 * 24 * 60 * 60 * 1000;
    let badgePhotos = {}; // login -> { data, at }
    try { badgePhotos = JSON.parse(localStorage.getItem(PHOTO_STORAGE_KEY) || '{}') || {}; } catch (e) { badgePhotos = {}; }

    function savePhotos() {
        try { localStorage.setItem(PHOTO_STORAGE_KEY, JSON.stringify(badgePhotos)); } catch (e) { }
    }

    const PHOTO_URLS = [
        function (l) { return 'https://badgephotos.corp.amazon.com/?uid=' + encodeURIComponent(l); },
        function (l) { return 'https://badgephotos.corp.amazon.com/' + encodeURIComponent(l) + '?' + encodeURIComponent(l); },
        function (l) { return 'https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=' + encodeURIComponent(l); }
    ];
    let photoUrlIdx = 0; // ilk calisan varyant bulununca sabitlenir

    function gmGetBlob(url) {
        return new Promise(function (resolve) {
            if (typeof GM_xmlhttpRequest !== 'function') { resolve(null); return; }
            GM_xmlhttpRequest({
                method: 'GET', url: url, responseType: 'blob', timeout: 15000,
                onload: function (r) {
                    if (r.status >= 200 && r.status < 300 && r.response && r.response.size > 400) resolve(r.response);
                    else resolve(null);
                },
                onerror: function () { resolve(null); },
                ontimeout: function () { resolve(null); }
            });
        });
    }

    function blobToSmallDataURL(blob, px) {
        return new Promise(function (resolve) {
            const url = URL.createObjectURL(blob);
            const img = new Image();
            img.onload = function () {
                try {
                    const cv = document.createElement('canvas');
                    cv.width = px; cv.height = px;
                    const ctx = cv.getContext('2d');
                    const side = Math.min(img.width, img.height);
                    ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, px, px);
                    resolve(cv.toDataURL('image/jpeg', 0.7));
                } catch (e) { resolve(null); }
                URL.revokeObjectURL(url);
            };
            img.onerror = function () { resolve(null); URL.revokeObjectURL(url); };
            img.src = url;
        });
    }

    async function fetchBadgePhoto(login) {
        const hit = badgePhotos[login];
        if (hit && hit.data && (Date.now() - hit.at) < PHOTO_TTL_MS) return hit.data;

        const order = [photoUrlIdx].concat(PHOTO_URLS.map(function (_, i) { return i; }));
        for (let k = 0; k < order.length; k++) {
            const i = order[k];
            const blob = await gmGetBlob(PHOTO_URLS[i](login));
            if (!blob) continue;
            const data = await blobToSmallDataURL(blob, 64);
            if (!data || data.length < 200) continue;
            photoUrlIdx = i;
            badgePhotos[login] = { data: data, at: Date.now() };
            savePhotos();
            return data;
        }
        badgePhotos[login] = { data: null, at: Date.now() };
        savePhotos();
        return null;
    }

    let photoRefreshRunning = false;
    async function refreshBadgePhotos(limit) {
        if (photoRefreshRunning) return;
        photoRefreshRunning = true;
        try {
            const todo = Object.keys(trackerData)
                .sort(function (a, b) {
                    return (trackerData[b].totalInactiveMinutes || 0) - (trackerData[a].totalInactiveMinutes || 0);
                })
                .filter(function (l) {
                    const h = badgePhotos[l];
                    return !(h && (Date.now() - h.at) < PHOTO_TTL_MS);
                })
                .slice(0, limit || 30);
            let cursor = 0, got = 0;
            async function w() {
                while (cursor < todo.length) {
                    const l = todo[cursor++];
                    const d = await fetchBadgePhoto(l);
                    if (d) got++;
                }
            }
            await Promise.all(Array.from({ length: Math.min(4, todo.length) }, w));
            if (todo.length) console.log('[ITP] rozet foto: ' + got + '/' + todo.length + ' alindi (varyant #' + photoUrlIdx + ')');
        } catch (e) {
            console.warn('[ITP] foto yenileme hatasi:', e);
        } finally {
            photoRefreshRunning = false;
        }
    }

    function photoOf(login) {
        const h = badgePhotos[login];
        return (h && h.data) ? h.data : null;
    }

    // Tabloda/dashboard'da gosterilen: BUGUNUN rate'i
    function fetchDayRateDetailed(login) { return fetchRateDetailed(login, 1); }
    // Kisi detayinda gosterilen: HAFTALIK rate
    function fetchWeekRateDetailed(login) { return fetchRateDetailed(login, 7); }
    // Geriye uyumluluk
    function fetchWeeklyRateDetailed(login) { return fetchRateDetailed(login, 1); }
    async function fetchWeeklyRate(login) {
        const r = await fetchRateDetailed(login, 1);
        return r.value;
    }

    // v2.20: Haftalik rate teshisi — konsolda ITP_RATE_DEBUG('login') calistir
    async function itpRateDebug(login) {
        console.log('%c[ITP RATE] === ' + login + ' ===', 'color:#ff9800;font-weight:bold');

        const idUrl = '/api/fcs/IST2/employee-identity/employee-login/' + encodeURIComponent(login);
        console.log('[ITP RATE] 1) employeeId istegi:', idUrl);
        let empId = null;
        try {
            const r1 = await fetch(idUrl, { credentials: 'include' });
            console.log('[ITP RATE]    HTTP', r1.status, r1.statusText, '| content-type:', r1.headers.get('content-type'));
            const t1 = await r1.text();
            console.log('[ITP RATE]    ham cevap (ilk 600 krkt):', t1.slice(0, 600));
            try {
                const j1 = JSON.parse(t1);
                console.log('[ITP RATE]    parse edilmis:', j1);
                empId = j1 && (j1.employeeId || (j1.data && j1.data.employeeId));
                console.log('[ITP RATE]    bulunan employeeId:', empId);
            } catch (pe) { console.warn('[ITP RATE]    JSON parse edilemedi:', pe.message); }
        } catch (e) { console.error('[ITP RATE]    istek hatasi:', e); }

        if (!empId) { console.warn('[ITP RATE] employeeId alinamadi, scorecard istegi atlaniyor.'); return; }

        // v2.27: "o gunun" rate'i -> bugun 00:00'dan simdiye
        const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
        const toSec = Math.floor(Date.now() / 1000);
        const fromSec = Math.floor(dayStart.getTime() / 1000);
        const variants = [
            { label: 'saniye (sec)', from: fromSec, to: toSec },
            { label: 'milisaniye (ms)', from: fromSec * 1000, to: toSec * 1000 }
        ];

        for (const v of variants) {
            const url = '/api/fcs/IST2/reports/individual-scorecard/picker/' + empId +
                '/pickprocess/Rollup/destination/Rollup/pickarea/Rollup/granularity/day/from/' + v.from + '/to/' + v.to;
            console.log('[ITP RATE] 2) scorecard istegi [' + v.label + ']:', url);
            try {
                const r2 = await fetch(url, { credentials: 'include' });
                console.log('[ITP RATE]    HTTP', r2.status, r2.statusText);
                const t2 = await r2.text();
                console.log('[ITP RATE]    ham cevap (ilk 1500 krkt):', t2.slice(0, 1500));
                try {
                    const j2 = JSON.parse(t2);
                    console.log('[ITP RATE]    parse edilmis obje:', j2);
                    console.log('[ITP RATE]    ust seviye anahtarlar:', Object.keys(j2 || {}));
                    const sd = j2 && j2.scorecardData;
                    console.log('[ITP RATE]    scorecardData var mi:', !!sd, sd ? Object.keys(sd) : '-');
                    const fsd = sd && sd.fullScorecardData;
                    console.log('[ITP RATE]    fullScorecardData var mi:', !!fsd, fsd ? Object.keys(fsd) : '-');
                    if (fsd) console.log('[ITP RATE]    percentToGoal =', fsd.percentToGoal, '(tip:', typeof fsd.percentToGoal + ')');
                } catch (pe) { console.warn('[ITP RATE]    JSON parse edilemedi:', pe.message); }
            } catch (e) { console.error('[ITP RATE]    istek hatasi:', e); }
        }
        console.log('%c[ITP RATE] === bitti ===', 'color:#ff9800;font-weight:bold');
    }

    // v2.24: Tablolarda haftalik rate hucresi (entry.weeklyRate'ten)
    function rateCellHTML(userId) {
        const e = trackerData[userId];
        const r = e ? e.weeklyRate : null;
        if (typeof r !== 'number') {
            const why = e && e.weeklyRateReason ? e.weeklyRateReason : 'bekleniyor';
            return '<span style="color:#666;" title="' + why + '">-</span>';
        }
        return '<span style="color:' + rateColor(r) + ';font-weight:700;">' + r + '%</span>';
    }

    function rateColor(pct) {
        if (pct === null || pct === undefined) return '#888';
        if (pct >= 100) return '#4caf50';
        if (pct >= 85) return '#ff9800';
        return '#f44336';
    }


    // ==================== IDLE PERIOD & DAILY SUMMARY ====================
    // Snapshot verilerinden idle periyotlarini hesaplar (kanitlar icin)
    // ==================== v2.17: MOLA SAATLERI (geri alinabilir) ====================
    // Mola saatleri vardiyadan vardiyaya degisiyor, otomatik tahmin edilemez.
    // Yonetici panelden mola araliklarini girer. Veri SILINMEZ: snapshot'lar
    // yerinde kalir, toplamlar mola araliklari haric tutularak yeniden
    // hesaplanir. Boylece yanlis girilen bir mola silinince toplam geri gelir.
    let breakWindows = []; // [{ start: Date, end: Date }]
    // v2.43: kat degisimi sonrasi yurume/transit suresi -- kisi basina DEGIL,
    // her kat degisimi olayi basina bagislanir. 0 = kapali (hicbir sey dusulmez).
    let floorChangeForgiveMin = 0;
    // v2.44: hangi vardiya icin otomatik mola yuklendi (vardiya baslangic ms).
    // Kullanici otomatik eklenen bir molayi silerse, ayni vardiya icinde geri gelmez.
    let autoBreakSeededFor = null;

    function isInBreakWindow(t) {
        const ms = t instanceof Date ? t.getTime() : Number(t);
        return breakWindows.some(function (w) {
            return ms >= w.start.getTime() && ms <= w.end.getTime();
        });
    }

    function isBreakFor(entry, t) {
        const ms = t instanceof Date ? t.getTime() : Number(t);
        if (isInBreakWindow(ms)) return true;
        const pb = entry && entry.personalBreaks;
        if (!pb || pb.length === 0) return false;
        return pb.some(function (w) {
            return ms >= new Date(w.start).getTime() && ms <= new Date(w.end).getTime();
        });
    }

    // v2.19: Mola affi kurali
    // Mola saatleri panelden manuel girilir (1 veya 2 aralik). Bir aralik
    // icinde kisinin BUYUK ve KESINTISIZ bir inactive blogu varsa (>= esik)
    // o blok mola kabul edilip idle toplamindan dusulur. Aralik icinde sadece
    // dagink 5-10 dk'lik ufak idle varsa bu mola degildir, DOKUNULMAZ.
    // v2.37: 0 = sinir yok / esik yok. Mola araligina denk gelen TUM idle dusulur.
    // Eski 40/20 degerleri sessizce "mola dusmedi" sonucu veriyordu.
    let maxBreakMinutesPerPerson = 0;    // kisi basi gunluk af ust siniri (0 = sinirsiz)
    let minBreakBlockMinutes = 0;        // mola sayilmasi icin gereken kesintisiz sure (0 = esik yok)

    function isInPersonalBreak(entry, ms) {
        const pb = entry && entry.personalBreaks;
        if (!pb || pb.length === 0) return false;
        return pb.some(function (w) {
            return ms >= new Date(w.start).getTime() && ms <= new Date(w.end).getTime();
        });
    }

    // Verilen indeks listesini kesintisiz bloklara ayir (tarama araligi 5 dk,
    // 7 dk'ya kadar bosluk ayni blok sayilir)
    function splitIntoRuns(snaps, indices) {
        const runs = [];
        let cur = [];
        for (let k = 0; k < indices.length; k++) {
            const i = indices[k];
            if (cur.length === 0) { cur = [i]; continue; }
            const prev = cur[cur.length - 1];
            const gap = snaps[i].time.getTime() - snaps[prev].time.getTime();
            if (gap <= SNAP_GAP_MS) cur.push(i);
            else { runs.push(cur); cur = [i]; }
        }
        if (cur.length > 0) runs.push(cur);
        return runs;
    }

    // Bir kisinin toplamlarini snapshot'lardan yeniden hesapla.
    // Manuel (kisiye ozel) isaretler tam dusulur; mola araliklarindan ise
    // sadece esigi gecen en uzun kesintisiz blok dusulur.
    function recomputeEntryTotals(entry) {
        if (!entry) return;
        let runs = ensureIdleRuns(entry);

        // v2.37: bu vardiyadan once baslayan periyotlari tamamen at
        const before = runs.length;
        runs = runs.filter(function (r) { return !runIsBeforeShift(r); });
        if (runs.length !== before) entry.idleRuns = runs;

        // 1) Kisiye ozel (manuel) mola isaretleri: kesisen sure tam dusulur
        let personalMs = 0;
        runs.forEach(function (r) {
            const span = Math.max(0, r.e - r.s);
            let c = 0;
            (entry.personalBreaks || []).forEach(function (w) {
                c += overlapMs(r.s, r.e, new Date(w.start).getTime(), new Date(w.end).getTime());
            });
            r.cutMs = Math.min(span, c);
            personalMs += r.cutMs;
        });

        // 2) Ekip molasi: bir periyot mola araligiyla minBreakBlockMinutes'tan
        // UZUN kesisiyorsa mola kabul edilir. Kisa/dagink idle'a dokunulmaz.
        // maxBreakMinutesPerPerson = 0 -> sinirsiz, minBreakBlockMinutes = 0 -> esik yok
        const capped = maxBreakMinutesPerPerson > 0;
        let remainingMs = capped ? Math.max(0, maxBreakMinutesPerPerson * 60000 - personalMs) : Infinity;
        breakWindows.forEach(function (w) {
            if (remainingMs <= 0) return;
            const ws = w.start.getTime(), we = w.end.getTime();
            runs.forEach(function (r) {
                if (remainingMs <= 0) return;
                const ov = overlapMs(r.s, r.e, ws, we);
                if (ov <= 0) return;
                if (minBreakBlockMinutes > 0 && ov < minBreakBlockMinutes * 60000) return;
                const room = Math.max(0, (r.e - r.s) - r.cutMs);
                const take = Math.min(ov, room, remainingMs);
                r.cutMs += take;
                if (capped) remainingMs -= take;
            });
        });

        // 3) Kat degisimi sonrasi yurume/transit payi (v2.43). Her kat degisimi
        // olayinin KENDI anindan, en fazla floorChangeForgiveMin kadar -- ve sadece
        // o olayin icinde dustugu periyodun kalan payi kadar -- dusulur. Kapali
        // (0) ise hicbir sey degismez; eski scriptlerle ayni davranis.
        let fcForgivenMs = 0;
        if (floorChangeForgiveMin > 0 && entry.floorChangeTimes && entry.floorChangeTimes.length) {
            entry.floorChangeTimes.forEach(function (chMs) {
                const r = runs.find(function (rr) { return chMs >= rr.s && chMs <= rr.e; });
                if (!r) return;
                const room = Math.max(0, (r.e - r.s) - r.cutMs);
                const windowMs = Math.min(floorChangeForgiveMin * 60000, Math.max(0, r.e - chMs));
                const take = Math.min(windowMs, room);
                if (take <= 0) return;
                r.cutMs += take;
                fcForgivenMs += take;
            });
        }
        entry.floorChangeMinutes = Math.round(fcForgivenMs / 60000);

        // 4) Toplam + lokasyon dagilimi (segment sureleri oraninda)
        let mins = 0;
        const locs = {};
        runs.forEach(function (r) {
            const span = Math.max(0, r.e - r.s);
            r.effMin = Math.round(Math.max(0, span - (r.cutMs || 0)) / 60000);
            mins += r.effMin;
            if (r.effMin <= 0) return;
            const segTot = r.segs.reduce(function (a, g) { return a + Math.max(0, g.to - g.from); }, 0);
            r.segs.forEach(function (g) {
                const share = segTot > 0 ? Math.max(0, g.to - g.from) / segTot : 1 / r.segs.length;
                const loc = g.loc || 'Bilinmiyor';
                locs[loc] = (locs[loc] || 0) + Math.round(r.effMin * share);
            });
        });

        entry.totalInactiveMinutes = mins;
        entry.locationCounts = locs;
        entry.breakForgivenMinutes = Math.round(runs.reduce(function (a, r) { return a + (r.cutMs || 0); }, 0) / 60000);
        entry.breakExcludedTimes = [];
    }

    function recomputeAllTotals() {
        Object.values(trackerData).forEach(recomputeEntryTotals);
    }

    // v2.44: icinde bulundugun vardiyanin sabit molalarini otomatik ekler.
    // Ayni vardiyada bir kez calisir; elle silinen mola geri gelmez.
    // force = true ise (panelden "vardiya molalarini yukle") tekrar ekler.
    function seedShiftBreaks(force) {
        const b = getShiftBounds(now());
        const key = b.start.getHours();
        const plan = SHIFT_BREAKS[key];
        if (!plan) return 0;
        if (!force && autoBreakSeededFor === b.start.getTime()) return 0;

        let added = 0;
        plan.forEach(function (pair) {
            const sp = pair[0].split(':'), ep = pair[1].split(':');
            const st = new Date(b.start); st.setHours(Number(sp[0]), Number(sp[1]), 0, 0);
            const en = new Date(b.start); en.setHours(Number(ep[0]), Number(ep[1]), 0, 0);
            // Ayni aralik zaten varsa (elle veya daha once otomatik) tekrar eklemeyiz
            const dup = breakWindows.some(function (w) {
                return w.start.getTime() === st.getTime() && w.end.getTime() === en.getTime();
            });
            if (dup) return;
            breakWindows.push({ start: st, end: en, auto: true });
            added++;
        });

        autoBreakSeededFor = b.start.getTime();
        if (added > 0) {
            breakWindows.sort(function (a, c) { return a.start - c.start; });
            recomputeAllTotals();
            saveStateToStorage();
            try { sendToGist(); } catch (e) {}
            const lbl = plan.map(function (p) { return p[0] + '-' + p[1]; }).join(', ');
            console.log('[ITP] \u2615 ' + fmtHM(b.start) + ' vardiyasinin molalari otomatik yuklendi: ' + lbl);
            addLogEntry('\u2615', fmtHM(b.start) + ' vardiyasi molalari otomatik yuklendi (' + lbl + ')');
        } else {
            // yine de isaretle, surekli denemesin
            saveStateToStorage();
        }
        return added;
    }

    function addBreakWindow(startDate, endDate) {
        breakWindows.push({ start: startDate, end: endDate });
        breakWindows.sort(function (a, b) { return a.start - b.start; });
        recomputeAllTotals();
        saveStateToStorage();
        try { sendToGist(); } catch (e) {}   // v2.39: site hemen guncellensin
        addLogEntry('\u2615', 'Mola eklendi: ' + timeStr(startDate).slice(0, 5) + '-' + timeStr(endDate).slice(0, 5) +
            ' (tum kisilerin idle toplamindan dusuldu)');
    }

    function removeBreakWindow(index) {
        if (index < 0 || index >= breakWindows.length) return;
        const w = breakWindows[index];
        breakWindows.splice(index, 1);
        recomputeAllTotals();
        saveStateToStorage();
        try { sendToGist(); } catch (e) {}   // v2.39: site hemen guncellensin
        addLogEntry('\u21a9\ufe0f', 'Mola kaldirildi: ' + timeStr(w.start).slice(0, 5) + '-' + timeStr(w.end).slice(0, 5) +
            ' (idle toplamlari geri eklendi)');
    }

    // v2.43: bir kat degisiminden sonra kisi kac dk'da yeniden okutmus?
    // Henuz okutmadiysa (periyot hala acik) "acik" + simdiye kadar gecen sure doner.
    function transitInfo(entry, changeMs) {
        const runs = ensureIdleRuns(entry);
        const r = runs.find(function (rr) { return changeMs >= rr.s && changeMs <= rr.e; });
        if (!r) return null;
        if (r.open) return { open: true, minutes: Math.round((now().getTime() - changeMs) / 60000) };
        return { open: false, minutes: Math.round((r.e - changeMs) / 60000) };
    }

    // Belirli bir aralikta kac dk idle mola olarak hariclendi
    function breakImpact(startMs, endMs) {
        let total = 0, people = 0;
        Object.values(trackerData).forEach(function (entry) {
            const runs = ensureIdleRuns(entry);
            let ms = 0;
            runs.forEach(function (r) { ms += overlapMs(r.s, r.e, startMs, endMs); });
            const m = Math.round(ms / 60000);
            if (m > 0) { total += m; people++; }
        });
        return { minutes: total, people: people };
    }

    // ==================== MOLA SAATLERI MODALI ====================
    function showBreakSettings() {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.style.maxWidth = '620px';

        function render() {
            const rows = breakWindows.map(function (w, i) {
                const imp = breakImpact(w.start.getTime(), w.end.getTime());
                return '<tr style="border-bottom:1px solid rgba(255,255,255,0.06);">' +
                    '<td style="padding:8px 10px;font-size:13px;font-weight:700;color:#ffcc80;">' +
                    timeStr(w.start).slice(0, 5) + ' \u2013 ' + timeStr(w.end).slice(0, 5) +
                    (w.auto ? ' <span style="font-size:9px;font-weight:600;color:#80cbc4;background:rgba(128,203,196,0.15);border-radius:4px;padding:1px 5px;vertical-align:middle;">OTOMAT\u0130K</span>' : '') +
                    '</td>' +
                    '<td style="padding:8px 10px;font-size:12px;color:#aaa;">' +
                    imp.people + ' ki\u015fi / ' + formatMinutes(imp.minutes) + ' d\u00fc\u015f\u00fcld\u00fc</td>' +
                    '<td style="padding:8px 10px;text-align:right;">' +
                    '<button class="itp-break-del" data-idx="' + i + '" ' +
                    'style="background:#f44336;color:#fff;border:none;border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;" ' +
                    'title="Bu molayi kaldir, idle dakikalari geri eklenir">\u2715 Kald\u0131r</button></td></tr>';
            }).join('');

            const thS = 'background:rgba(121,85,72,0.25);color:#ffcc80;padding:8px 10px;text-align:left;font-size:11px;border-bottom:2px solid rgba(121,85,72,0.5);';
            const table = breakWindows.length === 0
                ? '<p style="color:#888;text-align:center;padding:14px;font-size:12px;">Hen\u00fcz mola aral\u0131\u011f\u0131 girilmemi\u015f</p>'
                : '<table style="width:100%;border-collapse:collapse;margin-top:6px;"><thead><tr>' +
                  '<th style="' + thS + '">Mola Aral\u0131\u011f\u0131</th>' +
                  '<th style="' + thS + '">Etki</th>' +
                  '<th style="' + thS + '"></th>' +
                  '</tr></thead><tbody>' + rows + '</tbody></table>';

            const inpS = 'background:rgba(0,0,0,0.35);color:#fff;border:1px solid rgba(255,255,255,0.15);border-radius:8px;padding:8px 10px;font-size:14px;font-family:inherit;';

            modal.innerHTML =
                '<button class="itp-close-btn" id="itp-close-break">\u2715</button>' +
                '<h2 style="color:#ffcc80;margin:0 0 6px 0;font-size:19px;">\u2615 Mola Saatleri</h2>' +
                '<p style="color:#999;font-size:12px;margin:0 0 16px 0;line-height:1.5;">' +
                'Girdi\u011fin aral\u0131klara denk gelen <b>t\u00fcm idle</b> her ki\u015finin toplam\u0131ndan d\u00fc\u015f\u00fcl\u00fcr ve o aral\u0131kta otomatik FANS mesaj\u0131 gitmez.<br>' +
                'Veri silinmez \u2014 bir molay\u0131 kald\u0131r\u0131rsan dakikalar geri eklenir.<br>' +
                '<b style="color:#80cbc4;">Vardiya molalar\u0131 otomatik y\u00fcklenir</b> (sabah 10:30-11:10 + 14:05-14:25, ak\u015fam 19:15-19:55 + 22:05-22:25, gece 03:30-04:10 + 06:05-06:25). ' +
                'Otomatik geleni kald\u0131r\u0131rsan ayn\u0131 vardiyada geri gelmez; geri istersen \u201cVardiya Molalar\u0131n\u0131 Y\u00fckle\u201d butonuna bas.</p>' +
                '<div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:14px;">' +
                '<div style="display:flex;align-items:flex-end;gap:10px;flex-wrap:wrap;">' +
                '<div><div style="font-size:11px;color:#aaa;margin-bottom:4px;">Ba\u015flang\u0131\u00e7</div>' +
                '<input type="time" id="itp-break-start" style="' + inpS + '"></div>' +
                '<div><div style="font-size:11px;color:#aaa;margin-bottom:4px;">Biti\u015f</div>' +
                '<input type="time" id="itp-break-end" style="' + inpS + '"></div>' +
                '<button id="itp-break-add" class="itp-export-btn" style="background:#795548;font-size:12px;padding:9px 18px;">\u2795 Mola Ekle</button>' +
                '<button id="itp-break-seed" class="itp-export-btn" style="background:#00897b;font-size:12px;padding:9px 18px;" ' +
                'title="Bu vardiyanin sabit molalarini (yemek + cay) listeye ekler">\ud83d\udd04 Vardiya Molalar\u0131n\u0131 Y\u00fckle</button>' +
                '</div>' +
                '<div style="margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.08);display:flex;align-items:flex-end;gap:10px;flex-wrap:wrap;">' +
                '<div><div style="font-size:11px;color:#aaa;margin-bottom:4px;">Ki\u015fi ba\u015f\u0131 mola limiti (dk, 0 = s\u0131n\u0131rs\u0131z)</div>' +
                '<input type="number" id="itp-break-cap" min="0" step="5" value="' + maxBreakMinutesPerPerson + '" style="' + inpS + 'width:90px;"></div>' +
                '<div><div style="font-size:11px;color:#aaa;margin-bottom:4px;">Mola sayma e\u015fi\u011fi (dk, 0 = esik yok)</div>' +
                '<input type="number" id="itp-break-min" min="0" step="5" value="' + minBreakBlockMinutes + '" style="' + inpS + 'width:90px;"></div>' +
                '<div><div style="font-size:11px;color:#aaa;margin-bottom:4px;">Kat de\u011fi\u015fimi ba\u015f\u0131 ba\u011f\u0131\u015flanan (dk, 0 = kapal\u0131)</div>' +
                '<input type="number" id="itp-fc-forgive" min="0" step="1" value="' + floorChangeForgiveMin + '" style="' + inpS + 'width:90px;"></div>' +
                '<button id="itp-break-cap-save" class="itp-export-btn" style="background:#607d8b;font-size:12px;padding:9px 18px;">\ud83d\udcbe Kaydet</button>' +
                '</div>' +
                '<div style="margin-top:10px;font-size:11px;color:#888;line-height:1.5;">' +
                'E\u015fik <b>0</b> ise aral\u0131\u011fa denk gelen <b>t\u00fcm</b> idle d\u00fc\u015f\u00fcl\u00fcr (\u00f6nerilen). ' +
                'E\u015fi\u011fe de\u011fer verirsen, aral\u0131kta en az o kadar kesintisiz idle olmayan ki\u015fiden hi\u00e7bir \u015fey d\u00fc\u015f\u00fclmez.<br>' +
                'Limit <b>0</b> ise ki\u015fi ba\u015f\u0131 \u00fcst s\u0131n\u0131r yoktur. Veri silinmez, molay\u0131 kald\u0131r\u0131rsan dakikalar geri gelir.<br>' +
                'Kat de\u011fi\u015fimi alan\u0131: her kat de\u011fi\u015fiminden sonraki ilk N dakika y\u00fcr\u00fcme/ge\u00e7i\u015f say\u0131l\u0131p idle\u2019den d\u00fc\u015f\u00fcl\u00fcr (0 = kapal\u0131, hi\u00e7bir \u015fey d\u00fc\u015f\u00fclmez). Kat de\u011fi\u015fiminden sonra ka\u00e7 dk\u2019da okuttu\u011fu her olay i\u00e7in kat de\u011fi\u015fimleri b\u00f6l\u00fcm\u00fcnde her zaman g\u00f6sterilir.</div>' +
                '</div>' +
                '<div style="margin-top:16px;">' + table + '</div>';
        }

        render();
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        overlay.addEventListener('click', function (e) {
            if (e.target === overlay || e.target.id === 'itp-close-break') { overlay.remove(); updatePanel(); return; }

            if (e.target.id === 'itp-break-add') {
                const sv = (document.getElementById('itp-break-start') || {}).value;
                const ev = (document.getElementById('itp-break-end') || {}).value;
                if (!sv || !ev) { alert('Ba\u015flang\u0131\u00e7 ve biti\u015f saatini gir.'); return; }
                const sp = sv.split(':'), ep = ev.split(':');
                const st = now(); st.setHours(Number(sp[0]), Number(sp[1]), 0, 0);
                const en = now(); en.setHours(Number(ep[0]), Number(ep[1]), 0, 0);
                if (en.getTime() <= st.getTime()) { alert('Biti\u015f saati ba\u015flang\u0131\u00e7tan sonra olmal\u0131.'); return; }
                const imp = breakImpact(st.getTime(), en.getTime());
                addBreakWindow(st, en);
                render();
                alert('\u2615 Mola eklendi: ' + sv + ' - ' + ev + '\n\n' +
                    imp.people + ' ki\u015fiden toplam ' + imp.minutes + ' dk idle d\u00fc\u015f\u00fcld\u00fc.');
                return;
            }

            if (e.target.id === 'itp-break-seed') {
                const n = seedShiftBreaks(true);
                render();
                alert(n > 0
                    ? '\u2615 ' + n + ' vardiya molas\u0131 eklendi.\n\nToplamlar yeniden hesapland\u0131.'
                    : 'Bu vardiyan\u0131n molalar\u0131 zaten listede.');
                return;
            }

            if (e.target.id === 'itp-break-cap-save') {
                const cv = Number((document.getElementById('itp-break-cap') || {}).value);
                const mv = Number((document.getElementById('itp-break-min') || {}).value);
                const fv = Number((document.getElementById('itp-fc-forgive') || {}).value);
                if (isNaN(cv) || cv < 0 || isNaN(mv) || mv < 0 || isNaN(fv) || fv < 0) { alert('Ge\u00e7erli dakika de\u011ferleri gir (0 veya daha b\u00fcy\u00fck).'); return; }
                maxBreakMinutesPerPerson = cv;
                minBreakBlockMinutes = mv;
                floorChangeForgiveMin = fv;
                recomputeAllTotals();
                saveStateToStorage();
                try { sendToGist(); } catch (e2) {}   // v2.39: site hemen guncellensin
                addLogEntry('\u2615', 'Mola ayarlar\u0131: limit ' + cv + ' dk, e\u015fik ' + mv + ' dk, kat de\u011fi\u015fimi ba\u011f\u0131\u015f\u0131 ' + fv + ' dk.');
                render();
                alert('Kaydedildi.\nKi\u015fi ba\u015f\u0131 limit: ' + cv + ' dk\nMola sayma e\u015fi\u011fi: ' + mv + ' dk\nKat de\u011fi\u015fimi ba\u015f\u0131 ba\u011f\u0131\u015flanan: ' + fv + ' dk\n\nToplamlar yeniden hesapland\u0131.');
                return;
            }

            if (e.target.classList && e.target.classList.contains('itp-break-del')) {
                const idx = Number(e.target.getAttribute('data-idx'));
                if (!confirm('Bu mola aral\u0131\u011f\u0131 kald\u0131r\u0131ls\u0131n m\u0131?\nD\u00fc\u015f\u00fcr\u00fclen idle dakikalar\u0131 geri eklenecek.')) return;
                removeBreakWindow(idx);
                render();
                return;
            }
        });
    }

    // v2.17: bir idle periyodunu (tamamen veya belirtilen saatten sonrasini)
    // SADECE O KISI icin mola olarak isaretle. Veri silinmez; entry.personalBreaks
    // listesine eklenir, toplamlar yeniden hesaplanir, istenirse geri alinabilir.
    function markPeriodAsBreak(userId, periodStartMs, periodEndMs) {
        const entry = trackerData[userId];
        if (!entry || !entry.snapshots) return;

        const defaultHM = timeStr(new Date(periodStartMs)).slice(0, 5);
        const endHM = timeStr(new Date(periodEndMs)).slice(0, 5);
        const input = prompt(
            'Bu ki\u015fi i\u00e7in mola ka\u00e7ta ba\u015flad\u0131? (HH:MM)\n' +
            'Periyot ' + defaultHM + ' - ' + endHM + ' aras\u0131nda kay\u0131tl\u0131.\n' +
            'T\u00fcm periyodu mola saymak i\u00e7in direkt OK\u2019e bas.\n\n' +
            'Not: T\u00fcm ekibin molas\u0131 i\u00e7in panelden "\u2615 Mola Saatleri" kullan.',
            defaultHM
        );
        if (input === null) return;

        let breakStart = new Date(periodStartMs);
        const m = input.trim().match(/^(\d{1,2}):(\d{2})$/);
        if (m) {
            breakStart = new Date(periodStartMs);
            breakStart.setHours(Number(m[1]), Number(m[2]), 0, 0);
        }
        if (breakStart.getTime() < periodStartMs) breakStart = new Date(periodStartMs);
        if (breakStart.getTime() > periodEndMs) {
            alert('Girilen saat periyodun d\u0131\u015f\u0131nda, i\u015flem yap\u0131lmad\u0131.');
            return;
        }

        const before = entry.totalInactiveMinutes;
        entry.personalBreaks = entry.personalBreaks || [];
        entry.personalBreaks.push({
            start: breakStart.toISOString(),
            end: new Date(periodEndMs).toISOString(),
            markedAt: now().toISOString()
        });
        recomputeEntryTotals(entry);
        const removed = Math.max(0, before - entry.totalInactiveMinutes);

        if (removed === 0) {
            entry.personalBreaks.pop();
            recomputeEntryTotals(entry);
            alert('Bu aral\u0131kta d\u00fc\u015f\u00fclecek idle dakikas\u0131 bulunamad\u0131.');
            return;
        }

        saveStateToStorage();
        addLogEntry('\u2615', entry.name + ' i\u00e7in ' + removed + ' dk mola olarak i\u015faretlendi.');
        showPersonDetail(userId);
    }

    function computeIdlePeriods(userId) {
        const entry = trackerData[userId];
        if (!entry) return [];
        recomputeEntryTotals(entry);
        const runs = entry.idleRuns || [];
        return runs.map(function (r) {
            const lastSeg = r.segs[r.segs.length - 1] || {};
            return {
                startTime: new Date(r.s),          // son okutma saati (idle basladi)
                endTime: new Date(r.e),            // yeniden okutma saati (idle bitti)
                ongoing: !!r.open,
                location: lastSeg.loc || '',
                lastActivity: new Date(r.s).toLocaleString('tr-TR'),
                snapTimes: (r.snaps || []).map(function (m) { return new Date(m); }),
                snapCount: (r.snaps || []).length,
                rawMin: Math.round(Math.max(0, r.e - r.s) / 60000),
                cutMin: Math.round((r.cutMs || 0) / 60000),
                durationMin: r.effMin || 0
            };
        }).filter(function (pp) { return pp.durationMin > 0 || pp.ongoing; });
    }


    // v2.25: Kisinin idle'ini KAT bazinda ayristir.
    // Donus: [{ floor, minutes, ranges:[{start,end,min}] }] - dk'ya gore azalan.
    // Toplam = sum(minutes) === entry.totalInactiveMinutes
    function computeFloorIdle(userId) {
        const entry = trackerData[userId];
        if (!entry) return [];
        recomputeEntryTotals(entry);
        const runs = entry.idleRuns || [];
        const map = {};
        runs.forEach(function (r) {
            const eff = r.effMin || 0;
            if (eff <= 0) return;
            const segTot = r.segs.reduce(function (a, g) { return a + Math.max(0, g.to - g.from); }, 0);
            r.segs.forEach(function (g, i) {
                const fl = g.floor || entry.floor || 'Bilinmiyor';
                const share = segTot > 0 ? Math.max(0, g.to - g.from) / segTot : 1 / r.segs.length;
                const min = Math.round(eff * share);
                if (min <= 0) return;
                if (!map[fl]) map[fl] = { floor: fl, minutes: 0, ranges: [] };
                map[fl].minutes += min;
                map[fl].ranges.push({
                    start: new Date(i === 0 ? r.s : g.from),
                    end: new Date(i === r.segs.length - 1 ? r.e : g.to),
                    min: min
                });
            });
        });
        return Object.values(map).sort(function (a, b) { return b.minutes - a.minutes; });
    }

    // Ozet tablo icin kisa metin: "P2 25dk - P3 15dk"
    function floorIdleShort(userId) {
        const fi = computeFloorIdle(userId);
        if (fi.length === 0) return '-';
        return fi.map(function (f) { return f.floor + ' ' + formatMinutes(f.minutes); }).join(' \u00b7 ');
    }

    // Gunluk ozet mesaji olustur (mola oncesi bilgilendirme)
    function buildDailySummaryMsg(userId) {
        const entry = trackerData[userId];
        if (!entry) return '';
        const firstName = (entry.name || '').split(',')[1]?.trim() || (entry.name || '').split(' ')[0] || userId;
        const totalIdle = entry.totalInactiveMinutes;
        const locs = Object.entries(entry.locationCounts).sort((a, b) => b[1] - a[1]);
        const locStr = locs.map(([loc, mins]) => loc + "'da " + formatMinutes(mins)).join(', ');
        const periods = computeIdlePeriods(userId);
        const durBuckets = {};
        periods.forEach(p => {
            const key = formatMinutes(p.durationMin);
            durBuckets[key] = (durBuckets[key] || 0) + 1;
        });
        const durStr = Object.entries(durBuckets).map(([k, v]) => v + ' adet ' + k).join(', ');

        let msg = 'Selam ' + firstName + ', bug\u00fcn g\u00fcn i\u00e7erisinde toplam ' + formatMinutes(totalIdle) + ' idle yapt\u0131n.';
        const fiMsg = computeFloorIdle(userId);
        if (fiMsg.length > 0) {
            msg += ' Kat baz\u0131nda: ' + fiMsg.map(function (f) { return f.floor + ' ' + formatMinutes(f.minutes); }).join(', ') + '.';
        }
        if (locs.length > 0) msg += ' ' + locStr + ' idle tespit edildi.';
        if (periods.length > 1) msg += ' Toplam ' + periods.length + ' ayr\u0131 idle periyodu (' + durStr + ').';
        msg += ' Bilgin olsun. \u0130yi \u00e7al\u0131\u015fmalar \ud83d\udd14';
        return msg;
    }

    // ==================== DOM PARSING ====================
    // Sayfada birden fazla tablo olabilir (baska userscript'lerin ozet tablolari)
    // ve satirlar her zaman <tbody><tr> icinde olmayabilir (Cloudscape sticky-header
    // tablolarinda baslik ve govde ayri elemanlarda olabilir). Bu yuzden hem baslik
    // hem satir toplama dokuman genelinde ve esnek yapiliyor.

    const GMT_RE = /\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}/;

    function cellsOf(row) {
        let c = row.querySelectorAll('td');
        if (!c.length) c = row.querySelectorAll('[role="gridcell"], [role="cell"]');
        return c;
    }

    function findHeaderCells() {
        const tables = Array.from(document.querySelectorAll('table'));
        for (const t of tables) {
            const hs = t.querySelectorAll('thead th, thead td');
            if (!hs.length) continue;
            const txt = Array.from(hs).map(h => (h.textContent || '').toLowerCase()).join('|');
            if (txt.includes('user id') || txt.includes('last activity')) return hs;
        }
        const ch = document.querySelectorAll('[role="columnheader"]');
        if (ch.length) {
            const txt = Array.from(ch).map(h => (h.textContent || '').toLowerCase()).join('|');
            if (txt.includes('user id') || txt.includes('last activity')) return ch;
        }
        for (const t of tables) {
            const hs = t.querySelectorAll('thead th, thead td');
            if (hs.length >= 5) return hs;
        }
        return [];
    }

    function collectDataRows() {
        // Aday satirlar: dokuman genelinde yeterli hucresi olan tum satirlar
        let cand = Array.from(document.querySelectorAll('tbody tr'));
        if (!cand.length) cand = Array.from(document.querySelectorAll('tr'));
        let rows = cand.filter(r => cellsOf(r).length >= 5);
        if (!rows.length) {
            rows = Array.from(document.querySelectorAll('[role="row"]'))
                .filter(r => cellsOf(r).length >= 5);
        }
        // Sadece gercek picker satirlarini tut: icinde ya tarih/GMT ya da active/inactive olmali
        const filtered = rows.filter(r => {
            const t = (r.textContent || '').toLowerCase();
            return GMT_RE.test(r.textContent || '') || t.includes('inactive') || t.includes('active');
        });
        return filtered.length ? filtered : rows;
    }

    function getColumnIndexes() {
        const headers = findHeaderCells();
        if (!headers || !headers.length) return null;

        const indexes = {};
        Array.from(headers).forEach((th, i) => {
            const text = (th.textContent || '').trim().toLowerCase();
            if (text.includes('user id') || text === 'user id') indexes.userId = i;
            else if (text.includes('name') && !text.includes('manager')) indexes.name = i;
            else if (text.includes('location')) indexes.location = i;
            else if (text.includes('last activity')) indexes.lastActivity = i;
            else if (text.includes('sta') && !text.includes('station')) indexes.status = i;
            else if (text.includes('station')) indexes.station = i;
            else if (text.includes('manager')) indexes.manager = i;
        });

        // Status bulunamadiysa veya yanlissa, ilk veri satirinda active/inactive hucresini ara
        const firstRow = collectDataRows()[0];
        if (firstRow) {
            const cells = cellsOf(firstRow);
            if (indexes.status === undefined ||
                !/^(in)?active$/.test((cells[indexes.status]?.textContent || '').trim().toLowerCase())) {
                Array.from(cells).forEach((cell, i) => {
                    const t = (cell.textContent || '').trim().toLowerCase();
                    if (t === 'inactive' || t === 'active') indexes.status = i;
                });
            }
            if (indexes.lastActivity === undefined ||
                !GMT_RE.test(cells[indexes.lastActivity]?.textContent || '')) {
                Array.from(cells).forEach((cell, i) => {
                    if (indexes.lastActivity === undefined || !GMT_RE.test(cells[indexes.lastActivity]?.textContent || '')) {
                        if (GMT_RE.test(cell.textContent || '')) indexes.lastActivity = i;
                    }
                });
            }
        }

        return indexes;
    }

    // Satir bulunamadiginda DOM yapisini raporla (konsola yapistirmak icin)
    function itpDiagnose() {
        try {
            const tables = Array.from(document.querySelectorAll('table'));
            const info = tables.map((t, i) => ({
                i,
                theadCells: t.querySelectorAll('thead th, thead td').length,
                tbodyRows: t.querySelectorAll('tbody tr').length,
                allRows: t.querySelectorAll('tr').length,
                head: (t.querySelector('thead')?.textContent || '').trim().slice(0, 120)
            }));
            const allTr = Array.from(document.querySelectorAll('tr'));
            const fatTr = allTr.filter(r => r.querySelectorAll('td').length >= 5);
            const roleRows = Array.from(document.querySelectorAll('[role="row"]'));
            console.warn('[ITP] TANI — tablolar:', info);
            console.warn(`[ITP] TANI — toplam tr: ${allTr.length}, >=5 td olan tr: ${fatTr.length}, role=row: ${roleRows.length}`);
            if (fatTr.length) {
                console.warn('[ITP] TANI — ornek satir hucreleri:',
                    Array.from(fatTr[0].querySelectorAll('td')).map(c => (c.textContent || '').trim().slice(0, 40)));
            } else if (roleRows.length) {
                console.warn('[ITP] TANI — ornek role=row:', (roleRows[1] || roleRows[0]).outerHTML.slice(0, 600));
            }
        } catch (e) {
            console.warn('[ITP] TANI hata:', e);
        }
    }

    function parseTableRows() {
        const rows = [];
        const excluded = [];
        const cols = getColumnIndexes();
        if (!cols) {
            console.warn('[ITP] parseTableRows: baslik bulunamadi');
            return rows;
        }

        const trs = collectDataRows();
        trs.forEach(tr => {
            const cells = cellsOf(tr);
            if (cells.length < 5) return;

            // User Id hucresine baska script'ler ek metin basabiliyor ("login (08:00 13/10/2026)").
            // Once hucre icindeki link'i, sonra parantezleri temizleyip ilk kelimeyi al.
            let userId = '';
            if (cols.userId !== undefined && cells[cols.userId]) {
                const uCell = cells[cols.userId];
                const link = uCell.querySelector('a');
                userId = ((link ? link.textContent : uCell.textContent) || '')
                    .replace(/\(.*?\)/g, ' ').trim().split(/\s+/)[0] || '';
            }
            // Dislanan is tipleri (orn. PPConsolidationFlowPick1) takip edilmez
            if (userId) {
                const hay = Array.from(cells).map(c => c.textContent || '').join(' ').toLowerCase();
                const hit = EXCLUDED_PROCESSES.find(pp => hay.includes(pp.toLowerCase()));
                if (hit) {
                    excluded.push(userId + ' (' + hit + ')');
                    if (trackerData[userId]) delete trackerData[userId];
                    if (messagedUsers[userId]) delete messagedUsers[userId];
                    return;
                }
            }

            const name = cols.name !== undefined ? (cells[cols.name]?.textContent || '').trim() : '';
            const location = cols.location !== undefined ? (cells[cols.location]?.textContent || '').trim() : '';
            let lastActivity = cols.lastActivity !== undefined ? (cells[cols.lastActivity]?.textContent || '').trim() : '';
            if (!GMT_RE.test(lastActivity)) {
                for (const c of cells) {
                    const t = (c.textContent || '').trim();
                    if (GMT_RE.test(t)) { lastActivity = t; break; }
                }
            }

            let statusText = '';
            if (cols.status !== undefined && cells[cols.status]) {
                const badge = cells[cols.status].querySelector('[class*="badge"], [class*="status"], [class*="tag"], span');
                statusText = (badge ? badge.textContent : cells[cols.status].textContent || '').trim().toLowerCase();
            }
            if (statusText !== 'active' && statusText !== 'inactive') {
                for (const c of cells) {
                    const t = (c.textContent || '').trim().toLowerCase();
                    if (t === 'inactive' || t === 'active') { statusText = t; break; }
                }
            }

            if (userId && /^[a-z0-9._-]{3,30}$/i.test(userId)) {
                const manager = cols.manager !== undefined ? (cells[cols.manager]?.textContent || '').trim() : '';
                rows.push({
                    userId,
                    name,
                    location,
                    status: statusText,
                    lastActivity,
                    floor: extractFloor(location),
                    manager
                });
            }
        });

        const inact = rows.filter(r => r.status.includes('inactive'));
        console.log(`[ITP] parseTableRows: ${rows.length} satir, ${inact.length} inactive, cols:`, cols);
        if (!rows.length) itpDiagnose();
        if (rows.length && !rows[0].lastActivity) console.warn('[ITP] lastActivity bos, ornek satir:', rows[0]);
        if (inact.length) console.log('[ITP] ornek inactive:', inact[0]);
        if (excluded.length) console.log(`[ITP] ${excluded.length} kisi dislanan is tipinde, takip edilmiyor:`, excluded.join(', '));
        return rows;
    }

    // ==================== VERI KAYNAGI: WORKFORCE API (v2.40) ====================
    // Eskiden satirlar HTML tablosundan kaziniyordu. Sorun: kisi scanner'dan
    // cikinca satir tablodan dusuyor ve idle takibi orada kesiliyordu. Ayrica
    // baska userscript'ler hucre metnine ekleme yapabiliyor, tablo sayfalanabiliyor.
    //
    // Site bu veriyi zaten JSON olarak veriyor:
    //   GET /api/fcs/IST2/workforce  ->  { pickerStatusList: [ ... ] }
    // Her kayitta: userId, employeeId, name, manager, active (boolean),
    //   lastActivityTime / lastSeenTime (ONDALIKLI EPOCH SANIYE),
    //   location, pickArea, processPath, lastContainerId
    // Scanner'dan cikan kisi bu listede KALIR -> son okutma saati kaybolmaz.
    const WORKFORCE_API = '/api/fcs/IST2/workforce';
    let lastRowSource = '-';

    // parseLastActivityTime'in bekledigi "2026-10-16 15:28:25 GMT+0300" bicimi.
    function fmtActivityStamp(ms) {
        const d = new Date(ms);
        const p = n => String(n).padStart(2, '0');
        const off = -d.getTimezoneOffset();
        const sign = off >= 0 ? '+' : '-';
        const ao = Math.abs(off);
        return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' +
            p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) +
            ' GMT' + sign + p(Math.floor(ao / 60)) + p(ao % 60);
    }

    async function fetchWorkforceRows() {
        const res = await fetch(WORKFORCE_API, {
            credentials: 'include',
            headers: { Accept: 'application/json' }
        });
        if (!res.ok) throw new Error('workforce HTTP ' + res.status);
        const data = await res.json();
        const list = data && data.pickerStatusList;
        if (!Array.isArray(list)) throw new Error('pickerStatusList alani yok');

        const rows = [];
        const excluded = [];
        for (const w of list) {
            const userId = String((w && w.userId) || '').trim();
            if (!userId || !/^[a-z0-9._-]{3,30}$/i.test(userId)) continue;

            // Dislanan is tipleri (orn. PPConsolidationFlowPick1) takip edilmez.
            // Artik satir metni tahmini degil, gercek processPath alani.
            const path = String(w.processPath || '');
            const hit = EXCLUDED_PROCESSES.find(pp => path.toLowerCase() === pp.toLowerCase());
            if (hit) {
                excluded.push(userId + ' (' + hit + ')');
                if (trackerData[userId]) delete trackerData[userId];
                if (messagedUsers[userId]) delete messagedUsers[userId];
                continue;
            }

            const laMs = (() => {
                const n = Number(w.lastActivityTime);
                if (!isFinite(n) || n <= 0) return null;
                return n > 1e12 ? n : n * 1000;
            })();

            const location = String(w.location || '').trim();
            const area = String(w.pickArea || '').trim();
            let floor = extractFloor(location);
            if (floor === 'N/A' && area) floor = extractFloor(area.replace(/^pa/i, 'P-'));

            if (w.employeeId) {
                const eid = String(w.employeeId).trim();
                if (eid) employeeIdCache[userId] = eid;
            }

            rows.push({
                userId,
                name: String(w.name || '').trim(),
                location,
                status: w.active === true ? 'active' : 'inactive',
                lastActivity: laMs ? fmtActivityStamp(laMs) : '',
                lastActivityMs: laMs,
                floor,
                manager: String(w.manager || '').trim(),
                pickArea: area,
                processPath: path,
                tote: String(w.lastContainerId || '').trim(),
                src: 'api'
            });
        }

        const inact = rows.filter(r => r.status === 'inactive');
        console.log('[ITP] workforce API: ' + list.length + ' kayit -> ' + rows.length +
            ' satir, ' + inact.length + ' inactive');
        if (excluded.length) {
            console.log('[ITP] ' + excluded.length + ' kisi dislanan is tipinde, takip edilmiyor: ' +
                excluded.join(', '));
        }
        if (inact.length) console.log('[ITP] ornek inactive (api):', inact[0]);
        return rows;
    }

    // Birincil kaynak API; API patlarsa eski tablo kazimasina duser.
    async function getRows() {
        try {
            const rows = await fetchWorkforceRows();
            if (rows.length) { lastRowSource = 'API'; return rows; }
            console.warn('[ITP] workforce API bos liste dondu, tabloya dusuluyor.');
        } catch (e) {
            console.warn('[ITP] workforce API hatasi (' + (e && e.message) + '), tabloya dusuluyor.');
        }
        lastRowSource = 'TABLO';
        return parseTableRows();
    }

    // ==================== FANS MESSAGE ====================
    function buildMessage(name, userId, idleMinutes, location, floor) {
        const firstName = name.split(',')[1]?.trim() || name.split(' ')[0] || userId;
        return `Selam ${firstName}, ${floor} katında ${location} lokasyonunda ${idleMinutes} dakikadır inactive görünüyorsun. Lütfen ürün okutur musun. Teşekkürler. İyi çalışmalar 🔔`;
    }

    // Manuel mesaj gönder butonu için global fonksiyon
    async function sendMessageToUser(userId) {
        const data = trackerData[userId];
        if (!data) { alert('Kullanıcı bulunamadı: ' + userId); return; }
        if (messagedUsers[userId]) { alert('Bu kullanıcıya zaten mesaj gönderildi.'); return; }

        const idleMins = data.idleMinutes || data.totalInactiveMinutes;
        const msgPreview = buildMessage(data.name, userId, idleMins, data.snapshots[data.snapshots.length - 1]?.location || '', data.floor);

        // Onay uyarısı — mesaj içeriğini göster
        if (!confirm(`📩 FANS Mesaj Gönder\n\nKime: ${data.name} (${userId})\nKat: ${data.floor} | Idle: ${formatMinutes(idleMins)}\n\nMesaj:\n"${msgPreview}"\n\nGöndermek istiyor musun?`)) return;
        const msgText = buildMessage(data.name, userId, idleMins, data.snapshots[data.snapshots.length - 1]?.location || '', data.floor);

        // Butonu deaktive et
        const btn = document.querySelector(`[data-send-uid="${userId}"]`);
        if (btn) { btn.textContent = '⏳ Gönderiliyor...'; btn.disabled = true; }

        try {
            await sendFANSMessage(userId, msgText);
            messagedUsers[userId] = {
                sentAt: now(),
                floor: data.floor,
                name: data.name,
                location: data.snapshots[data.snapshots.length - 1]?.location || '',
                messageText: msgText
            };
            if (btn) { btn.textContent = '✅ Gönderildi'; btn.style.background = '#4caf50'; }
            addLogEntry('📤', `FANS mesaj gönderildi: ${data.name} (${userId}) — ${data.floor}`);
            saveStateToStorage();
        } catch (err) {
            if (btn) { btn.textContent = '❌ Hata'; btn.disabled = false; }
            addLogEntry('❌', `FANS mesaj HATA: ${data.name} (${userId}) — ${err.message}`);
            alert('Mesaj gönderilemedi: ' + err.message);
        }
    }

    // Toplu mesaj gönder (tüm hazır olanlara)
    async function sendMessageToAll() {
        const ready = Object.entries(trackerData).filter(([uid, d]) => d.readyForMessage && !messagedUsers[uid]);
        if (ready.length === 0) { alert('Mesaj gönderilecek kullanıcı yok.'); return; }
        if (!confirm(`${ready.length} kişiye mesaj gönderilecek. Onaylıyor musunuz?`)) return;

        for (const [uid] of ready) {
            await sendMessageToUser(uid);
            // Her mesaj arası 1sn bekle (rate limit)
            await new Promise(r => setTimeout(r, 1000));
        }
        alert(`✅ ${ready.length} mesaj gönderildi!`);
    }

    // Global erişim için window'a bağla
    // GM_xmlhttpRequest sandbox'ı nedeniyle unsafeWindow gerekli
    const _w = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
    _w._itpSendMsg = sendMessageToUser;
    _w._itpSendAll = sendMessageToAll;
    _w._itpShowDetail = showPersonDetail;

    function sendFANSMessage(userId, messageText) {
        return new Promise((resolve, reject) => {
            // Arka planda FANS'a mesaj gönder (popup AÇMADAN)
            // Önce GET ile sayfayı çek, hidden field'ları (CSRF token vs.) al
            GM_xmlhttpRequest({
                method: 'GET',
                url: FANS_URL,
                onload: function (response) {
                    if (response.status !== 200) {
                        console.error(`[FANS] GET failed: ${response.status}`);
                        reject(new Error('FANS GET failed'));
                        return;
                    }

                    // HTML'den form action ve hidden input'ları çıkar
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response.responseText, 'text/html');
                    const form = doc.querySelector('form');
                    const actionUrl = form ? (form.action || FANS_URL) : FANS_URL;

                    // Tüm hidden field'ları topla
                    const formData = new URLSearchParams();
                    if (form) {
                        form.querySelectorAll('input[type="hidden"]').forEach(inp => {
                            formData.append(inp.name, inp.value);
                        });
                    }

                    // FANS form alanları
                    formData.set('from', FANS_SENDER);
                    formData.set('to', userId);
                    formData.set('message', messageText);
                    formData.set('direct_reports_of', '');

                    // POST gönder
                    const postUrl = actionUrl.startsWith('http') ? actionUrl : FANS_URL;
                    GM_xmlhttpRequest({
                        method: 'POST',
                        url: postUrl,
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Referer': FANS_URL
                        },
                        data: formData.toString(),
                        onload: function (postResponse) {
                            if (postResponse.status >= 200 && postResponse.status < 400) {
                                console.log(`[FANS] ✅ Arka planda mesaj gönderildi: ${userId}`);
                                resolve(true);
                            } else {
                                console.error(`[FANS] POST failed: ${postResponse.status}`, postResponse.responseText?.slice(0, 200));
                                reject(new Error(`FANS POST failed: ${postResponse.status}`));
                            }
                        },
                        onerror: function (err) {
                            console.error('[FANS] POST error:', err);
                            reject(err);
                        }
                    });
                },
                onerror: function (err) {
                    console.error('[FANS] GET error:', err);
                    reject(err);
                }
            });
        });
    }


        // ==================== SCANNING ====================
    async function doScan() {
        const scanTime = now();
        // v2.44: vardiya molalarini otomatik yukle (vardiya degistiginde tekrar calisir)
        try { seedShiftBreaks(false); } catch (eSb) { console.warn('[ITP] mola yukleme hatasi:', eSb); }
        const rows = await getRows();

        // Bugunku shift baslangicindan (SHIFT_START) ONCEKI "Last Activity Time"
        // degerine sahip inactive satirlar, bugunun verisi degil — dunden kalan /
        // henuz bugun hic scan atmamis "stale" kayitlardir. Konsol tablosu bu
        // satirlari status=inactive olarak gostermeye devam edebiliyor; bunlari
        // tamamen yoksay (idle sureye, mesaja, raporlamaya dahil etme).
        const todayShiftStart = getShiftBounds(scanTime).start;
        let staleSkipped = 0;
        const inactiveRows = rows.filter(r => {
            if (!(r.status.includes('inactive') && TRACKED_FLOORS.includes(r.floor))) return false;
            const rla = parseLastActivityTime(r.lastActivity);
            if (rla && rla < todayShiftStart) {
                staleSkipped++;
                return false;
            }
            return true;
        });
        if (staleSkipped > 0) {
            console.log(`[ITP] ${staleSkipped} dunden kalan / stale inactive satiri atlandi (Last Activity < ${fmtHM(todayShiftStart)}).`);
        }

        // v2.36: ACTIVE satirlar da islenir. Kisi yesile dondugunde acik idle
        // periyodu, yeni "Last Activity Time" degerinde tam olarak kapanir.
        const inactiveSet = new Set(inactiveRows.map(function (r) { return r.userId; }));
        rows.forEach(function (r) {
            if (inactiveSet.has(r.userId)) return;
            const e = trackerData[r.userId];
            if (!e) return;
            updateIdleRuns(e, r, scanTime.getTime());
            recomputeEntryTotals(e);
        });

        for (const row of inactiveRows) {
            // Tracker data güncelle
            if (!trackerData[row.userId]) {
                trackerData[row.userId] = {
                    name: row.name,
                    snapshots: [],
                    totalInactiveMinutes: 0,
                    locationCounts: {},
                    floor: row.floor,
                    manager: row.manager,
                    firstInactiveSeen: scanTime
                };
            }

            const entry = trackerData[row.userId];
            entry.name = row.name || entry.name;
            entry.manager = row.manager || entry.manager;
            // v2.41: is tipi artik API'den gercek alan olarak geliyor
            entry.processPath = row.processPath || entry.processPath || '';

            // ===== KAT DEĞİŞİMİ TESPİTİ =====
            const prevSnapshots = entry.snapshots;
            const lastSnap = prevSnapshots.length > 0 ? prevSnapshots[prevSnapshots.length - 1] : null;
            const prevFloor = lastSnap ? extractFloor(lastSnap.location) : null;
            const currFloor = row.floor;
            const isFloorChange = prevFloor && prevFloor !== currFloor && prevFloor !== 'N/A' && currFloor !== 'N/A';

            if (isFloorChange) {
                // Kat değişimi kaydı
                if (!floorChanges[row.userId]) floorChanges[row.userId] = [];
                floorChanges[row.userId].push({
                    time: scanTime,
                    fromFloor: prevFloor,
                    toFloor: currFloor,
                    fromLocation: lastSnap.location,
                    toLocation: row.location
                });
                // v2.43: bagislama hesabi icin olayin kesin zamani entry uzerinde de tutulur
                // (recomputeEntryTotals sadece entry alir, userId'ye ihtiyac duymasin).
                entry.floorChangeTimes = entry.floorChangeTimes || [];
                entry.floorChangeTimes.push(scanTime.getTime());
                console.log(`[ITP] 🔄 Kat değişimi: ${row.name} (${row.userId}) ${prevFloor} → ${currFloor}`);
                addLogEntry('🔄', `Kat değişimi: ${row.name} ${prevFloor} → ${currFloor}`);
            } else {
                // v2.18: toplamlar artik snapshot'lardan yeniden hesaplaniyor
                // (mola limiti dogru uygulanabilsin diye) — asagidaki
                // recomputeEntryTotals bu isi yapar.
            }

            entry.floor = row.floor || entry.floor;

            entry.snapshots.push({
                time: scanTime,
                location: row.location,
                status: row.status,
                lastActivity: row.lastActivity,
                isFloorChange: isFloorChange
            });

            // v2.36: idle periyotlarini Last Activity Time'a gore guncelle,
            // sonra toplamlari tek yerden hesapla.
            updateIdleRuns(entry, row, scanTime.getTime());
            recomputeEntryTotals(entry);

            // ===== 10 dk FANS mesaj kontrolü =====
            // Idle süresini hesapla (mesaj butonu göstermek için)
            const realLastActivity = parseLastActivityTime(row.lastActivity);
            const inactiveDuration = realLastActivity
                ? (scanTime - realLastActivity)
                : (scanTime - entry.firstInactiveSeen);
            const alreadyMessaged = messagedUsers[row.userId];

            // 10dk+ inactive → mesaj atılabilir olarak işaretle
            if (inactiveDuration >= INACTIVE_MSG_THRESHOLD_MS && !alreadyMessaged && !isInBreakWindow(scanTime)) {
                entry.readyForMessage = true;
                entry.idleMinutes = Math.round(inactiveDuration / 60000);

                // Otomatik mesaj toggle'ı açıksa ve kat filtresi uygunsa → gönder
                const floorEnabled = enabledMsgFloors.has(row.floor);
                if (autoMessageEnabled && floorEnabled) {
                    const msgText = buildMessage(row.name, row.userId, entry.idleMinutes, row.location, row.floor);
                    try {
                        await sendFANSMessage(row.userId, msgText);
                        messagedUsers[row.userId] = {
                            sentAt: scanTime, floor: row.floor, name: row.name,
                            location: row.location, messageText: msgText
                        };
                        addLogEntry('📤', `Otomatik mesaj: ${row.name} (${row.userId}) — ${row.floor}`);
                    } catch (err) {
                        addLogEntry('❌', `Mesaj HATA: ${row.name} — ${err.message}`);
                    }
                }
            } else if (!alreadyMessaged) {
                entry.readyForMessage = false;
            }

            // ===== Mesaj gönderilmiş ama hâlâ inactive mi? =====
            if (alreadyMessaged) {
                const sinceMsg = Math.round((scanTime - alreadyMessaged.sentAt) / 60000);
                stillInactiveAfterMsg[row.userId] = {
                    name: row.name,
                    floor: row.floor,
                    msgSentAt: alreadyMessaged.sentAt,
                    checkedAt: scanTime,
                    idleSinceMsg: sinceMsg,
                    location: row.location,
                    totalInactiveMinutes: entry.totalInactiveMinutes
                };
            }
        }

        // Mesaj gönderilmiş ama artık active olan kullanıcıları stillInactiveAfterMsg'dan çıkar
        const activeUserIds = new Set(rows.filter(r => r.status.includes('active') && !r.status.includes('inactive')).map(r => r.userId));
        Object.keys(stillInactiveAfterMsg).forEach(uid => {
            if (activeUserIds.has(uid)) {
                delete stillInactiveAfterMsg[uid];
            }
        });

        // Active olan kullanıcıların firstInactiveSeen'ını sıfırla
        activeUserIds.forEach(uid => {
            if (trackerData[uid]) {
                trackerData[uid].firstInactiveSeen = null;
            }
        });

        scanCount++;
        lastScanTime = scanTime;
        updatePanel();
        // v2.23: dashboard paketine rate'ler de gitsin -> once doldur
        await refreshWeeklyRates(false);
        await refreshBadgePhotos(30);
        sendToGist();

        console.log(`[Inactive Tracker] Scan #${scanCount}: ${inactiveRows.length} inactive, ${Object.keys(messagedUsers).length} mesaj gönderildi, ${Object.keys(stillInactiveAfterMsg).length} hâlâ inactive`);

        // State'i localStorage'a kaydet (auto-refresh sayfa yenileme için)
        saveStateToStorage();
    }

    // ==================== SHIFT TIMER ====================
    function checkShiftEnd() {
        const current = now();
        const endTime = getShiftBounds(current).end;
        if (current >= endTime && isTracking) {
            stopTracking();
            showSummary();
        }
    }


    // ==================== ARKA PLAN MOTORU (v2.38) ====================
    // Chrome, arka plandaki sekmelerde setInterval'i dakikada 1'e kadar kisiyor
    // ("intensive throttling", sekme 5 dk gizli kaldiktan sonra).
    // Eski kod 1 saniyede bir sayaci azaltarak calisiyordu; arka planda bu sayac
    // dakikada 1 azaldigi icin 60 sn'lik sayfa yenilemesi 60 DAKIKAYA cikiyordu.
    // Tarama da ayni sekilde kayiyordu (ekranda 6 dk'lik araliklar, sonra tam duruyor).
    //
    // Cozum 3 katmanli:
    //   1) Sayac yok, DUVAR SAATI var: nextScanAt / nextRefreshAt. Tek bir tick
    //      gelse bile gecikmis is hemen yapilir (en kotu durumda 1 dk sapma).
    //   2) Tick kaynagi Web Worker: worker zamanlayicilari ayni sekilde kisilmiyor.
    //   3) Duyulmaz ses: sekme "ses caliyor" sayilinca Chrome agir throttling
    //      uygulamaz ve sekmeyi bellekten atmaz.
    let nextScanAt = 0;
    let nextGistAt = 0;
    let lastTickAt = Date.now();
    let bgWorker = null;
    let keepAliveCtx = null;

    function bgTick() {
        const t = Date.now();
        const gap = t - lastTickAt;
        lastTickAt = t;
        if (gap > SCAN_INTERVAL_MS) {
            console.log('[ITP] \u23f1 ' + Math.round(gap / 60000) + ' dk ara verilmis (uyku / arka plan kisitlamasi) \u2014 hemen taraniyor.');
            addLogEntry('\u23f1', Math.round(gap / 60000) + ' dk ara sonrasi tarama');
        }

        if (isTracking && t >= nextScanAt) {
            nextScanAt = t + SCAN_INTERVAL_MS;
            try {
                doScan().catch(function (e) { console.warn('[ITP] tarama hatasi:', e); });
                checkShiftEnd();
            } catch (e) { console.warn('[ITP] tarama hatasi:', e); }
        }
        if (t >= nextGistAt) {
            nextGistAt = t + SCAN_INTERVAL_MS;
            try { sendToGist(); } catch (e) { console.warn('[Gist] gonderim hatasi:', e); }
        }
        if (autoRefreshEnabled) {
            if (!nextRefreshAt) nextRefreshAt = t + autoRefreshIntervalMs;
            autoRefreshCountdown = Math.max(0, Math.round((nextRefreshAt - t) / 1000));
            updateRefreshCountdown();
            if (t >= nextRefreshAt) {
                saveStateToStorage();
                location.reload();
            }
        }
    }

    function startBgTicker() {
        const workerSrc = 'var i=setInterval(function(){postMessage(1)},5000);' +
                          'onmessage=function(){clearInterval(i)};';
        try {
            const url = URL.createObjectURL(new Blob([workerSrc], { type: 'application/javascript' }));
            bgWorker = new Worker(url);
            bgWorker.onmessage = function () { bgTick(); };
            console.log('[ITP] \u2699 arka plan zamanlayici: Web Worker (5 sn tick) \u2014 sekme arka planda da taranir');
        } catch (e) {
            console.warn('[ITP] Worker kurulamadi, yedek setInterval kullanilacak:', e);
        }
        setInterval(bgTick, 5000);  // yedek (arka planda kisilir ama hic olmazsa calisir)
        document.addEventListener('visibilitychange', function () { if (!document.hidden) bgTick(); });
        window.addEventListener('focus', bgTick);
        window.addEventListener('online', bgTick);
    }

    // Duyulmaz ses -> sekme "audible" sayilir -> Chrome throttling'i uygulamaz.
    // Tarayici otomatik oynatmaya izin vermedigi icin ilk kullanici tiklamasinda baslar.
    function startKeepAlive() {
        try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            if (!keepAliveCtx) {
                keepAliveCtx = new AC();
                const osc = keepAliveCtx.createOscillator();
                const g = keepAliveCtx.createGain();
                osc.frequency.value = 40;
                g.gain.value = 0.0015;  // duyulmaz ama "sessiz" sayilmaz
                osc.connect(g);
                g.connect(keepAliveCtx.destination);
                osc.start();
            }
            if (keepAliveCtx.state !== 'running') {
                keepAliveCtx.resume().then(function () {
                    console.log('[ITP] \ud83d\udd0a arka plan korumasi aktif (sekme uyutulmayacak)');
                }).catch(function () {});
            }
        } catch (e) { /* sessizce gec */ }
    }

    function startTracking() {
        if (isTracking) return;
        isTracking = true;

        // 30 dakikada bir otomatik rapor güncelle
        reportTimer = setInterval(() => {
            showAutoReport();
        }, REPORT_INTERVAL_MS);

        doScan().catch(function (e) { console.warn('[ITP] ilk tarama hatasi:', e); });
        nextScanAt = Date.now() + SCAN_INTERVAL_MS;  // v2.38: tarama bgTick'ten tetiklenir
        startKeepAlive();
        updatePanel();
        addLogEntry('▶️', 'Takip başlatıldı');
    }

    function stopTracking() {
        isTracking = false;
        nextScanAt = 0;
        if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
        if (reportTimer) { clearInterval(reportTimer); reportTimer = null; }
        updatePanel();
        addLogEntry('⏹', 'Takip durduruldu');
    }

    // ==================== 30 DK DASHBOARD RAPORU ====================
    // Tarama geçmişi (timeline grafik için)
    let scanHistory = []; // [{ time: Date, inactiveCount: number, msgCount: number, stillInactiveCount: number }]

    function showAutoReport() {
        showReportToast();

        // Tarama geçmişine ekle
        scanHistory.push({
            time: now(),
            inactiveCount: Object.keys(trackerData).length,
            msgCount: Object.keys(messagedUsers).length,
            stillInactiveCount: Object.keys(stillInactiveAfterMsg).length,
            totalIdleMin: Object.values(trackerData).reduce((s, d) => s + d.totalInactiveMinutes, 0)
        });

        showDashboard();
    }

    function showReportToast() {
        if (Notification.permission === 'granted') {
            const totalStill = Object.keys(stillInactiveAfterMsg).length;
            new Notification('📊 IST2 Dashboard Güncellendi', {
                body: `Inactive: ${Object.keys(trackerData).length} | ⚠️ Hâlâ Inactive: ${totalStill}`,
                tag: 'itp-report',
                requireInteraction: false
            });
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission();
        }

        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = 800;
            gain.gain.value = 0.1;
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
        } catch (e) {}
    }

    function showDashboard() {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        const FLOOR_COLORS = {
            'P1': '#4fc3f7', 'P2': '#66bb6a', 'P3': '#ffa726',
            'P4': '#ef5350', 'P5': '#ab47bc', 'P6': '#26c6da', 'HRV': '#78909c', 'N/A': '#555'
        };

        // ===== Veri hazırlama =====
        const allEntries = Object.entries(trackerData);
        const totalInactive = allEntries.length;
        const totalMessaged = Object.keys(messagedUsers).length;
        const totalStillInactive = Object.keys(stillInactiveAfterMsg).length;
        const totalIdleMin = allEntries.reduce((s, [_, d]) => s + d.totalInactiveMinutes, 0);
        const avgIdleMin = totalInactive > 0 ? Math.round(totalIdleMin / totalInactive) : 0;

        // Kat bazlı dağılım
        const floorData = {};
        TRACKED_FLOORS.forEach(f => { floorData[f] = { count: 0, totalIdle: 0, messaged: 0, stillInactive: 0 }; });
        allEntries.forEach(([uid, d]) => {
            const f = d.floor;
            if (floorData[f]) {
                floorData[f].count++;
                floorData[f].totalIdle += d.totalInactiveMinutes;
                if (messagedUsers[uid]) floorData[f].messaged++;
                if (stillInactiveAfterMsg[uid]) floorData[f].stillInactive++;
            }
        });

        // Manager bazlı dağılım
        const managerData = {};
        allEntries.forEach(([uid, d]) => {
            const mgr = d.manager || 'Bilinmiyor';
            if (!managerData[mgr]) managerData[mgr] = { count: 0, totalIdle: 0, isPick: false, pickers: [] };
            managerData[mgr].count++;
            managerData[mgr].totalIdle += d.totalInactiveMinutes;
            managerData[mgr].isPick = PICK_MANAGERS.some(pm => mgr.toLowerCase().includes(pm.toLowerCase()));
            managerData[mgr].pickers.push({ userId: uid, name: d.name, idle: d.totalInactiveMinutes, floor: d.floor });
        });
        const managerEntries = Object.entries(managerData).sort((a, b) => b[1].totalIdle - a[1].totalIdle);
        const maxMgrIdle = managerEntries.length > 0 ? Math.max(...managerEntries.map(([_,d]) => d.totalIdle), 1) : 1;

        // Bizim ekip vs. diğer bölüm özet
        let pickTeamIdle = 0, pickTeamCount = 0, otherTeamIdle = 0, otherTeamCount = 0;
        managerEntries.forEach(([mgr, d]) => {
            if (d.isPick) { pickTeamIdle += d.totalIdle; pickTeamCount += d.count; }
            else { otherTeamIdle += d.totalIdle; otherTeamCount += d.count; }
        });

        // Kat değişimi istatistikleri
        const totalFloorChanges = Object.values(floorChanges).reduce((s, arr) => s + arr.length, 0);
        const totalFloorChangeMin = allEntries.reduce((s, [_, d]) => s + (d.floorChangeMinutes || 0), 0);
        const floorChangeUsers = Object.keys(floorChanges).length;

        // Top 5 idle picker
        const top5 = [...allEntries]
            .sort((a, b) => b[1].totalInactiveMinutes - a[1].totalInactiveMinutes)
            .slice(0, 5);

        // Maksimum değerler (grafik ölçekleme)
        const maxFloorCount = Math.max(...Object.values(floorData).map(f => f.count), 1);
        const maxFloorIdle = Math.max(...Object.values(floorData).map(f => f.totalIdle), 1);
        const maxTopIdle = top5.length > 0 ? top5[0][1].totalInactiveMinutes : 1;

        // ===== KAT BAR CHART HTML =====
        function renderFloorBarChart() {
            return TRACKED_FLOORS.map(f => {
                const d = floorData[f];
                const barW = Math.round((d.count / maxFloorCount) * 100);
                const color = FLOOR_COLORS[f] || '#888';
                return `
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                        <span style="width:32px; font-weight:700; color:${color}; font-size:12px;">${f}</span>
                        <div style="flex:1; background:rgba(255,255,255,0.06); border-radius:6px; height:24px; position:relative; overflow:hidden;">
                            <div style="width:${barW}%; height:100%; background:${color}; border-radius:6px; transition:width 0.5s;"></div>
                            <span style="position:absolute; right:8px; top:3px; font-size:11px; font-weight:600;">${d.count} kişi</span>
                </div>
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val" style="color:#29b6f6">${totalFloorChanges}</div>
                    <div class="itp-dash-kpi-label">🔄 Kat Değişimi</div>
                </div>
                        <span style="width:60px; text-align:right; font-size:11px; color:#aaa;">${formatMinutes(d.totalIdle)}</span>
                    </div>`;
            }).join('');
        }

        // ===== KAT IDLE BAR CHART =====
        function renderFloorIdleChart() {
            return TRACKED_FLOORS.map(f => {
                const d = floorData[f];
                const barW = Math.round((d.totalIdle / maxFloorIdle) * 100);
                const color = FLOOR_COLORS[f] || '#888';
                return `
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                        <span style="width:32px; font-weight:700; color:${color}; font-size:12px;">${f}</span>
                        <div style="flex:1; background:rgba(255,255,255,0.06); border-radius:6px; height:24px; position:relative; overflow:hidden;">
                            <div style="width:${barW}%; height:100%; background:linear-gradient(90deg, ${color}, ${color}88); border-radius:6px; transition:width 0.5s;"></div>
                            <span style="position:absolute; right:8px; top:3px; font-size:11px; font-weight:600;">${formatMinutes(d.totalIdle)}</span>
                        </div>
                    </div>`;
            }).join('');
        }

        // ===== MANAGER BAR CHART =====
        function renderManagerChart() {
            if (managerEntries.length === 0) return '<p style="color:#888; text-align:center;">Henüz veri yok</p>';
            const MGR_COLORS = { pick: '#4caf50', other: '#ff5722' };
            return managerEntries.map(([mgr, d]) => {
                const barW = Math.round((d.totalIdle / maxMgrIdle) * 100);
                const isPick = d.isPick;
                const color = isPick ? MGR_COLORS.pick : MGR_COLORS.other;
                // MANAGER_LABELS'dan etiket al, yoksa otomatik belirle
                const matchedKey = Object.keys(MANAGER_LABELS).find(k => mgr.toLowerCase().includes(k.toLowerCase()));
                const label = matchedKey ? MANAGER_LABELS[matchedKey] : (isPick ? '🟢 Pick' : '🔶 Diğer');
                const displayName = mgr.length > 22 ? mgr.slice(0, 22) + '…' : mgr;
                return `
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                        <span style="width:140px; font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${mgr}">${displayName}</span>
                        <div style="flex:1; background:rgba(255,255,255,0.06); border-radius:6px; height:24px; position:relative; overflow:hidden;">
                            <div style="width:${barW}%; height:100%; background:${color}; border-radius:6px; transition:width 0.5s;"></div>
                            <span style="position:absolute; right:8px; top:3px; font-size:11px; font-weight:600;">${formatMinutes(d.totalIdle)}</span>
                        </div>
                        <span style="width:50px; text-align:right; font-size:10px; color:#aaa;">${d.count} kişi</span>
                        <span style="font-size:9px; color:${color}; width:50px;">${label}</span>
                    </div>`;
            }).join('');
        }

        // ===== BİZİM EKİP vs DİĞER BÖLÜM DONUT =====
        function renderTeamDonut() {
            const total = pickTeamCount + otherTeamCount || 1;
            const pPick = (pickTeamCount / total) * 100;
            return `
                <div style="display:flex; align-items:center; gap:16px; justify-content:center;">
                    <div style="width:110px; height:110px; border-radius:50%; background:conic-gradient(
                        #4caf50 0% ${pPick}%,
                        #ff5722 ${pPick}% 100%
                    ); display:flex; align-items:center; justify-content:center;">
                        <div style="width:65px; height:65px; border-radius:50%; background:#1a1a2e; display:flex; align-items:center; justify-content:center;">
                            <span style="font-size:18px; font-weight:700; color:#ff9800;">${pickTeamCount + otherTeamCount}</span>
                        </div>
                    </div>
                    <div style="font-size:11px;">
                        <div style="margin-bottom:8px;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#4caf50; margin-right:6px;"></span>🟢 Pick Ekibi: <b>${pickTeamCount}</b> kişi / <b>${formatMinutes(pickTeamIdle)}</b></div>
                        <div><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#ff5722; margin-right:6px;"></span>🔶 Diğer Bölüm: <b>${otherTeamCount}</b> kişi / <b>${formatMinutes(otherTeamIdle)}</b></div>
                    </div>
                </div>`;
        }

        // ===== TOP 5 PICKER BAR CHART =====
        function renderTop5Chart() {
            if (top5.length === 0) return '<p style="color:#888; text-align:center; padding:12px;">Henüz veri yok</p>';
            return top5.map(([uid, d], i) => {
                const barW = Math.round((d.totalInactiveMinutes / maxTopIdle) * 100);
                const color = FLOOR_COLORS[d.floor] || '#ff9800';
                const isWarned = !!stillInactiveAfterMsg[uid];
                const warnIcon = isWarned ? ' ⚠️' : '';
                const displayName = d.name.length > 20 ? d.name.slice(0, 20) + '…' : d.name;
                return `
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                        <span style="width:18px; font-weight:700; color:#ff9800; font-size:12px;">${i + 1}</span>
                        <span style="width:140px; font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:flex; align-items:center; gap:4px;" title="${d.name}">${badgeImg(uid, 22)} ${displayName}${warnIcon}</span>
                        <div style="flex:1; background:rgba(255,255,255,0.06); border-radius:6px; height:22px; position:relative; overflow:hidden;">
                            <div style="width:${barW}%; height:100%; background:${color}; border-radius:6px;"></div>
                            <span style="position:absolute; right:8px; top:2px; font-size:11px; font-weight:600;">${formatMinutes(d.totalInactiveMinutes)}</span>
                        </div>
                        <span style="width:28px; font-size:10px; color:${FLOOR_COLORS[d.floor] || '#aaa'}; font-weight:700;">${d.floor}</span>
                    </div>`;
            }).join('');
        }

        // ===== DONUT CHART (Mesaj durumu) =====
        function renderDonutChart() {
            const noMsg = totalInactive - totalMessaged;
            const cleared = totalMessaged - totalStillInactive;
            const still = totalStillInactive;
            const total = totalInactive || 1;

            const pNoMsg = (noMsg / total) * 100;
            const pCleared = (cleared / total) * 100;
            const pStill = (still / total) * 100;

            const seg1End = pNoMsg;
            const seg2End = seg1End + pCleared;

            return `
                <div style="display:flex; align-items:center; gap:16px; justify-content:center;">
                    <div style="width:120px; height:120px; border-radius:50%; background:conic-gradient(
                        #607d8b 0% ${seg1End}%,
                        #4caf50 ${seg1End}% ${seg2End}%,
                        #e91e63 ${seg2End}% 100%
                    ); display:flex; align-items:center; justify-content:center;">
                        <div style="width:70px; height:70px; border-radius:50%; background:#1a1a2e; display:flex; align-items:center; justify-content:center;">
                            <span style="font-size:20px; font-weight:700; color:#ff9800;">${totalInactive}</span>
                        </div>
                    </div>
                    <div style="font-size:11px;">
                        <div style="margin-bottom:6px;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#607d8b; margin-right:6px;"></span>Mesaj yok: <b>${noMsg}</b></div>
                        <div style="margin-bottom:6px;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#4caf50; margin-right:6px;"></span>Mesaj → Aktif: <b>${cleared}</b></div>
                        <div><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#e91e63; margin-right:6px;"></span>Mesaja Rağmen ⚠️: <b>${still}</b></div>
                    </div>
                </div>`;
        }

        // ===== TIMELINE CHART =====
        function renderTimeline() {
            if (scanHistory.length < 2) return '<p style="color:#888; text-align:center; padding:12px; font-size:11px;">Henüz yeterli veri yok (2. güncelleme sonrası görünür)</p>';

            const maxVal = Math.max(...scanHistory.map(s => s.inactiveCount), 1);
            const chartH = 80;
            const points = scanHistory.map((s, i) => {
                const x = (i / (scanHistory.length - 1)) * 100;
                const y = chartH - (s.inactiveCount / maxVal) * chartH;
                return `${x},${y}`;
            }).join(' ');

            const stillPoints = scanHistory.map((s, i) => {
                const x = (i / (scanHistory.length - 1)) * 100;
                const y = chartH - (s.stillInactiveCount / maxVal) * chartH;
                return `${x},${y}`;
            }).join(' ');

            const labels = scanHistory.map((s, i) => {
                const x = (i / (scanHistory.length - 1)) * 100;
                return `<text x="${x}%" y="${chartH + 14}" font-size="9" fill="#888" text-anchor="middle">${timeStr(s.time).slice(0, 5)}</text>`;
            }).join('');

            return `
                <svg viewBox="-2 -5 104 ${chartH + 20}" width="100%" height="${chartH + 30}" style="overflow:visible;">
                    <polyline points="${points}" fill="none" stroke="#ff9800" stroke-width="2" stroke-linejoin="round"/>
                    <polyline points="${stillPoints}" fill="none" stroke="#e91e63" stroke-width="1.5" stroke-dasharray="4,3" stroke-linejoin="round"/>
                    ${scanHistory.map((s, i) => {
                        const x = (i / (scanHistory.length - 1)) * 100;
                        const y = chartH - (s.inactiveCount / maxVal) * chartH;
                        return `<circle cx="${x}%" cy="${y}" r="3" fill="#ff9800"/>`;
                    }).join('')}
                    ${labels}
                </svg>
                <div style="display:flex; gap:16px; justify-content:center; margin-top:4px; font-size:10px; color:#aaa;">
                    <span><span style="color:#ff9800;">━━</span> Inactive</span>
                    <span><span style="color:#e91e63;">╌╌</span> Mesaja Rağmen</span>
                </div>`;
        }

        // ===== HÂLÂ INACTIVE LİSTESİ =====
        function renderStillInactiveList() {
            const entries = Object.entries(stillInactiveAfterMsg).sort((a, b) => b[1].idleSinceMsg - a[1].idleSinceMsg);
            if (entries.length === 0) return '<p style="color:#4caf50; text-align:center; padding:12px; font-size:12px;">✅ Mesaja rağmen inactive yok!</p>';

            return entries.slice(0, 8).map(([uid, d]) => {
                const color = FLOOR_COLORS[d.floor] || '#aaa';
                return `
                    <div style="display:flex; align-items:center; gap:8px; padding:6px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                        <span style="width:28px; font-size:10px; color:${color}; font-weight:700;">${d.floor}</span>
                        <span style="flex:1; font-size:11px; display:flex; align-items:center; gap:4px;">${badgeImg(uid, 22)} ${d.name} <span style="color:#888;">(${uid})</span></span>
                        <span style="font-size:11px; color:#e91e63; font-weight:700;">+${formatMinutes(d.idleSinceMsg)}</span>
                    </div>`;
            }).join('') + (entries.length > 8 ? `<p style="color:#888; font-size:10px; text-align:center; margin-top:4px;">...ve ${entries.length - 8} kişi daha</p>` : '');
        }

        // ===== MODAL OLUŞTUR =====
        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.style.minWidth = '900px';
        modal.style.maxWidth = '95vw';

        modal.innerHTML = `
            <style>
                .itp-dash-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
                .itp-dash-card {
                    background: rgba(255,255,255,0.03); border-radius: 12px; padding: 16px;
                    border: 1px solid rgba(255,255,255,0.06);
                }
                .itp-dash-card h3 {
                    font-size: 13px; font-weight: 700; color: #ff9800; margin: 0 0 12px 0;
                    display: flex; align-items: center; gap: 6px;
                }
                .itp-dash-kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 16px; }
                .itp-dash-kpi {
                    background: rgba(255,255,255,0.04); border-radius: 10px; padding: 12px 8px;
                    text-align: center; border: 1px solid rgba(255,255,255,0.06);
                }
                .itp-dash-kpi-val { font-size: 24px; font-weight: 800; color: #ff9800; }
                .itp-dash-kpi-label { font-size: 10px; color: #999; margin-top: 4px; }
                .itp-dash-full { grid-column: 1 / -1; }
            </style>
            <button class="itp-close-btn" id="itp-close-modal">✕</button>
            <h2>📊 IST2 Inactive Dashboard</h2>
            <div class="itp-summary-info">
                Shift: ${shiftLabel()} | Tarama: ${scanCount} | Son Güncelleme: ${timeStr(now())} | ${new Date().toLocaleDateString('tr-TR')}
            </div>
            <!-- KPI KARTLARI -->
            <div class="itp-dash-kpis">
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val">${totalInactive}</div>
                    <div class="itp-dash-kpi-label">Inactive Picker</div>
                </div>
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val">${formatMinutes(totalIdleMin)}</div>
                    <div class="itp-dash-kpi-label">Toplam Idle</div>
                </div>
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val">${formatMinutes(avgIdleMin)}</div>
                    <div class="itp-dash-kpi-label">Ort. Idle / Kişi</div>
                </div>
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val" style="color:#2196f3">${totalMessaged}</div>
                    <div class="itp-dash-kpi-label">📩 Mesaj Gönderildi</div>
                </div>
                <div class="itp-dash-kpi">
                    <div class="itp-dash-kpi-val" style="color:#e91e63">${totalStillInactive}</div>
                    <div class="itp-dash-kpi-label">⚠️ Hâlâ Inactive</div>
                </div>
            </div>
            <!-- GRAFİK GRID -->
            <div class="itp-dash-grid">
                <!-- Kat Bazlı Inactive Sayısı -->
                <div class="itp-dash-card">
                    <h3>🏢 Kat Bazlı Inactive Sayısı</h3>
                    ${renderFloorBarChart()}
                </div>
                <!-- Kat Bazlı Toplam Idle -->
                <div class="itp-dash-card">
                    <h3>⏱ Kat Bazlı Toplam Idle Süresi</h3>
                    ${renderFloorIdleChart()}
                </div>
                <!-- Top 5 Idle Picker -->
                <div class="itp-dash-card">
                    <h3>🏆 En Çok Idle Yapan 5 Picker</h3>
                    ${renderTop5Chart()}
                </div>
                <!-- Mesaj Durumu Donut -->
                <div class="itp-dash-card">
                    <h3>📩 Mesaj Durumu Dağılımı</h3>
                    ${renderDonutChart()}
                </div>
                <!-- Manager Bazlı Idle -->
                <div class="itp-dash-card itp-dash-full">
                    <h3>👔 Manager Bazlı Idle Süresi</h3>
                    ${renderManagerChart()}
                </div>

                <!-- Bizim Ekip vs Diğer Bölüm -->
                <div class="itp-dash-card">
                    <h3>🏭 Pick Ekibi vs Diğer Bölüm</h3>
                    ${renderTeamDonut()}
                </div>

                <!-- Diğer Bölüm Detay -->
                <div class="itp-dash-card">
                    <h3>🔶 Diğer Bölümden Gelenler</h3>
                    ${managerEntries.filter(([_,d]) => !d.isPick).length === 0
                        ? '<p style="color:#4caf50; text-align:center; padding:12px;">✅ Diğer bölümden inactive yok</p>'
                        : managerEntries.filter(([_,d]) => !d.isPick).map(([mgr, d]) =>
                            '<div style="margin-bottom:8px; padding:8px; background:rgba(255,87,34,0.1); border-radius:8px; border-left:3px solid #ff5722;">' +
                            '<div style="font-weight:700; font-size:12px; color:#ff5722;">' + mgr + ' <span style="color:#aaa; font-weight:400;">(' + d.count + ' kişi — ' + formatMinutes(d.totalIdle) + ' idle)</span></div>' +
                            '<div style="font-size:10px; color:#ccc; margin-top:4px;">' +
                            d.pickers.map(p => badgeImg(p.userId, 18) + ' ' + p.name + ' (' + p.userId + ') ' + formatMinutes(p.idle)).join(' &nbsp;·&nbsp; ') +
                            '</div></div>'
                        ).join('')}
                </div>

                <!-- Kat Değişimleri -->
                <div class="itp-dash-card itp-dash-full">
                    <h3>🔄 Kat Değişimleri (Idle Sayılmadı: ${formatMinutes(totalFloorChangeMin)})</h3>
                    ${totalFloorChanges === 0
                        ? '<p style="color:#888; text-align:center; padding:12px;">Henüz kat değişimi tespit edilmedi</p>'
                        : '<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:8px;">' +
                          Object.entries(floorChanges).map(([uid, changes]) => {
                              const data = trackerData[uid];
                              const name = data ? data.name : uid;
                              return changes.map(c =>
                                  '<div style="padding:8px 12px; background:rgba(41,182,246,0.1); border-radius:8px; border-left:3px solid #29b6f6;">' +
                                  '<div style="font-weight:600; font-size:12px; color:#29b6f6; display:flex; align-items:center; gap:4px;">' + badgeImg(uid, 20) + ' ' + name +
                                  ' <span style="color:#888; font-weight:400;">(' + uid + ')</span></div>' +
                                  '<div style="font-size:11px; color:#ccc; margin-top:2px;">' +
                                  '<span style="color:#ff9800;">' + c.fromFloor + '</span> → <span style="color:#4caf50;">' + c.toFloor + '</span>' +
                                  ' | ' + timeStr(c.time) +
                                  '</div></div>'
                              ).join('');
                          }).join('') +
                          '</div>'
                    }
                </div>

                <!-- Timeline -->
                <div class="itp-dash-card itp-dash-full">
                    <h3>📈 Zaman Çizelgesi (Her 30dk)</h3>
                    ${renderTimeline()}
                </div>
                <!-- Mesaja Rağmen Inactive -->
                <div class="itp-dash-card itp-dash-full">
                    <h3>⚠️ Mesaja Rağmen Inactive Olanlar</h3>
                    ${renderStillInactiveList()}
                </div>
            </div>
            <div style="display:flex; gap:8px; margin-top:16px; justify-content:center;">
                <button class="itp-export-btn" id="itp-dash-table" style="background:#2196f3;">📋 Detay Tablo</button>
                <button class="itp-export-btn" id="itp-dash-csv">📥 CSV İndir</button>
                <button class="itp-export-btn" id="itp-dash-chart" style="background:#ff9800;">📊 Grafik İndir (PNG)</button>
                <button class="itp-export-btn" id="itp-dash-clipboard" style="background:#9c27b0;">📋 Panoya Kopyala</button>
            </div>
        `;

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        addLogEntry('📊', `Dashboard güncellendi: ${totalInactive} inactive, ${totalMessaged} mesaj, ${totalStillInactive} hâlâ inactive`);

        overlay.addEventListener('click', (e) => {
            if (e.target.id === 'itp-close-modal' || e.target === overlay) { overlay.remove(); return; }
            if (e.target.id === 'itp-dash-table') { overlay.remove(); showSummary(); }
            if (e.target.id === 'itp-dash-csv') exportCSV('ALL', 'all');
            if (e.target.id === 'itp-dash-chart') exportChartAsPNG();
            if (e.target.id === 'itp-dash-clipboard') copyToClipboard('ALL', 'all');
        });
    }

    // ==================== AUTO-REFRESH (Sayfa Yenileme) ====================
    const STORAGE_KEY = 'itp_tracker_data_v2';

    // ==================== HAFTALIK GECMIS (7 GUNLUK ARSIV) ====================
    // Gun degisince (loadStateFromStorage'daki tarih kontrolu) canli veri silinmeden
    // once gunun ozeti bu arsive eklenir. Arsiv 7 gunden eski kayitlari otomatik atar.
    const DAILY_ARCHIVE_KEY = 'itp_daily_archive_v1';
    const ARCHIVE_RETENTION_DAYS = 7;

    function loadDailyArchive() {
        try {
            const raw = localStorage.getItem(DAILY_ARCHIVE_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            console.error('[ITP] arsiv okuma hatasi:', e);
            return [];
        }
    }

    function pruneDailyArchive(archive) {
        const cutoff = Date.now() - ARCHIVE_RETENTION_DAYS * 24 * 60 * 60 * 1000;
        return archive.filter(day => day.savedAt >= cutoff);
    }

    // Eski (bugun olmayan) state objesinden kompakt bir gunluk ozet cikarir.
    // Tum snapshot/periyot detayini degil, kisi bazli toplamlari tutar — 7 gunluk
    // arsiv localStorage'i sismesin.
    function buildDaySummaryFromState(state) {
        const dateStr = new Date(state.savedAt).toLocaleDateString('tr-TR');
        const pickers = Object.entries(state.trackerData || {}).map(([uid, d]) => ({
            userId: uid,
            name: d.name || uid,
            floor: d.floor || 'N/A',
            manager: d.manager || '',
            totalInactiveMinutes: d.totalInactiveMinutes || 0,
            msgSent: !!(state.messagedUsers && state.messagedUsers[uid])
        })).sort((a, b) => b.totalInactiveMinutes - a.totalInactiveMinutes);

        return {
            date: dateStr,
            savedAt: state.savedAt,
            scanCount: state.scanCount || 0,
            msgSentCount: state.messagedUsers ? Object.keys(state.messagedUsers).length : 0,
            totalIdleMin: pickers.reduce((s, p) => s + p.totalInactiveMinutes, 0),
            pickers
        };
    }

    function archiveDay(state) {
        try {
            if (!state || !state.trackerData || Object.keys(state.trackerData).length === 0) return;
            const summary = buildDaySummaryFromState(state);
            let archive = loadDailyArchive();
            // Ayni gun icin birden fazla kayit birikmesin (ayni tarihli varsa guncelle)
            archive = archive.filter(day => day.date !== summary.date);
            archive.push(summary);
            archive = pruneDailyArchive(archive);
            localStorage.setItem(DAILY_ARCHIVE_KEY, JSON.stringify(archive));
            console.log(`[ITP] ${summary.date} gunu arsivlendi (${summary.pickers.length} kisi, ${summary.totalIdleMin} dk toplam idle). Arsivde ${archive.length} gun var.`);
        } catch (e) {
            console.error('[ITP] gunluk arsivleme hatasi:', e);
        }
    }


    function saveStateToStorage() {
        if (standDown) return; // v2.33: eski kopya veriyi bozmasin
        try {
            const state = {
                trackerData: {},
                messagedUsers: {},
                stillInactiveAfterMsg: {},
                scanCount,
                scanHistory,
                floorChanges: (() => {
                    const fc = {};
                    Object.entries(floorChanges).forEach(([uid, arr]) => {
                        fc[uid] = arr.map(c => ({ ...c, time: c.time.getTime() }));
                    });
                    return fc;
                })(),
                enabledMsgFloors: [...enabledMsgFloors],
                autoRefreshEnabled,
                autoMessageEnabled,
                autoRefreshIntervalMs,
                isTracking,
                breakWindows: breakWindows.map(function (w) { return { start: w.start.getTime(), end: w.end.getTime(), auto: !!w.auto }; }),
                autoBreakSeededFor,
                maxBreakMinutesPerPerson,
                minBreakBlockMinutes,
                floorChangeForgiveMin,
                breakRuleV: 3,
                savedAt: Date.now()
            };
            // trackerData — Date nesnelerini stringe çevir
            Object.entries(trackerData).forEach(([uid, d]) => {
                state.trackerData[uid] = {
                    ...d,
                    firstInactiveSeen: d.firstInactiveSeen ? d.firstInactiveSeen.getTime() : null,
                    snapshots: d.snapshots.map(s => ({ ...s, time: s.time.getTime() }))
                };
            });
            Object.entries(messagedUsers).forEach(([uid, d]) => {
                state.messagedUsers[uid] = { ...d, sentAt: d.sentAt.getTime() };
            });
            Object.entries(stillInactiveAfterMsg).forEach(([uid, d]) => {
                state.stillInactiveAfterMsg[uid] = {
                    ...d,
                    msgSentAt: d.msgSentAt.getTime(),
                    checkedAt: d.checkedAt.getTime()
                };
            });
            state.scanHistory = scanHistory.map(s => ({ ...s, time: s.time.getTime() }));
            localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        } catch (e) {
            console.error('[ITP] localStorage kayıt hatası:', e);
        }
    }

    function loadStateFromStorage() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return false;
            const state = JSON.parse(raw);

            // Bugünün verisi mi kontrol et (shift bazlı)
            const savedDate = new Date(state.savedAt);
            const today = new Date();
            if (savedDate.toDateString() !== today.toDateString()) {
                // Gun degisti: canli veriyi silmeden once gunun ozetini 7 gunluk arsive kaydet
                archiveDay(state);
                localStorage.removeItem(STORAGE_KEY);
                return false;
            }

            // Geri yükle
            scanCount = state.scanCount || 0;
            enabledMsgFloors = new Set(state.enabledMsgFloors || TRACKED_FLOORS);
            autoRefreshEnabled = state.autoRefreshEnabled || false;
            autoMessageEnabled = state.autoMessageEnabled !== undefined ? state.autoMessageEnabled : false;
            autoRefreshIntervalMs = state.autoRefreshIntervalMs || AUTO_REFRESH_DEFAULT_MS;
            isTracking = state.isTracking || false;
            // v2.44 tek seferlik gecis: vardiya molalari 40 dk yemek + 20 dk cay = 60 dk.
            // Kisi basi 40 dk limit kalirsa cay molasi sessizce dusulmuyordu.
            if (state.breakRuleV === 3) {
                maxBreakMinutesPerPerson = state.maxBreakMinutesPerPerson !== undefined ? state.maxBreakMinutesPerPerson : 0;
                minBreakBlockMinutes = state.minBreakBlockMinutes !== undefined ? state.minBreakBlockMinutes : 0;
            } else {
                maxBreakMinutesPerPerson = 0;
                minBreakBlockMinutes = 0;
                console.log('[ITP] v2.44: mola kurallari sifirlandi (esik 0, limit sinirsiz) \u2014 ' +
                    'vardiya molalarinin (yemek 40 dk + cay 20 dk) tamami dusulebilsin diye.');
            }
            breakWindows = (state.breakWindows || []).map(function (w) {
                return { start: new Date(w.start), end: new Date(w.end), auto: !!w.auto };
            });
            floorChangeForgiveMin = state.floorChangeForgiveMin || 0;
            autoBreakSeededFor = state.autoBreakSeededFor || null;

            Object.entries(state.trackerData || {}).forEach(([uid, d]) => {
                trackerData[uid] = {
                    ...d,
                    firstInactiveSeen: d.firstInactiveSeen ? new Date(d.firstInactiveSeen) : null,
                    snapshots: (d.snapshots || []).map(s => ({ ...s, time: new Date(s.time) }))
                };
            });
            Object.entries(state.messagedUsers || {}).forEach(([uid, d]) => {
                messagedUsers[uid] = { ...d, sentAt: new Date(d.sentAt) };
            });
            Object.entries(state.stillInactiveAfterMsg || {}).forEach(([uid, d]) => {
                stillInactiveAfterMsg[uid] = {
                    ...d,
                    msgSentAt: new Date(d.msgSentAt),
                    checkedAt: new Date(d.checkedAt)
                };
            });
            scanHistory = (state.scanHistory || []).map(s => ({ ...s, time: new Date(s.time) }));

            // floorChanges geri yükle (time alanlarını Date'e çevir)
            floorChanges = {};
            Object.entries(state.floorChanges || {}).forEach(([uid, arr]) => {
                floorChanges[uid] = arr.map(c => ({
                    ...c,
                    time: new Date(c.time)
                }));
            });

            console.log(`[ITP] State yüklendi: ${scanCount} tarama, ${Object.keys(trackerData).length} picker`);
            return true;
        } catch (e) {
            console.error('[ITP] localStorage yükleme hatası:', e);
            return false;
        }
    }

    function startAutoRefresh() {
        autoRefreshEnabled = true;
        nextRefreshAt = Date.now() + autoRefreshIntervalMs;
        autoRefreshCountdown = Math.round(autoRefreshIntervalMs / 1000);
        saveStateToStorage();
        startKeepAlive();

        // v2.38: yenileme karari duvar saatinden verilir (bgTick). Buradaki
        // 1 sn'lik timer SADECE ekrandaki geri sayimi gosterir; arka planda
        // kisilsa bile yenileme zamaninda yapilir.
        countdownTimer = setInterval(() => {
            autoRefreshCountdown = Math.max(0, Math.round((nextRefreshAt - Date.now()) / 1000));
            updateRefreshCountdown();
            if (Date.now() >= nextRefreshAt) {
                saveStateToStorage();
                location.reload();
            }
        }, 1000);
    }

    function stopAutoRefresh() {
        autoRefreshEnabled = false;
        nextRefreshAt = 0;
        if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
        autoRefreshCountdown = 0;
        updateRefreshCountdown();
    }

    function resetData() {
        trackerData = {};
        messagedUsers = {};
        stillInactiveAfterMsg = {};
        floorChanges = {};
        scanCount = 0;
        lastScanTime = null;
        activityLog = [];
        updatePanel();
    }

    // ==================== ACTIVITY LOG ====================
    let activityLog = [];
    function addLogEntry(icon, text) {
        activityLog.push({ time: now(), icon, text });
        if (activityLog.length > 100) activityLog.shift();
    }

    // ==================== SUMMARY ====================
    function generateSummary(floorFilter = 'ALL') {
        let entries = Object.entries(trackerData).filter(([_, data]) => TRACKED_FLOORS.includes(data.floor));
        if (floorFilter !== 'ALL') {
            entries = entries.filter(([_, data]) => data.floor === floorFilter);
        }
        entries.sort((a, b) => b[1].totalInactiveMinutes - a[1].totalInactiveMinutes);

        return entries.map(([userId, data]) => {
            let topLocation = 'N/A';
            let topLocationMin = 0;
            Object.entries(data.locationCounts).forEach(([loc, mins]) => {
                if (mins > topLocationMin) { topLocation = loc; topLocationMin = mins; }
            });

            const wasMessaged = !!messagedUsers[userId];
            const stillInactive = !!stillInactiveAfterMsg[userId];

            return {
                userId,
                name: data.name,
                floor: data.floor,
                manager: data.manager || 'Bilinmiyor',
                totalInactiveMinutes: data.totalInactiveMinutes,
                totalInactiveFormatted: formatMinutes(data.totalInactiveMinutes),
                topLocation,
                topLocationMinutes: topLocationMin,
                topLocationFormatted: formatMinutes(topLocationMin),
                snapshotCount: data.snapshots.length,
                allLocations: { ...data.locationCounts },
                floorChangeMinutes: data.floorChangeMinutes || 0,
                floorChangeCount: (floorChanges[userId] || []).length,
                floorIdle: computeFloorIdle(userId),
                floorIdleShort: floorIdleShort(userId),
                wasMessaged,
                stillInactive,
                readyForMessage: data.readyForMessage || false,
                msgSentAt: messagedUsers[userId]?.sentAt || null,
                idleSinceMsg: stillInactiveAfterMsg[userId]?.idleSinceMsg || 0
            };
        });
    }

    // ==================== UI: CONTROL PANEL ====================
    function createPanel() {
        const panel = document.createElement('div');
        panel.id = 'inactive-tracker-panel';
        panel.innerHTML = `
            <style>
                #inactive-tracker-panel {
                    position: fixed;
                    top: 10px;
                    right: 10px;
                    z-index: 99999;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: #e0e0e0;
                    border-radius: 12px;
                    padding: 16px;
                    min-width: 320px;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
                    font-family: 'Amazon Ember', Arial, sans-serif;
                    font-size: 13px;
                    border: 1px solid rgba(255,255,255,0.1);
                }
                #inactive-tracker-panel .itp-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 12px;
                    padding-bottom: 8px;
                    border-bottom: 1px solid rgba(255,255,255,0.15);
                    cursor: move;
                    user-select: none;
                }
                #inactive-tracker-panel .itp-title { font-size: 14px; font-weight: 700; color: #ff9800; }
                #inactive-tracker-panel .itp-status { font-size: 11px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
                #inactive-tracker-panel .itp-status.active { background: #4caf50; color: white; }
                #inactive-tracker-panel .itp-status.stopped { background: #f44336; color: white; }
                #inactive-tracker-panel .itp-stats { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-bottom: 12px; }
                #inactive-tracker-panel .itp-stat { background: rgba(255,255,255,0.05); padding: 8px; border-radius: 8px; text-align: center; }
                #inactive-tracker-panel .itp-stat-value { font-size: 18px; font-weight: 700; color: #ff9800; }
                #inactive-tracker-panel .itp-stat-label { font-size: 10px; color: #aaa; margin-top: 2px; }
                #inactive-tracker-panel .itp-buttons { display: flex; gap: 6px; flex-wrap: wrap; }
                #inactive-tracker-panel .itp-btn {
                    flex: 1; padding: 7px 10px; border: none; border-radius: 8px;
                    cursor: pointer; font-size: 11px; font-weight: 600; transition: all 0.2s; min-width: 60px;
                }
                #inactive-tracker-panel .itp-btn:hover { opacity: 0.85; transform: translateY(-1px); }
                #inactive-tracker-panel .itp-btn.start { background: #4caf50; color: white; }
                #inactive-tracker-panel .itp-btn.stop { background: #f44336; color: white; }
                #inactive-tracker-panel .itp-btn.summary { background: #2196f3; color: white; }
                #inactive-tracker-panel .itp-btn.warn-report { background: #e91e63; color: white; }
                #inactive-tracker-panel .itp-btn.reset { background: #607d8b; color: white; }
                #inactive-tracker-panel .itp-btn.minimize { background: transparent; color: #aaa; font-size: 16px; min-width: 30px; flex: 0; padding: 4px 8px; }
                #inactive-tracker-panel .itp-last-scan { font-size: 10px; color: #888; margin-top: 8px; text-align: center; }
                #inactive-tracker-panel .itp-floor-toggles {
                    display: flex; gap: 4px; flex-wrap: wrap; margin: 8px 0;
                    padding: 8px; background: rgba(255,255,255,0.03); border-radius: 8px;
                }
                #inactive-tracker-panel .itp-floor-toggle {
                    padding: 4px 10px; border-radius: 12px; font-size: 10px; font-weight: 600;
                    cursor: pointer; border: 1px solid #ff9800; transition: all 0.2s;
                }
                #inactive-tracker-panel .itp-floor-toggle.on { background: #ff9800; color: #1a1a2e; }
                #inactive-tracker-panel .itp-floor-toggle.off { background: transparent; color: #666; border-color: #444; }
                #inactive-tracker-panel .itp-section-label { font-size: 10px; color: #888; margin-bottom: 4px; }
                #inactive-tracker-panel .itp-refresh-bar {
                    display: flex; gap: 6px; align-items: center; margin: 8px 0;
                    padding: 8px; background: rgba(255,255,255,0.03); border-radius: 8px;
                }
                #inactive-tracker-panel .itp-refresh-toggle {
                    position: relative; width: 36px; height: 20px; background: #444; border-radius: 10px;
                    cursor: pointer; transition: background 0.3s; flex-shrink: 0;
                }
                #inactive-tracker-panel .itp-refresh-toggle.on { background: #4caf50; }
                #inactive-tracker-panel .itp-refresh-toggle .itp-toggle-knob {
                    position: absolute; top: 2px; left: 2px; width: 16px; height: 16px;
                    background: white; border-radius: 50%; transition: left 0.3s;
                }
                #inactive-tracker-panel .itp-refresh-toggle.on .itp-toggle-knob { left: 18px; }
                #inactive-tracker-panel .itp-refresh-select { background: #2a2a4a; color: #e0e0e0; border: 1px solid #444; border-radius: 6px; padding: 3px 6px; font-size: 11px; }
                #inactive-tracker-panel .itp-countdown { font-size: 11px; color: #ff9800; font-weight: 700; min-width: 36px; text-align: center; }

                /* ========= SUMMARY MODAL ========= */
                .itp-overlay {
                    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
                    background: rgba(0,0,0,0.7); z-index: 100000;
                    display: flex; justify-content: center; align-items: center;
                }
                .itp-modal {
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: #e0e0e0; border-radius: 16px; padding: 24px;
                    max-width: 92vw; max-height: 85vh; overflow-y: auto;
                    box-shadow: 0 16px 64px rgba(0,0,0,0.6);
                    font-family: 'Amazon Ember', Arial, sans-serif;
                    border: 1px solid rgba(255,255,255,0.1); min-width: 750px;
                    position: relative;
                }
                .itp-modal h2 { color: #ff9800; margin: 0 0 8px 0; font-size: 20px; }
                .itp-modal .itp-summary-info { color: #aaa; font-size: 12px; margin-bottom: 16px; }
                .itp-modal .itp-filter-bar { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }
                .itp-modal .itp-floor-btn {
                    padding: 6px 16px; border: 2px solid #ff9800; background: transparent;
                    color: #ff9800; border-radius: 20px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.2s;
                }
                .itp-modal .itp-floor-btn.active { background: #ff9800; color: #1a1a2e; }
                .itp-modal .itp-floor-btn:hover { opacity: 0.8; }
                .itp-modal table { width: 100%; border-collapse: collapse; margin-top: 8px; }
                .itp-modal th {
                    background: rgba(255,152,0,0.2); color: #ff9800; padding: 10px 12px;
                    text-align: left; font-size: 12px; font-weight: 700; border-bottom: 2px solid rgba(255,152,0,0.3);
                }
                .itp-modal td { padding: 8px 12px; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 12px; }
                .itp-modal tr:hover td { background: rgba(255,255,255,0.05); }
                .itp-idle-high { color: #f44336; font-weight: 700; }
                .itp-idle-medium { color: #ff9800; font-weight: 600; }
                .itp-idle-low { color: #4caf50; }
                .itp-modal .itp-close-btn {
                    position: absolute; top: 16px; right: 20px; background: #f44336; color: white;
                    border: none; border-radius: 50%; width: 32px; height: 32px; font-size: 18px;
                    cursor: pointer; display: flex; align-items: center; justify-content: center;
                }
                .itp-modal .itp-export-btn {
                    padding: 8px 20px; background: #4caf50; color: white; border: none;
                    border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; margin-top: 12px;
                }
                .itp-modal .itp-export-btn:hover { opacity: 0.85; }
                .itp-modal .itp-totals { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 16px; }
                .itp-modal .itp-total-card { background: rgba(255,255,255,0.05); border-radius: 10px; padding: 12px; text-align: center; }
                .itp-modal .itp-total-value { font-size: 22px; font-weight: 700; color: #ff9800; }
                .itp-modal .itp-total-label { font-size: 10px; color: #aaa; margin-top: 4px; }
                .itp-modal .itp-tab-bar { display: flex; gap: 0; margin-bottom: 16px; }
                .itp-modal .itp-tab {
                    padding: 10px 20px; cursor: pointer; font-weight: 600; font-size: 13px;
                    border-bottom: 3px solid transparent; color: #888; transition: all 0.2s;
                }
                .itp-modal .itp-tab.active { color: #ff9800; border-bottom-color: #ff9800; }
                .itp-modal .itp-tab:hover { color: #fff; }
                .itp-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; }
                .itp-badge.sent { background: #2196f3; color: white; }
                .itp-badge.still { background: #e91e63; color: white; }
                .itp-badge.cleared { background: #4caf50; color: white; }
            </style>
            <div class="itp-header">
                <span class="itp-title">🔍 Inactive Tracker v2</span>
                <span>
                    <span id="itp-status" class="itp-status stopped">Durdu</span>
                    <button id="itp-minimize" class="itp-btn minimize">−</button>
                </span>
            </div>
            <div id="itp-body">
                <div class="itp-stats">
                    <div class="itp-stat">
                        <div class="itp-stat-value" id="itp-scan-count">0</div>
                        <div class="itp-stat-label">Tarama</div>
                    </div>
                    <div class="itp-stat">
                        <div class="itp-stat-value" id="itp-inactive-count">0</div>
                        <div class="itp-stat-label">Inactive</div>
                    </div>
                    <div class="itp-stat">
                        <div class="itp-stat-value" id="itp-msg-count">0</div>
                        <div class="itp-stat-label">Mesaj Atıldı</div>
                    </div>
                </div>
                <div class="itp-section-label">📩 Otomatik FANS Mesajı:</div>
                <div class="itp-refresh-bar">
                    <div class="itp-refresh-toggle ${autoMessageEnabled ? 'on' : ''}" id="itp-automsg-toggle">
                        <div class="itp-toggle-knob"></div>
                    </div>
                    <span style="font-size:11px; color:${autoMessageEnabled ? '#4caf50' : '#888'};" id="itp-automsg-label">${autoMessageEnabled ? '✅ Açık — 10dk+ inactive olana otomatik mesaj gider' : '⏸ Kapalı — sadece manuel butonla'}</span>
                </div>
                <div class="itp-section-label">📩 Mesaj Gönderilecek Katlar:</div>
                <div class="itp-floor-toggles" id="itp-floor-toggles"></div>
                <div class="itp-section-label">🔄 Otomatik Sayfa Yenileme:</div>
                <div class="itp-refresh-bar">
                    <div class="itp-refresh-toggle" id="itp-refresh-toggle">
                        <div class="itp-toggle-knob"></div>
                    </div>
                    <select class="itp-refresh-select" id="itp-refresh-interval">
                        <option value="30">30 sn</option>
                        <option value="60" selected>60 sn</option>
                        <option value="120">2 dk</option>
                        <option value="180">3 dk</option>
                        <option value="300">5 dk</option>
                    </select>
                    <span class="itp-countdown" id="itp-countdown">—</span>
                </div>
                <div class="itp-buttons">
                    <button id="itp-start" class="itp-btn start">▶ Başlat</button>
                    <button id="itp-stop" class="itp-btn stop" style="display:none">⏹ Durdur</button>
                    <button id="itp-summary-btn" class="itp-btn summary">📊 Dashboard</button>
                    <button id="itp-warn-btn" class="itp-btn warn-report">⚠️ Uyarı Raporu</button>
                    <button id="itp-history-btn" class="itp-btn summary" style="background:#009688;">📅 Haftalık Geçmiş</button>
                    <button id="itp-break-btn" class="itp-btn summary" style="background:#795548;" title="Mola saatlerini gir — tüm kişilerin idle toplamından düşülür, geri alınabilir">☕ Mola Saatleri</button>
                    <button id="itp-token-btn" class="itp-btn summary" style="background:#455a64;" title="GitHub Gist token'ı — dashboard'a veri yazmak için gerekli, tarayıcıda saklanır">🔑 Token</button>
                    <button id="itp-reset" class="itp-btn reset">🗑</button>
                </div>
                <div class="itp-last-scan" id="itp-last-scan">Henüz tarama yapılmadı</div>
            </div>
        `;
        document.body.appendChild(panel);

        // ===== DRAG & DROP =====
        const PANEL_POS_KEY = 'itp_panel_position';

        // Kaydedilmiş pozisyon varsa uygula
        try {
            const savedPos = JSON.parse(localStorage.getItem(PANEL_POS_KEY));
            if (savedPos) {
                panel.style.top = savedPos.top;
                panel.style.left = savedPos.left;
                panel.style.right = 'auto';
            }
        } catch (e) {}

        const header = panel.querySelector('.itp-header');
        let isDragging = false;
        let dragOffsetX = 0;
        let dragOffsetY = 0;

        header.addEventListener('mousedown', (e) => {
            // Butonlara tıklama drag başlatmasın
            if (e.target.tagName === 'BUTTON') return;
            isDragging = true;
            dragOffsetX = e.clientX - panel.getBoundingClientRect().left;
            dragOffsetY = e.clientY - panel.getBoundingClientRect().top;
            panel.style.transition = 'none';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            let newX = e.clientX - dragOffsetX;
            let newY = e.clientY - dragOffsetY;

            // Ekran sınırları içinde tut
            newX = Math.max(0, Math.min(newX, window.innerWidth - panel.offsetWidth));
            newY = Math.max(0, Math.min(newY, window.innerHeight - 40));

            panel.style.left = newX + 'px';
            panel.style.top = newY + 'px';
            panel.style.right = 'auto';
        });

        document.addEventListener('mouseup', () => {
            if (!isDragging) return;
            isDragging = false;
            panel.style.transition = '';
            // Pozisyonu kaydet
            try {
                localStorage.setItem(PANEL_POS_KEY, JSON.stringify({ top: panel.style.top, left: panel.style.left }));
            } catch (e) {}
        });

        // Kat toggle butonları oluştur
        renderFloorToggles();

        // Auto-refresh toggle
        const refreshToggle = document.getElementById('itp-refresh-toggle');
        const refreshSelect = document.getElementById('itp-refresh-interval');

        refreshToggle.addEventListener('click', () => {
            if (autoRefreshEnabled) {
                stopAutoRefresh();
                refreshToggle.classList.remove('on');
            } else {
                autoRefreshIntervalMs = parseInt(refreshSelect.value) * 1000;
                startAutoRefresh();
                refreshToggle.classList.add('on');
            }
        });

        refreshSelect.addEventListener('change', () => {
            autoRefreshIntervalMs = parseInt(refreshSelect.value) * 1000;
            nextRefreshAt = Date.now() + autoRefreshIntervalMs;
            if (autoRefreshEnabled) {
                stopAutoRefresh();
                startAutoRefresh();
                refreshToggle.classList.add('on');
            }
        });

        // Otomatik mesaj toggle
        const autoMsgToggle = document.getElementById('itp-automsg-toggle');
        autoMsgToggle.addEventListener('click', () => {
            autoMessageEnabled = !autoMessageEnabled;
            autoMsgToggle.classList.toggle('on', autoMessageEnabled);
            const label = document.getElementById('itp-automsg-label');
            if (label) {
                label.textContent = autoMessageEnabled ? '✅ Açık — 10dk+ inactive olana otomatik mesaj gider' : '⏸ Kapalı — sadece manuel butonla';
                label.style.color = autoMessageEnabled ? '#4caf50' : '#888';
            }
            saveStateToStorage();
        });

        // Minimize
        let minimized = false;
        document.getElementById('itp-minimize').addEventListener('click', () => {
            minimized = !minimized;
            document.getElementById('itp-body').style.display = minimized ? 'none' : 'block';
            document.getElementById('itp-minimize').textContent = minimized ? '+' : '−';
        });

        // Buttons
        document.getElementById('itp-start').addEventListener('click', startTracking);
        document.getElementById('itp-stop').addEventListener('click', stopTracking);
        document.getElementById('itp-summary-btn').addEventListener('click', () => showDashboard());
        document.getElementById('itp-warn-btn').addEventListener('click', () => showWarningReport());
        document.getElementById('itp-history-btn').addEventListener('click', () => showWeeklyHistory());
        document.getElementById('itp-break-btn').addEventListener('click', () => showBreakSettings());
        document.getElementById('itp-token-btn').addEventListener('click', () => promptGistToken());
        document.getElementById('itp-reset').addEventListener('click', () => {
            if (confirm('Tüm veriler silinecek. Emin misiniz?')) resetData();
        });
    }

    function renderFloorToggles() {
        const container = document.getElementById('itp-floor-toggles');
        if (!container) return;
        container.innerHTML = TRACKED_FLOORS.map(f => {
            const on = enabledMsgFloors.has(f);
            return `<span class="itp-floor-toggle ${on ? 'on' : 'off'}" data-floor="${f}">${f}</span>`;
        }).join('');

        container.querySelectorAll('.itp-floor-toggle').forEach(btn => {
            btn.addEventListener('click', () => {
                const floor = btn.dataset.floor;
                if (enabledMsgFloors.has(floor)) {
                    enabledMsgFloors.delete(floor);
                    btn.className = 'itp-floor-toggle off';
                } else {
                    enabledMsgFloors.add(floor);
                    btn.className = 'itp-floor-toggle on';
                }
            });
        });
    }

    function updateRefreshCountdown() {
        const el = document.getElementById('itp-countdown');
        if (!el) return;
        if (!autoRefreshEnabled) { el.textContent = '—'; return; }
        const secs = autoRefreshCountdown;
        el.textContent = secs > 0 ? `${secs}s` : '🔄';
    }

    function updatePanel() {
        const statusEl = document.getElementById('itp-status');
        const startBtn = document.getElementById('itp-start');
        const stopBtn = document.getElementById('itp-stop');
        if (!statusEl) return;

        if (isTracking) {
            statusEl.textContent = 'Aktif'; statusEl.className = 'itp-status active';
            startBtn.style.display = 'none'; stopBtn.style.display = '';
        } else {
            statusEl.textContent = 'Durdu'; statusEl.className = 'itp-status stopped';
            startBtn.style.display = ''; stopBtn.style.display = 'none';
        }

        document.getElementById('itp-scan-count').textContent = scanCount;
        document.getElementById('itp-inactive-count').textContent = Object.keys(trackerData).length;
        document.getElementById('itp-msg-count').textContent = Object.keys(messagedUsers).length;

        if (lastScanTime) {
            document.getElementById('itp-last-scan').textContent =
                `Son: ${timeStr(lastScanTime)} | ⚠️ Hâlâ inactive: ${Object.keys(stillInactiveAfterMsg).length}`;
        }
    }

    // ==================== MAIN SUMMARY MODAL ====================
    function showSummary(defaultFloor = 'ALL') {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        let currentFloor = defaultFloor;
        let currentTab = 'all'; // 'all' veya 'warned'

        function renderContent() {
            const summary = generateSummary(currentFloor);
            const allSummary = summary;
            const warnedSummary = summary.filter(r => r.wasMessaged);
            const stillInactiveSummary = summary.filter(r => r.stillInactive);

            const displayList = currentTab === 'warned' ? warnedSummary : allSummary;

            const totalPickers = allSummary.length;
            const totalIdleMin = allSummary.reduce((s, r) => s + r.totalInactiveMinutes, 0);
            const avgIdleMin = totalPickers > 0 ? Math.round(totalIdleMin / totalPickers) : 0;

            const floorButtons = ['ALL', ...TRACKED_FLOORS].map(f => {
                const cls = f === currentFloor ? 'itp-floor-btn active' : 'itp-floor-btn';
                return `<button class="${cls}" data-floor="${f}">${f === 'ALL' ? 'Tümü' : f}</button>`;
            }).join('');

            const tableRows = displayList.map((r, i) => {
                let idleClass = 'itp-idle-low';
                if (r.totalInactiveMinutes >= 60) idleClass = 'itp-idle-high';
                else if (r.totalInactiveMinutes >= 30) idleClass = 'itp-idle-medium';

                let msgBadge = '';
                if (r.stillInactive) {
                    msgBadge = `<span class="itp-badge still">⚠️ Hâlâ Inactive (${r.idleSinceMsg} dk)</span>`;
                } else if (r.wasMessaged) {
                    msgBadge = `<span class="itp-badge sent">✅ Mesaj Gönderildi</span>`;
                } else {
                    msgBadge = `<button data-send-uid="${r.userId}" onclick="event.stopPropagation(); window._itpSendMsg('${r.userId}')" style="background:#2196f3; color:white; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px; font-weight:600;">📩 Mesaj At</button>`;
                }

                return `<tr onclick="window._itpShowDetail('${r.userId}')" style="cursor:pointer;" title="Detay için tıkla">
                    <td>${i + 1}</td>
                    <td style="white-space:nowrap;">${badgeImg(r.userId, 24)} ${r.userId}</td>
                    <td>${r.name}</td>
                    <td>${r.floor}</td>
                    <td style="font-size:11px; color:${PICK_MANAGERS.some(pm => (r.manager||'').toLowerCase().includes(pm.toLowerCase())) ? '#4caf50' : '#ff5722'}">
                        ${r.manager || '-'} <span style="font-size:9px; opacity:0.7;">${(() => { const mk = Object.keys(MANAGER_LABELS).find(k => (r.manager||'').toLowerCase().includes(k.toLowerCase())); return mk ? MANAGER_LABELS[mk].replace(/[🟢🔶]\s*/,'') : ''; })()}</span>
                    </td>
                    <td class="${idleClass}">${r.totalInactiveFormatted}</td>
                    <td>${rateCellHTML(r.userId)}</td>
                    <td style="color:#9ccc65;font-size:11px;white-space:nowrap;" title="Kat bazli idle dagilimi">${r.floorIdleShort}</td>
                    <td style="color:#29b6f6;">${r.floorChangeCount > 0 ? '🔄 ' + r.floorChangeCount + 'x (' + formatMinutes(r.floorChangeMinutes) + ')' : '-'}</td>
                    <td>${r.topLocation}</td>
                    <td>${msgBadge || '-'}</td>
                </tr>`;
            }).join('');

            return `
                <button class="itp-close-btn" id="itp-close-modal">✕</button>
                <h2>📊 IST2 Inactive Picker Özeti</h2>
                <div class="itp-summary-info">
                    Shift: ${shiftLabel()} | Tarama: ${scanCount} | Tarih: ${new Date().toLocaleDateString('tr-TR')}
                </div>
                <div class="itp-totals">
                    <div class="itp-total-card">
                        <div class="itp-total-value">${totalPickers}</div>
                        <div class="itp-total-label">Inactive Picker</div>
                    </div>
                    <div class="itp-total-card">
                        <div class="itp-total-value">${formatMinutes(totalIdleMin)}</div>
                        <div class="itp-total-label">Toplam Idle</div>
                    </div>
                    <div class="itp-total-card">
                        <div class="itp-total-value">${warnedSummary.length}</div>
                        <div class="itp-total-label">Mesaj Gönderildi</div>
                    </div>
                    <div class="itp-total-card">
                        <div class="itp-total-value" style="color:#e91e63">${stillInactiveSummary.length}</div>
                        <div class="itp-total-label">⚠️ Hâlâ Inactive</div>
                    </div>
                </div>
                <div class="itp-tab-bar">
                    <div class="itp-tab ${currentTab === 'all' ? 'active' : ''}" data-tab="all">
                        Tüm Inactive (${allSummary.length})
                    </div>
                    <div class="itp-tab ${currentTab === 'warned' ? 'active' : ''}" data-tab="warned">
                        📩 Mesaj Atılanlar (${warnedSummary.length})
                    </div>
                </div>
                <div class="itp-filter-bar">
                    <span style="color:#aaa; font-size:12px;">Kat:</span>
                    ${floorButtons}
                </div>
                ${displayList.length === 0 ? '<p style="text-align:center; color:#888; padding:20px;">Veri bulunamadı.</p>' : `
                <div style="font-size:10px; color:#666; margin-bottom:4px; text-align:right;">💡 Satıra tıklayarak kişi detayını görebilirsiniz</div>
                <table>
                    <thead><tr>
                        <th>#</th><th>User ID</th><th>Ad Soyad</th><th>Kat</th><th>Manager</th>
                        <th>Idle</th><th>Rate</th><th>Kat Idle</th><th>🔄 Kat Değ.</th><th>En Çok Lokasyon</th><th>Mesaj Durumu</th>
                    </tr></thead>
                    <tbody>${tableRows}</tbody>
                </table>`}
                <div style="display:flex; gap:8px; margin-top:16px;">
                    <button class="itp-export-btn" id="itp-export-csv">📥 CSV İndir</button>
                    <button class="itp-export-btn" id="itp-export-chart" style="background:#ff9800;">📊 Grafik İndir (PNG)</button>
                    <button class="itp-export-btn" id="itp-export-clipboard" style="background:#2196f3;">📋 Panoya Kopyala</button>
                    <button class="itp-export-btn" id="itp-send-all-btn" style="background:#e91e63;">📩 Tümüne Mesaj At</button>
                </div>
            `;
        }

        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.innerHTML = renderContent();
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        overlay.addEventListener('click', (e) => {
            if (e.target.id === 'itp-close-modal' || e.target === overlay) { overlay.remove(); return; }
            if (e.target.classList.contains('itp-floor-btn')) {
                currentFloor = e.target.dataset.floor;
                modal.innerHTML = renderContent();
            }
            if (e.target.classList.contains('itp-tab')) {
                currentTab = e.target.dataset.tab;
                modal.innerHTML = renderContent();
            }
            if (e.target.id === 'itp-export-csv') exportCSV(currentFloor, currentTab);
            if (e.target.id === 'itp-export-chart') exportChartAsPNG();
            if (e.target.id === 'itp-export-clipboard') copyToClipboard(currentFloor, currentTab);
            if (e.target.id === 'itp-send-all-btn') window._itpSendAll();
        });
    }

    // ==================== WARNING REPORT (Mesaja Rağmen Inactive) ====================
    function showWarningReport() {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        let currentFloor = 'ALL';

        function renderWarnContent() {
            let entries = Object.entries(stillInactiveAfterMsg);
            if (currentFloor !== 'ALL') {
                entries = entries.filter(([_, d]) => d.floor === currentFloor);
            }
            entries.sort((a, b) => b[1].idleSinceMsg - a[1].idleSinceMsg);

            const floorButtons = ['ALL', ...TRACKED_FLOORS].map(f => {
                const cls = f === currentFloor ? 'itp-floor-btn active' : 'itp-floor-btn';
                return `<button class="${cls}" data-floor="${f}">${f === 'ALL' ? 'Tümü' : f}</button>`;
            }).join('');

            const rows = entries.map(([userId, d], i) => {
                let cls = 'itp-idle-low';
                if (d.idleSinceMsg >= 30) cls = 'itp-idle-high';
                else if (d.idleSinceMsg >= 15) cls = 'itp-idle-medium';

                return `<tr onclick="window._itpShowDetail('${userId}')" style="cursor:pointer;" title="Detay için tıkla">
                    <td>${i + 1}</td>
                    <td style="white-space:nowrap;">${badgeImg(userId, 22)} ${userId}</td>
                    <td>${d.name}</td>
                    <td>${d.floor}</td>
                    <td>${d.location}</td>
                    <td>${timeStr(d.msgSentAt)}</td>
                    <td class="${cls}">${formatMinutes(d.idleSinceMsg)}</td>
                    <td>${formatMinutes(d.totalInactiveMinutes)}</td>
                    <td>${rateCellHTML(userId)}</td>
                </tr>`;
            }).join('');

            return `
                <button class="itp-close-btn" id="itp-close-modal">✕</button>
                <h2>⚠️ Mesaja Rağmen Inactive Olanlar</h2>
                <div class="itp-summary-info">
                    FANS mesajı gönderildi, mesajı okudu (CLOSED) ancak hâlâ Inactive durumunda olan picker'lar.
                </div>
                <div class="itp-filter-bar">
                    <span style="color:#aaa; font-size:12px;">Kat:</span>
                    ${floorButtons}
                </div>
                ${entries.length === 0 ? '<p style="text-align:center; color:#4caf50; padding:30px; font-size:16px;">✅ Şu anda mesaja rağmen inactive olan picker yok!</p>' : `
                <table>
                    <thead><tr>
                        <th>#</th><th>User ID</th><th>Ad Soyad</th><th>Kat</th>
                        <th>Lokasyon</th><th>Mesaj Saati</th><th>Mesajdan Sonra Idle</th><th>Toplam Idle</th><th>Rate</th>
                    </tr></thead>
                    <tbody>${rows}</tbody>
                </table>`}
                <div style="display:flex; gap:8px; margin-top:16px;">
                    <button class="itp-export-btn" id="itp-export-warn-csv" style="background:#e91e63;">📥 Uyarı Raporu CSV</button>
                    <button class="itp-export-btn" id="itp-export-warn-clipboard" style="background:#2196f3;">📋 Panoya Kopyala</button>
                </div>
            `;
        }

        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.innerHTML = renderWarnContent();
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        overlay.addEventListener('click', (e) => {
            if (e.target.id === 'itp-close-modal' || e.target === overlay) { overlay.remove(); return; }
            if (e.target.classList.contains('itp-floor-btn')) {
                currentFloor = e.target.dataset.floor;
                modal.innerHTML = renderWarnContent();
            }
            if (e.target.id === 'itp-export-warn-csv') exportWarningCSV(currentFloor);
            if (e.target.id === 'itp-export-warn-clipboard') copyWarningToClipboard(currentFloor);
        });
    }

    // ==================== HAFTALIK GECMIS GORUNUMU ====================
    function showWeeklyHistory() {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        let selectedDayIdx = null; // null = gun listesi, sayi = secili gunun detayi

        function renderHistoryContent() {
            const archive = loadDailyArchive().slice().sort((a, b) => b.savedAt - a.savedAt);

            if (archive.length === 0) {
                return `
                    <button class="itp-close-btn" id="itp-close-modal">\u2715</button>
                    <h2>\ud83d\udcc5 Haftal\u0131k Ge\u00e7mi\u015f</h2>
                    <p style="text-align:center; color:#888; padding:30px;">Hen\u00fcz arsivlenmi\u015f g\u00fcn yok. Her g\u00fcn de\u011fi\u015fiminde (bir \u00f6nceki g\u00fcn\u00fcn verisi otomatik arsivlenir, en fazla ${ARCHIVE_RETENTION_DAYS} g\u00fcn tutulur).</p>
                `;
            }

            if (selectedDayIdx !== null && archive[selectedDayIdx]) {
                const day = archive[selectedDayIdx];
                const rows = day.pickers.map((p, i) => `
                    <tr onclick="window._itpShowDetail && window._itpShowDetail('${p.userId}')" style="cursor:pointer;" title="Canl\u0131 veri varsa detay a\u00e7\u0131l\u0131r">
                        <td>${i + 1}</td>
                        <td>${badgeImg(p.userId, 22)} ${p.userId}</td>
                        <td>${p.name}</td>
                        <td>${p.floor}</td>
                        <td>${p.manager || '-'}</td>
                        <td>${formatMinutes(p.totalInactiveMinutes)}</td>
                        <td>${p.msgSent ? '\u2705' : '-'}</td>
                    </tr>`).join('');

                return `
                    <button class="itp-close-btn" id="itp-close-modal">\u2715</button>
                    <h2>\ud83d\udcc5 ${day.date} \u2014 G\u00fcnl\u00fck \u00d6zet</h2>
                    <div class="itp-summary-info">
                        Tarama: ${day.scanCount} | Toplam idle: ${formatMinutes(day.totalIdleMin)} | Mesaj g\u00f6nderilen: ${day.msgSentCount} | Ki\u015fi say\u0131s\u0131: ${day.pickers.length}
                    </div>
                    <div style="margin-bottom:12px;">
                        <button class="itp-export-btn" id="itp-history-back" style="background:#607d8b;">\u2190 G\u00fcn Listesine D\u00f6n</button>
                    </div>
                    ${day.pickers.length === 0 ? '<p style="text-align:center; color:#4caf50; padding:20px;">O g\u00fcn inactive kaydı yok.</p>' : `
                    <table>
                        <thead><tr>
                            <th>#</th><th>User ID</th><th>Ad Soyad</th><th>Kat</th><th>Manager</th><th>Toplam Idle</th><th>Mesaj</th>
                        </tr></thead>
                        <tbody>${rows}</tbody>
                    </table>`}
                `;
            }

            // Gun listesi
            const dayRows = archive.map((day, idx) => `
                <tr data-day-idx="${idx}" style="cursor:pointer;" title="Detay için tıkla">
                    <td>${idx + 1}</td>
                    <td>${day.date}</td>
                    <td>${day.pickers.length}</td>
                    <td>${formatMinutes(day.totalIdleMin)}</td>
                    <td>${day.msgSentCount}</td>
                    <td>${day.scanCount}</td>
                </tr>`).join('');

            return `
                <button class="itp-close-btn" id="itp-close-modal">\u2715</button>
                <h2>\ud83d\udcc5 Haftal\u0131k Ge\u00e7mi\u015f (son ${ARCHIVE_RETENTION_DAYS} g\u00fcn)</h2>
                <div class="itp-summary-info">
                    Her g\u00fcn\u00fcn \u00f6zeti otomatik olarak burada tutulur, ${ARCHIVE_RETENTION_DAYS} g\u00fcnden eski kay\u0131tlar otomatik silinir. Bir g\u00fcne t\u0131klayarak o g\u00fcn\u00fcn ki\u015fi bazl\u0131 detay\u0131n\u0131 g\u00f6rebilirsiniz.
                </div>
                <table>
                    <thead><tr>
                        <th>#</th><th>Tarih</th><th>Ki\u015fi Say\u0131s\u0131</th><th>Toplam Idle</th><th>Mesaj G\u00f6nderilen</th><th>Tarama Say\u0131s\u0131</th>
                    </tr></thead>
                    <tbody>${dayRows}</tbody>
                </table>
            `;
        }

        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.innerHTML = renderHistoryContent();
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        overlay.addEventListener('click', (e) => {
            if (e.target.id === 'itp-close-modal' || e.target === overlay) { overlay.remove(); return; }
            if (e.target.id === 'itp-history-back') { selectedDayIdx = null; modal.innerHTML = renderHistoryContent(); return; }
            const tr = e.target.closest('tr[data-day-idx]');
            if (tr) { selectedDayIdx = Number(tr.dataset.dayIdx); modal.innerHTML = renderHistoryContent(); }
        });
    }

    // ==================== EXPORT ====================
    function exportCSV(floorFilter, tab) {
        const summary = generateSummary(floorFilter);
        const list = tab === 'warned' ? summary.filter(r => r.wasMessaged) : summary;
        const headers = ['#', 'User ID', 'Ad Soyad', 'Kat', 'Manager', 'Toplam Idle (dk)', 'Kat Bazı Idle', 'En Çok Lokasyon', 'Lok Süre (dk)', 'Mesaj Durumu'];
        let csv = '\uFEFF' + headers.join(';') + '\n';
        list.forEach((r, i) => {
            const msgStatus = r.stillInactive ? 'Hâlâ Inactive' : (r.wasMessaged ? 'Mesaj Gönderildi' : '-');
            csv += [i + 1, r.userId, r.name, r.floor, r.manager || '-', r.totalInactiveMinutes, (r.floorIdleShort || '-').replace(/;/g, ','), r.topLocation, r.topLocationMinutes, msgStatus].join(';') + '\n';
        });
        downloadCSV(csv, `IST2_Inactive_${floorFilter}_${tab}_${new Date().toISOString().slice(0, 10)}.csv`);
    }

    function exportWarningCSV(floorFilter) {
        let entries = Object.entries(stillInactiveAfterMsg);
        if (floorFilter !== 'ALL') entries = entries.filter(([_, d]) => d.floor === floorFilter);
        const headers = ['#', 'User ID', 'Ad Soyad', 'Kat', 'Lokasyon', 'Mesaj Saati', 'Mesajdan Sonra Idle (dk)', 'Toplam Idle (dk)'];
        let csv = '\uFEFF' + headers.join(';') + '\n';
        entries.forEach(([uid, d], i) => {
            csv += [i + 1, uid, d.name, d.floor, d.location, timeStr(d.msgSentAt), d.idleSinceMsg, d.totalInactiveMinutes].join(';') + '\n';
        });
        downloadCSV(csv, `IST2_Uyarı_Raporu_${floorFilter}_${new Date().toISOString().slice(0, 10)}.csv`);
    }

    function downloadCSV(csv, filename) {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = filename; a.click();
        URL.revokeObjectURL(url);
    }

    function copyToClipboard(floorFilter, tab) {
        const summary = generateSummary(floorFilter);
        const list = tab === 'warned' ? summary.filter(r => r.wasMessaged) : summary;
        let text = `IST2 Inactive Özeti | Kat: ${floorFilter} | ${new Date().toLocaleDateString('tr-TR')}\n\n`;
        list.forEach((r, i) => {
            const badge = r.stillInactive ? '⚠️ HÂLÂ INACTIVE' : (r.wasMessaged ? '✅ Mesaj Gönderildi' : '');
            text += `${i + 1}. ${r.userId} — ${r.name} | ${r.floor} | Idle: ${r.totalInactiveFormatted} | Lokasyon: ${r.topLocation} ${badge}\n`;
        });
        navigator.clipboard.writeText(text).then(() => alert('Panoya kopyalandı!'));
    }

    function copyWarningToClipboard(floorFilter) {
        let entries = Object.entries(stillInactiveAfterMsg);
        if (floorFilter !== 'ALL') entries = entries.filter(([_, d]) => d.floor === floorFilter);
        let text = `⚠️ Mesaja Rağmen Inactive | Kat: ${floorFilter} | ${new Date().toLocaleDateString('tr-TR')}\n\n`;
        entries.forEach(([uid, d], i) => {
            text += `${i + 1}. ${uid} — ${d.name} | ${d.floor} | ${d.location} | Mesaj: ${timeStr(d.msgSentAt)} | Sonra Idle: ${formatMinutes(d.idleSinceMsg)}\n`;
        });
        navigator.clipboard.writeText(text).then(() => alert('Uyarı raporu panoya kopyalandı!'));
    }


    // ==================== PERSON DETAIL MODAL ====================
    function showPersonDetail(userId) {
        const existing = document.querySelector('.itp-overlay');
        if (existing) existing.remove();

        const entry = trackerData[userId];
        if (!entry) { alert('Kullan\u0131c\u0131 verisi bulunamad\u0131: ' + userId); return; }

        const periods = computeIdlePeriods(userId);
        const dailyMsg = buildDailySummaryMsg(userId);

        const FC = {
            'P1': '#4fc3f7', 'P2': '#66bb6a', 'P3': '#ffa726',
            'P4': '#ef5350', 'P5': '#ab47bc', 'P6': '#26c6da', 'HRV': '#78909c'
        };

        // Lokasyon dagilimi
        const locs = Object.entries(entry.locationCounts).sort((a, b) => b[1] - a[1]);
        const maxLocMin = locs.length > 0 ? locs[0][1] : 1;

        // Sure dagilimi
        const durationBuckets = {};
        periods.forEach(p => {
            let key;
            if (p.durationMin <= 5) key = '5 dk';
            else if (p.durationMin <= 10) key = '10 dk';
            else if (p.durationMin <= 15) key = '15 dk';
            else if (p.durationMin <= 20) key = '20 dk';
            else if (p.durationMin <= 30) key = '25-30 dk';
            else key = '30+ dk';
            durationBuckets[key] = (durationBuckets[key] || 0) + 1;
        });
        const maxBucket = Math.max(...Object.values(durationBuckets), 1);

        const mgrKey = Object.keys(MANAGER_LABELS).find(k => (entry.manager || '').toLowerCase().includes(k.toLowerCase()));
        const mgrLabel = mgrKey ? MANAGER_LABELS[mgrKey] : '';
        const userFC = floorChanges[userId] || [];

        // === HTML BUILDERS ===
        // v2.25: kat bazinda idle (saat araliklariyla) + en altta toplam
        const floorIdleList = computeFloorIdle(userId);
        const floorIdleTotal = floorIdleList.reduce(function (s2, f) { return s2 + f.minutes; }, 0);
        const floorIdleHtml = floorIdleList.length === 0
            ? '<p style="color:#888;">Veri yok</p>'
            : floorIdleList.map(function (f) {
                const clr = FC[f.floor] || '#ff9800';
                const rng = f.ranges.map(function (r) {
                    return '<span style="display:inline-block;background:rgba(255,255,255,0.07);border-radius:5px;padding:2px 7px;margin:2px 4px 2px 0;font-size:10px;color:#ccc;">' +
                        timeStr(r.start).slice(0, 5) + '\u2013' + timeStr(r.end).slice(0, 5) +
                        ' <b style="color:' + clr + ';">' + r.min + 'dk</b></span>';
                }).join('');
                return '<div style="margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.06);">' +
                    '<div style="display:flex;align-items:center;gap:8px;">' +
                    '<span style="min-width:48px;font-size:13px;font-weight:700;color:' + clr + ';">' + f.floor + '</span>' +
                    '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:6px;height:20px;position:relative;overflow:hidden;">' +
                    '<div style="width:' + Math.round((f.minutes / Math.max(floorIdleTotal, 1)) * 100) + '%;height:100%;background:' + clr + ';border-radius:6px;"></div>' +
                    '<span style="position:absolute;right:8px;top:1px;font-size:11px;font-weight:700;">' + formatMinutes(f.minutes) + '</span>' +
                    '</div></div>' +
                    '<div style="margin-top:4px;padding-left:56px;">' + rng + '</div>' +
                    '</div>';
            }).join('') +
            '<div style="margin-top:8px;padding-top:8px;border-top:2px solid rgba(255,152,0,0.4);font-size:13px;font-weight:700;">' +
            'TOPLAM: <span style="color:#ff9800;">' + formatMinutes(floorIdleTotal) + '</span>' +
            '<span style="font-size:10px;color:#888;font-weight:400;"> (kat ge\u00e7i\u015f s\u00fcreleri haric, katlar aras\u0131 s\u0131f\u0131rlanmaz)</span></div>';

        const locBars = locs.map(function(pair) {
            const loc = pair[0], mins = pair[1];
            const barW = Math.round((mins / maxLocMin) * 100);
            const fl = extractFloor(loc);
            const clr = FC[fl] || '#ff9800';
            return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;">' +
                '<span style="width:160px;font-size:11px;color:#ccc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + loc + '">' + loc + '</span>' +
                '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:6px;height:22px;position:relative;overflow:hidden;">' +
                '<div style="width:' + barW + '%;height:100%;background:' + clr + ';border-radius:6px;"></div>' +
                '<span style="position:absolute;right:8px;top:2px;font-size:11px;font-weight:600;">' + formatMinutes(mins) + '</span>' +
                '</div></div>';
        }).join('');

        const durBars = Object.entries(durationBuckets).map(function(pair) {
            const key = pair[0], count = pair[1];
            const barW = Math.round((count / maxBucket) * 100);
            return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;">' +
                '<span style="width:70px;font-size:12px;font-weight:600;color:#ff9800;">' + key + '</span>' +
                '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:6px;height:22px;position:relative;overflow:hidden;">' +
                '<div style="width:' + barW + '%;min-width:' + (count > 0 ? 20 : 0) + 'px;height:100%;background:#e91e63;border-radius:6px;"></div>' +
                '<span style="position:absolute;right:8px;top:2px;font-size:11px;font-weight:600;">' + count + ' adet</span>' +
                '</div></div>';
        }).join('');

        const periodRows = periods.map(function(p, i) {
            var durStyle = 'color:#4caf50';
            if (p.durationMin >= 30) durStyle = 'color:#f44336;font-weight:700';
            else if (p.durationMin >= 15) durStyle = 'color:#ff9800;font-weight:600';
            const scanTimes = p.snapTimes.map(function(t) { return timeStr(t).slice(0, 5); }).join(', ');
            const endDisp = p.endTime;
            const endLbl = p.ongoing
                ? '<span style="color:#ff9800;">devam</span>'
                : timeStr(endDisp).slice(0, 5);
            const detay = (p.cutMin > 0 ? ' (ham ' + p.rawMin + ' dk, mola -' + p.cutMin + ' dk)' : '');
            return '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">' +
                '<td style="padding:6px 10px;font-size:11px;">' + (i + 1) + '</td>' +
                '<td style="padding:6px 10px;font-size:12px;font-weight:600;">' + timeStr(p.startTime).slice(0, 5) + '</td>' +
                '<td style="padding:6px 10px;font-size:12px;font-weight:600;">' + endLbl + '</td>' +
                '<td style="padding:6px 10px;font-size:12px;' + durStyle + '">' + formatMinutes(p.durationMin) +
                '<span style="color:#888;font-size:10px;font-weight:400;">' + detay + '</span></td>' +
                '<td style="padding:6px 10px;font-size:11px;color:#29b6f6;">' + p.location + '</td>' +
                '<td style="padding:6px 10px;font-size:10px;color:#888;max-width:200px;word-break:break-all;">' + scanTimes + '</td>' +
                '<td style="padding:6px 10px;">' +
                '<button class="itp-mark-break-btn" data-start="' + p.startTime.getTime() + '" data-end="' + endDisp.getTime() + '" ' +
                'style="background:#795548;color:#fff;border:none;border-radius:6px;padding:4px 8px;font-size:10px;cursor:pointer;white-space:nowrap;" ' +
                'title="Bu periyodu (veya bir kismini) mola olarak isaretle, idle toplamindan dus">☕ Mola</button>' +
                '</td></tr>';
        }).join('');

        const thS = 'background:rgba(255,152,0,0.15);color:#ff9800;padding:8px 10px;text-align:left;font-size:11px;border-bottom:2px solid rgba(255,152,0,0.3);';
        const periodTable = periods.length === 0
            ? '<p style="color:#888;text-align:center;padding:12px;">Hen\u00fcz idle periyodu yok</p>'
            : '<div style="max-height:300px;overflow-y:auto;">' +
              '<table style="width:100%;border-collapse:collapse;">' +
              '<thead><tr>' +
              '<th style="' + thS + '">#</th>' +
              '<th style="' + thS + '" title="Son okutma saati (Last Activity Time)">Son Okutma</th>' +
              '<th style="' + thS + '" title="Yeniden okutma saati — idle burada bitti">Yeniden Okutma</th>' +
              '<th style="' + thS + '">S\u00fcre</th>' +
              '<th style="' + thS + '">Lokasyon</th>' +
              '<th style="' + thS + '">Tarama Saatleri</th>' +
              '<th style="' + thS + '"></th>' +
              '</tr></thead><tbody>' + periodRows + '</tbody></table></div>';

        const fcHtml = userFC.length === 0
            ? '<p style="color:#888;text-align:center;padding:8px;font-size:11px;">Kat de\u011fi\u015fimi yok</p>'
            : userFC.map(function(c) {
                const ti = transitInfo(entry, c.time.getTime());
                const tiTxt = !ti ? '' :
                    (ti.open
                        ? ' <span style="color:#ff9800;">\u2014 hen\u00fcz okutmad\u0131 (' + ti.minutes + ' dk ge\u00e7ti)</span>'
                        : ' <span style="color:#4caf50;">\u2014 ' + ti.minutes + ' dk sonra okuttu</span>');
                return '<div style="padding:4px 8px;font-size:11px;color:#ccc;">' +
                    timeStr(c.time).slice(0, 5) + ' \u2014 <span style="color:#ff9800;">' + c.fromFloor + '</span> \u2192 <span style="color:#4caf50;">' + c.toFloor + '</span>' +
                    ' <span style="color:#888;">(' + c.fromLocation + ' \u2192 ' + c.toLocation + ')</span>' + tiTxt + '</div>';
            }).join('');

        // === MODAL ===
        const overlay = document.createElement('div');
        overlay.className = 'itp-overlay';
        const modal = document.createElement('div');
        modal.className = 'itp-modal';
        modal.style.maxWidth = '950px';

        const cs = 'background:rgba(255,255,255,0.03);border-radius:12px;padding:16px;border:1px solid rgba(255,255,255,0.06);';
        const hs = 'font-size:13px;font-weight:700;margin:0 0 12px 0;';

        modal.innerHTML =
            '<button class="itp-close-btn" id="itp-close-detail">\u2715</button>' +
            '<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">' +
            badgeImg(userId, 48) +
            '<div>' +
            '<h2 style="color:#ff9800;margin:0;font-size:20px;">\ud83d\udc64 ' + entry.name + '</h2>' +
            '<div style="color:#aaa;font-size:12px;margin-top:4px;">' +
            userId + ' | Kat: <span style="color:' + (FC[entry.floor] || '#fff') + ';font-weight:700;">' + entry.floor + '</span>' +
            ' | Manager: ' + (entry.manager || '-') + ' <span style="font-size:10px;">' + mgrLabel + '</span>' +
            ' | Toplam Idle: <span style="color:#ff9800;font-weight:700;">' + formatMinutes(entry.totalInactiveMinutes) + '</span>' +
            ' | G\u00fcnl\u00fck Rate: <span style="color:' +
            (typeof entry.weeklyRate === 'number' ? rateColor(entry.weeklyRate) : '#888') + ';font-weight:700;">' +
            (typeof entry.weeklyRate === 'number' ? entry.weeklyRate + '%' : '-') + '</span>' +
            ' | Haftal\u0131k Rate: <span id="itp-weekly-rate" style="color:#888;font-weight:700;">\u23f3 y\u00fckleniyor\u2026</span>' +
            '</div></div></div>' +

            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">' +
            '<div style="' + cs + '">' +
            '<h3 style="' + hs + 'color:#29b6f6;">\ud83d\udccd Lokasyon Da\u011f\u0131l\u0131m\u0131</h3>' +
            (locBars || '<p style="color:#888;">Veri yok</p>') + '</div>' +
            '<div style="' + cs + '">' +
            '<h3 style="' + hs + 'color:#e91e63;">\ud83d\udcca \u0130dle S\u00fcre Da\u011f\u0131l\u0131m\u0131</h3>' +
            (durBars || '<p style="color:#888;">Veri yok</p>') +
            '<div style="margin-top:8px;font-size:10px;color:#888;">Toplam ' + periods.length + ' ayr\u0131 idle periyodu</div></div>' +
            '</div>' +

            '<div style="' + cs + 'margin-top:16px;">' +
            '<h3 style="' + hs + 'color:#ff9800;">\u23f1 \u0130dle Periyotlar\u0131 (Kan\u0131t)</h3>' +
            periodTable + '</div>' +

            '<div style="' + cs + 'margin-top:16px;">' +
            '<h3 style="' + hs + 'color:#9ccc65;">\ud83c\udfe2 Kat Baz\u0131nda Idle</h3>' +
            floorIdleHtml + '</div>' +

            '<div style="' + cs + 'margin-top:16px;">' +
            '<h3 style="' + hs + 'color:#ffd54f;">\ud83d\udcc8 G\u00fcn G\u00fcn Rate (son 7 g\u00fcn)</h3>' +
            '<div id="itp-daily-rate">\u23f3 y\u00fckleniyor\u2026</div></div>' +

            (userFC.length > 0 ?
                '<div style="' + cs + 'margin-top:16px;">' +
                '<h3 style="' + hs + 'color:#29b6f6;">\ud83d\udd04 Kat De\u011fi\u015fimleri (' + userFC.length + 'x' +
                (floorChangeForgiveMin > 0
                    ? ' \u2014 ba\u011f\u0131\u015flanan: ' + formatMinutes(entry.floorChangeMinutes || 0) + ' (olay ba\u015f\u0131 max ' + floorChangeForgiveMin + ' dk)'
                    : ' \u2014 bag\u0131\u015flama kapal\u0131, idle d\u00fc\u015f\u00fclm\u00fcyor') + ')</h3>' +
                fcHtml + '</div>' : '') +

            '<div style="' + cs + 'margin-top:16px;">' +
            '<h3 style="' + hs + 'color:#4caf50;">\ud83d\udce9 G\u00fcnl\u00fck \u00d6zet Mesaj\u0131 (Mola \u00d6ncesi)</h3>' +
            '<textarea id="itp-daily-msg" style="width:100%;min-height:80px;background:rgba(0,0,0,0.3);color:#e0e0e0;border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:12px;font-size:12px;font-family:inherit;resize:vertical;box-sizing:border-box;">' + dailyMsg + '</textarea>' +
            '<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;">' +
            '<button class="itp-export-btn" id="itp-detail-copy-msg" style="background:#9c27b0;font-size:11px;padding:6px 14px;">\ud83d\udccb Mesaj\u0131 Kopyala</button>' +
            '<button class="itp-export-btn" id="itp-detail-send-fans" style="background:#2196f3;font-size:11px;padding:6px 14px;">\ud83d\udce9 FANS ile G\u00f6nder</button>' +
            '<button class="itp-export-btn" id="itp-detail-back" style="background:#607d8b;font-size:11px;padding:6px 14px;">\u2190 Listeye D\u00f6n</button>' +
            '</div></div>';

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // v2.28: kisi detayinda HAFTALIK rate gosterilir (tabloda gunluk kalir)
        fetchWeekRateDetailed(userId).then(function (res) {
            const el = document.getElementById('itp-weekly-rate');
            if (!el) return; // modal kapatilmis olabilir
            if (res.value === null || res.value === undefined) {
                // v2.21: sadece "bulunamadi" degil, sebebini de yaz
                el.textContent = 'yok (' + (res.reason || 'bilinmiyor') + ')';
                el.style.color = '#888';
                el.title = 'Konsolda ITP_RATE_DEBUG(\'' + userId + '\') ile detay\u0131 g\u00f6rebilirsin';
            } else {
                el.textContent = res.value + '%';
                el.style.color = rateColor(res.value);
            }
        }).catch(function (e) {
            const el = document.getElementById('itp-weekly-rate');
            if (el) { el.textContent = 'hata'; el.style.color = '#f44336'; }
            console.error('[ITP] rate gosterim hatasi:', e);
        });

        // v2.27: gun gun rate tablosunu arka planda doldur
        fetchDailyRateSeries(userId, 7).then(function (days) {
            const box = document.getElementById('itp-daily-rate');
            if (!box) return;
            if (!days || days.length === 0) {
                box.innerHTML = '<p style="color:#888;margin:0;">G\u00fcnl\u00fck veri bulunamad\u0131</p>';
                return;
            }
            const maxP = Math.max.apply(null, days.map(function (d) { return d.pct; }).concat([100]));
            box.innerHTML = days.map(function (d) {
                const clr = rateColor(d.pct);
                const w = Math.round((d.pct / maxP) * 100);
                return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;">' +
                    '<span style="width:92px;font-size:11px;color:#ccc;white-space:nowrap;">' +
                    '<b>' + (d.date || '-') + '</b> <span style="color:#888;">' + (d.dayName || '') + '</span></span>' +
                    '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:6px;height:20px;position:relative;overflow:hidden;">' +
                    '<div style="width:' + w + '%;height:100%;background:' + clr + ';border-radius:6px;"></div>' +
                    '<span style="position:absolute;right:8px;top:1px;font-size:11px;font-weight:700;">' + d.pct + '%</span>' +
                    '</div></div>';
            }).join('');
        }).catch(function () {
            const box = document.getElementById('itp-daily-rate');
            if (box) box.innerHTML = '<p style="color:#f44336;margin:0;">G\u00fcnl\u00fck rate al\u0131namad\u0131</p>';
        });

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay || e.target.id === 'itp-close-detail') { overlay.remove(); return; }
            if (e.target.id === 'itp-detail-back') { overlay.remove(); showSummary(); return; }

            if (e.target.id === 'itp-detail-copy-msg') {
                var ta = document.getElementById('itp-daily-msg');
                navigator.clipboard.writeText(ta.value).then(function() {
                    e.target.textContent = '\u2705 Kopyaland\u0131!';
                    setTimeout(function() { e.target.textContent = '\ud83d\udccb Mesaj\u0131 Kopyala'; }, 2000);
                });
                return;
            }

            if (e.target.classList && e.target.classList.contains('itp-mark-break-btn')) {
                var pStart = Number(e.target.getAttribute('data-start'));
                var pEnd = Number(e.target.getAttribute('data-end'));
                markPeriodAsBreak(userId, pStart, pEnd);
                return;
            }

            if (e.target.id === 'itp-detail-send-fans') {
                var ta2 = document.getElementById('itp-daily-msg');
                var msgText = ta2.value;
                if (!confirm('\ud83d\udce9 G\u00fcnl\u00fck \u00f6zet mesaj g\u00f6nder?\n\nKime: ' + entry.name + ' (' + userId + ')\n\nMesaj:\n"' + msgText + '"\n\nG\u00f6ndermek istiyor musun?')) return;
                e.target.textContent = '\u23f3 G\u00f6nderiliyor...';
                e.target.disabled = true;
                sendFANSMessage(userId, msgText).then(function() {
                    e.target.textContent = '\u2705 G\u00f6nderildi!';
                    e.target.style.background = '#4caf50';
                    addLogEntry('\ud83d\udce9', 'G\u00fcnl\u00fck \u00f6zet mesaj g\u00f6nderildi: ' + entry.name + ' (' + userId + ')');
                }).catch(function(err) {
                    e.target.textContent = '\u274c Hata';
                    e.target.disabled = false;
                    alert('Mesaj g\u00f6nderilemedi: ' + err.message);
                });
                return;
            }
        });
    }



    // ==================== CHART PNG EXPORT ====================
    // Canvas rounded rectangle helper
    function _itpRoundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    }

    function exportChartAsPNG() {
        const W = 1400, H = 950;
        const canvas = document.createElement('canvas');
        canvas.width = W;
        canvas.height = H;
        const ctx = canvas.getContext('2d');

        // Arka plan
        const bgGrad = ctx.createLinearGradient(0, 0, W, H);
        bgGrad.addColorStop(0, '#1a1a2e');
        bgGrad.addColorStop(1, '#16213e');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, W, H);

        // Border
        ctx.strokeStyle = 'rgba(255,255,255,0.1)';
        ctx.lineWidth = 2;
        ctx.strokeRect(1, 1, W - 2, H - 2);

        // Baslik
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 26px Arial, sans-serif';
        ctx.fillText('\ud83d\udcca IST2 Inactive Picker \u00d6zeti', 40, 46);

        ctx.fillStyle = '#aaa';
        ctx.font = '13px Arial, sans-serif';
        const dateStr = new Date().toLocaleDateString('tr-TR');
        ctx.fillText('Shift: ' + shiftLabel() + ' | Tarama: ' + scanCount + ' | Tarih: ' + dateStr + ' | Olu\u015fturma: ' + timeStr(now()), 40, 70);

        ctx.strokeStyle = 'rgba(255,152,0,0.3)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(40, 82); ctx.lineTo(W - 40, 82); ctx.stroke();

        // === KPI KUTULARI ===
        const allEntries = Object.entries(trackerData);
        const totalInactive = allEntries.length;
        const totalIdleMin = allEntries.reduce(function(s, pair) { return s + pair[1].totalInactiveMinutes; }, 0);
        const totalMessaged = Object.keys(messagedUsers).length;
        const totalStillInactive = Object.keys(stillInactiveAfterMsg).length;

        const kpis = [
            { label: 'Inactive Picker', value: String(totalInactive), color: '#ff9800' },
            { label: 'Toplam Idle', value: formatMinutes(totalIdleMin), color: '#ff9800' },
            { label: 'Mesaj G\u00f6nderildi', value: String(totalMessaged), color: '#2196f3' },
            { label: 'H\u00e2l\u00e2 Inactive', value: String(totalStillInactive), color: '#e91e63' }
        ];

        const kpiW = 300, kpiH = 65, kpiGap = 20, kpiStartX = 40, kpiY = 95;
        kpis.forEach(function(kpi, i) {
            var x = kpiStartX + i * (kpiW + kpiGap);
            ctx.fillStyle = 'rgba(255,255,255,0.04)';
            _itpRoundRect(ctx, x, kpiY, kpiW, kpiH, 10); ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.08)';
            _itpRoundRect(ctx, x, kpiY, kpiW, kpiH, 10); ctx.stroke();
            ctx.fillStyle = kpi.color;
            ctx.font = 'bold 26px Arial, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(kpi.value, x + kpiW / 2, kpiY + 32);
            ctx.fillStyle = '#999';
            ctx.font = '11px Arial, sans-serif';
            ctx.fillText(kpi.label, x + kpiW / 2, kpiY + 52);
        });
        ctx.textAlign = 'left';

        // === KAT BAR CHART (sol) ===
        const FCLR = {
            'P1': '#4fc3f7', 'P2': '#66bb6a', 'P3': '#ffa726',
            'P4': '#ef5350', 'P5': '#ab47bc', 'P6': '#26c6da', 'HRV': '#78909c'
        };
        var floorStats = {};
        TRACKED_FLOORS.forEach(function(f) { floorStats[f] = { count: 0, totalIdle: 0 }; });
        allEntries.forEach(function(pair) {
            var d = pair[1];
            if (floorStats[d.floor]) { floorStats[d.floor].count++; floorStats[d.floor].totalIdle += d.totalInactiveMinutes; }
        });

        var chartY = 190, chartX = 40, chartW = 600, barH = 26, barGap = 7;
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.fillText('\ud83c\udfe2 Kat Bazl\u0131 Idle Da\u011f\u0131l\u0131m\u0131', chartX, chartY);

        var maxFloorIdle = Math.max.apply(null, Object.values(floorStats).map(function(f) { return f.totalIdle; }).concat([1]));

        TRACKED_FLOORS.forEach(function(f, i) {
            var d = floorStats[f];
            var y = chartY + 18 + i * (barH + barGap);
            var bW = Math.round((d.totalIdle / maxFloorIdle) * (chartW - 100));
            var clr = FCLR[f] || '#888';
            ctx.fillStyle = clr;
            ctx.font = 'bold 13px Arial, sans-serif';
            ctx.fillText(f, chartX, y + 17);
            ctx.fillStyle = 'rgba(255,255,255,0.05)';
            _itpRoundRect(ctx, chartX + 50, y, chartW - 100, barH, 6); ctx.fill();
            if (bW > 0) { ctx.fillStyle = clr; _itpRoundRect(ctx, chartX + 50, y, Math.max(bW, 4), barH, 6); ctx.fill(); }
            ctx.fillStyle = '#e0e0e0';
            ctx.font = '11px Arial, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(d.count + ' ki\u015fi / ' + formatMinutes(d.totalIdle), chartX + chartW, y + 17);
            ctx.textAlign = 'left';
        });

        // === TOP 10 PICKER (sag) ===
        var topX = 700, topW = 660;
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.fillText('\ud83c\udfc6 En \u00c7ok Idle Yapan 10 Picker', topX, chartY);

        var top10 = allEntries.slice().sort(function(a, b) { return b[1].totalInactiveMinutes - a[1].totalInactiveMinutes; }).slice(0, 10);
        var maxTopIdle = top10.length > 0 ? top10[0][1].totalInactiveMinutes : 1;

        top10.forEach(function(pair, i) {
            var uid = pair[0], d = pair[1];
            var y = chartY + 18 + i * (barH + barGap);
            var bW = Math.round((d.totalInactiveMinutes / maxTopIdle) * (topW - 240));
            var clr = FCLR[d.floor] || '#ff9800';
            ctx.fillStyle = '#ff9800';
            ctx.font = 'bold 13px Arial, sans-serif';
            ctx.fillText((i + 1) + '.', topX, y + 17);
            ctx.fillStyle = '#e0e0e0';
            ctx.font = '12px Arial, sans-serif';
            var dName = d.name.length > 18 ? d.name.slice(0, 18) + '\u2026' : d.name;
            ctx.fillText(dName + ' (' + uid + ')', topX + 24, y + 17);
            ctx.fillStyle = 'rgba(255,255,255,0.05)';
            _itpRoundRect(ctx, topX + 210, y, topW - 240, barH, 6); ctx.fill();
            if (bW > 0) { ctx.fillStyle = clr; _itpRoundRect(ctx, topX + 210, y, Math.max(bW, 4), barH, 6); ctx.fill(); }
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 11px Arial, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(formatMinutes(d.totalInactiveMinutes) + ' | ' + d.floor, topX + topW, y + 17);
            ctx.textAlign = 'left';
        });

        // === DONUT CHART (mesaj durumu) ===
        var donutY = 540;
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.fillText('\ud83d\udce9 Mesaj Durumu Da\u011f\u0131l\u0131m\u0131', 40, donutY);

        var donutCX = 200, donutCY = donutY + 110, donutR = 75, donutR2 = 42;
        var noMsg = totalInactive - totalMessaged;
        var cleared = totalMessaged - totalStillInactive;
        var still = totalStillInactive;
        var total = totalInactive || 1;
        var segments = [
            { label: 'Mesaj yok', value: noMsg, color: '#607d8b' },
            { label: 'Mesaj \u2192 Aktif', value: cleared, color: '#4caf50' },
            { label: 'Mesaja Ra\u011fmen', value: still, color: '#e91e63' }
        ];

        var startAngle = -Math.PI / 2;
        segments.forEach(function(seg) {
            if (seg.value <= 0) return;
            var sliceAngle = (seg.value / total) * 2 * Math.PI;
            ctx.beginPath();
            ctx.moveTo(donutCX, donutCY);
            ctx.arc(donutCX, donutCY, donutR, startAngle, startAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = seg.color;
            ctx.fill();
            startAngle += sliceAngle;
        });
        ctx.beginPath(); ctx.arc(donutCX, donutCY, donutR2, 0, 2 * Math.PI);
        ctx.fillStyle = '#1a1a2e'; ctx.fill();
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 22px Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(String(totalInactive), donutCX, donutCY + 8);
        ctx.textAlign = 'left';

        var legX = donutCX + donutR + 40;
        segments.forEach(function(seg, i) {
            var ly = donutCY - 25 + i * 26;
            ctx.fillStyle = seg.color;
            ctx.fillRect(legX, ly - 8, 13, 13);
            ctx.fillStyle = '#ccc';
            ctx.font = '12px Arial, sans-serif';
            ctx.fillText(seg.label + ': ' + seg.value, legX + 20, ly + 4);
        });

        // === MANAGER CHART (sag alt) ===
        var mgrY = donutY;
        var mgrX = 520;
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.fillText('\ud83d\udc54 Manager Bazl\u0131 Idle', mgrX, mgrY);

        var mgrData = {};
        allEntries.forEach(function(pair) {
            var uid = pair[0], d = pair[1];
            var mgr = d.manager || 'Bilinmiyor';
            if (!mgrData[mgr]) mgrData[mgr] = { count: 0, totalIdle: 0, isPick: false };
            mgrData[mgr].count++;
            mgrData[mgr].totalIdle += d.totalInactiveMinutes;
            mgrData[mgr].isPick = PICK_MANAGERS.some(function(pm) { return mgr.toLowerCase().includes(pm.toLowerCase()); });
        });
        var mgrEntries = Object.entries(mgrData).sort(function(a, b) { return b[1].totalIdle - a[1].totalIdle; }).slice(0, 6);
        var maxMgrIdle = mgrEntries.length > 0 ? Math.max.apply(null, mgrEntries.map(function(e) { return e[1].totalIdle; }).concat([1])) : 1;

        mgrEntries.forEach(function(pair, i) {
            var mgr = pair[0], d = pair[1];
            var y = mgrY + 18 + i * (barH + barGap + 2);
            var bW = Math.round((d.totalIdle / maxMgrIdle) * 480);
            var clr = d.isPick ? '#4caf50' : '#ff5722';
            ctx.fillStyle = '#ccc';
            ctx.font = '11px Arial, sans-serif';
            ctx.fillText(mgr.length > 20 ? mgr.slice(0, 20) + '\u2026' : mgr, mgrX, y + 16);
            ctx.fillStyle = 'rgba(255,255,255,0.05)';
            _itpRoundRect(ctx, mgrX + 155, y, 480, barH, 6); ctx.fill();
            if (bW > 0) { ctx.fillStyle = clr; _itpRoundRect(ctx, mgrX + 155, y, Math.max(bW, 4), barH, 6); ctx.fill(); }
            ctx.fillStyle = '#e0e0e0';
            ctx.font = '11px Arial, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(d.count + ' ki\u015fi / ' + formatMinutes(d.totalIdle), mgrX + 650, y + 16);
            ctx.textAlign = 'left';
        });

        // === TAM PICKER LISTESI (ilk 15) ===
        var listY = 780;
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.fillText('\ud83d\udccb T\u00fcm Inactive Picker Listesi (ilk 15)', 40, listY);

        var sortedAll = allEntries.slice().sort(function(a, b) { return b[1].totalInactiveMinutes - a[1].totalInactiveMinutes; }).slice(0, 15);

        ctx.fillStyle = 'rgba(255,152,0,0.15)';
        ctx.fillRect(40, listY + 8, W - 80, 20);
        ctx.fillStyle = '#ff9800';
        ctx.font = 'bold 10px Arial, sans-serif';
        var colX = [50, 80, 190, 400, 450, 640, 730, 940];
        var colL = ['#', 'User ID', 'Ad Soyad', 'Kat', 'Manager', 'Idle', 'Lokasyon', 'Mesaj'];
        colL.forEach(function(l, i) { ctx.fillText(l, colX[i], listY + 22); });

        sortedAll.forEach(function(pair, i) {
            var uid = pair[0], d = pair[1];
            var y = listY + 32 + i * 14;
            if (y > H - 15) return;
            if (i % 2 === 0) { ctx.fillStyle = 'rgba(255,255,255,0.02)'; ctx.fillRect(40, y - 8, W - 80, 14); }
            ctx.font = '10px Arial, sans-serif';
            ctx.fillStyle = '#ccc';
            ctx.fillText(String(i + 1), 50, y);
            ctx.fillText(uid, 80, y);
            ctx.fillText(d.name.length > 24 ? d.name.slice(0, 24) + '\u2026' : d.name, 190, y);
            ctx.fillStyle = FCLR[d.floor] || '#fff';
            ctx.fillText(d.floor, 400, y);
            ctx.fillStyle = '#ccc';
            ctx.fillText((d.manager || '-').length > 20 ? (d.manager || '-').slice(0, 20) + '\u2026' : (d.manager || '-'), 450, y);
            if (d.totalInactiveMinutes >= 60) ctx.fillStyle = '#f44336';
            else if (d.totalInactiveMinutes >= 30) ctx.fillStyle = '#ff9800';
            else ctx.fillStyle = '#4caf50';
            ctx.font = 'bold 10px Arial, sans-serif';
            ctx.fillText(formatMinutes(d.totalInactiveMinutes), 640, y);
            var topLoc = '-';
            if (d.locationCounts) {
                var le = Object.entries(d.locationCounts);
                if (le.length > 0) topLoc = le.sort(function(a,b){return b[1]-a[1];})[0][0];
            }
            ctx.fillStyle = '#29b6f6'; ctx.font = '10px Arial, sans-serif';
            ctx.fillText(topLoc.length > 16 ? topLoc.slice(0, 16) + '\u2026' : topLoc, 730, y);
            var msged = messagedUsers[uid]; var stillInact = stillInactiveAfterMsg[uid];
            if (stillInact) { ctx.fillStyle = '#e91e63'; ctx.fillText('\u26a0 H\u00e2l\u00e2 Inactive', 940, y); }
            else if (msged) { ctx.fillStyle = '#4caf50'; ctx.fillText('\u2705 G\u00f6nderildi', 940, y); }
            else { ctx.fillStyle = '#888'; ctx.fillText('-', 940, y); }
        });

        // Watermark
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.font = '10px Arial, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText('IST2 Inactive Tracker v2.8 | ' + dateStr + ' ' + timeStr(now()), W - 20, H - 10);
        ctx.textAlign = 'left';

        // Download
        canvas.toBlob(function(blob) {
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'IST2_Inactive_Grafik_' + new Date().toISOString().slice(0, 10) + '.png';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 'image/png');
    }


    // ==================== INIT ====================
    function init() {
        // Tablo yüklenene kadar bekle (React app — DOM geç yükleniyor)
        let waitCount = 0;
        const checkReady = setInterval(() => {
            waitCount++;
            // Sadece "bir tbody tr var mi" yetmiyor: baska script'lerin ozet tablosu
            // de bu kosulu gecirip taramayi tablo render olmadan baslatiyordu.
            // v2.40: veri artik API'den geliyor, tablonun render olmasi sart degil.
            // Tablo varsa hemen basla; yoksa 5 sn sonra yine basla (API yeter).
            const ready = collectDataRows().length > 0;
            if (ready || waitCount > 5) {
                clearInterval(checkReady);

                // localStorage'dan state yükle
                const restored = loadStateFromStorage();

                createPanel();

                if (restored) {
                    // Panel'i güncelle
                    updatePanel();

                    // Floor toggle'ları restore et
                    renderFloorToggles();

                    // Refresh interval select'i ayarla
                    const refreshSelect = document.getElementById('itp-refresh-interval');
                    if (refreshSelect) {
                        refreshSelect.value = String(Math.round(autoRefreshIntervalMs / 1000));
                    }

                    // Auto-refresh aktifse devam et
                    if (autoRefreshEnabled) {
                        const refreshToggle = document.getElementById('itp-refresh-toggle');
                        if (refreshToggle) refreshToggle.classList.add('on');
                        startAutoRefresh();
                    }

                    // Tracking aktifse devam et
                    if (isTracking) {
                        isTracking = false; // startTracking tekrar set edecek
                        startTracking();
                    }

                    console.log(`[ITP] State geri yüklendi — isTracking: ${isTracking}, autoRefresh: ${autoRefreshEnabled}, scanCount: ${scanCount}`);
                } else {
                    // Yeni başlatma — otomatik tracking başlat
                    startTracking();
                    console.log('[Inactive Tracker v2] Hazır — FANS mesaj entegrasyonu aktif.');
                }
            }
        }, 1000);
    }

    // NOT: Tampermonkey sandbox modunda devtools console'u, scriptin kendi
    // 'window' nesnesinden farkli bir 'window' gorur; bu yuzden burada da
    // unsafeWindow (_w) kullanilmali, yoksa sayfa konsolunda ITP_DEBUG() 'is not defined' verir.
    _w.ITP_DEBUG = function () { itpDiagnose(); return parseTableRows(); };
    // v2.40: API kaynagini dogrudan incelemek icin
    _w.ITP_API = function () {
        return fetchWorkforceRows().then(function (rows) {
            console.table(rows.slice(0, 20).map(function (r) {
                return { login: r.userId, durum: r.status, kat: r.floor, lok: r.location,
                    sonOkutma: r.lastActivity, path: r.processPath };
            }));
            console.log('[ITP] toplam ' + rows.length + ' satir, kaynak: API');
            return rows;
        });
    };
    window.ITP_API = _w.ITP_API;

    // v2.42: mola indirimi neden uygulanmadi? Tum girdiyi tek yerde goster.
    _w.ITP_BREAK_DEBUG = function () {
        var hm = function (ms) {
            return new Date(ms).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
        };
        console.log('=== MOLA TESHISI (v' + ITP_VERSION + ') ===');
        console.log('Kisi basi limit  :', maxBreakMinutesPerPerson, '(0 = sinirsiz)');
        console.log('Mola sayma esigi :', minBreakBlockMinutes, '(0 = esik yok)');
        console.log('Mola araligi say :', breakWindows.length);
        if (!breakWindows.length) {
            console.warn('>>> HIC MOLA ARALIGI YOK. Modalda "Mola Ekle" basilmamis ' +
                'veya eklendikten sonra state sifirlanmis. Indirim bu yuzden olmuyor.');
            return { breakWindows: [], people: [] };
        }
        breakWindows.forEach(function (w, i) {
            console.log('  [' + i + '] ' + hm(w.start.getTime()) + ' - ' + hm(w.end.getTime()) +
                '  (' + new Date(w.start).toLocaleDateString('tr-TR') + ')');
        });
        var out = [];
        Object.keys(trackerData).forEach(function (login) {
            var e = trackerData[login];
            if (!e) return;
            var runs = ensureIdleRuns(e);
            var ovTot = 0;
            var det = [];
            runs.forEach(function (r) {
                var ov = 0;
                breakWindows.forEach(function (w) {
                    ov += overlapMs(r.s, r.e, w.start.getTime(), w.end.getTime());
                });
                ovTot += ov;
                det.push(hm(r.s) + '-' + hm(r.e) +
                    ' ham ' + Math.round((r.e - r.s) / 60000) + 'dk' +
                    ' | mola kesisimi ' + Math.round(ov / 60000) + 'dk' +
                    ' | dusulen ' + Math.round((r.cutMs || 0) / 60000) + 'dk' +
                    ' | net ' + (r.effMin || 0) + 'dk' + (r.open ? ' (acik)' : ''));
            });
            out.push({
                login: login,
                periyot: runs.length,
                molaKesisimDk: Math.round(ovTot / 60000),
                dusulenDk: e.breakForgivenMinutes || 0,
                netIdleDk: e.totalInactiveMinutes || 0,
                detay: det
            });
        });
        out.sort(function (a, b) { return b.molaKesisimDk - a.molaKesisimDk; });
        console.table(out.map(function (o) {
            return { login: o.login, periyot: o.periyot, molaKesisimDk: o.molaKesisimDk,
                dusulenDk: o.dusulenDk, netIdleDk: o.netIdleDk };
        }));
        var kes = out.filter(function (o) { return o.molaKesisimDk > 0; });
        if (!kes.length) {
            console.warn('>>> Hic kimsenin idle periyodu bu mola araligiyla KESISMIYOR. ' +
                'Mola saatini yanlis girmis olabilirsin, ya da o saatlerde kayitli idle yok. ' +
                'Yukaridaki detay listesinde periyot saatlerini kontrol et.');
        } else {
            kes.slice(0, 5).forEach(function (o) {
                console.log('--- ' + o.login + ' (kesisim ' + o.molaKesisimDk + 'dk, dusulen ' + o.dusulenDk + 'dk)');
                o.detay.forEach(function (d) { console.log('      ' + d); });
            });
        }
        console.log('=== TESHIS SONU — bu ciktinin tamamini kopyala ===');
        return { breakWindows: breakWindows.length, people: out };
    };
    window.ITP_BREAK_DEBUG = _w.ITP_BREAK_DEBUG;
    _w.ITP_SOURCE = function () { console.log('[ITP] son tarama kaynagi: ' + lastRowSource); return lastRowSource; };
    window.ITP_SOURCE = _w.ITP_SOURCE;
    window.ITP_DEBUG = _w.ITP_DEBUG; // sandbox olmayan kurulumlar icin de calissin
    _w.ITP_RATE_DEBUG = function (login) { return itpRateDebug(login); };
    window.ITP_RATE_DEBUG = _w.ITP_RATE_DEBUG;
    // v2.22: modalin kullandigi URETIM yolunu dogrudan cagir
    _w.ITP_RATE = function (login) {
        return fetchWeeklyRateDetailed(login).then(function (r) {
            console.log('%c[ITP RATE] uretim yolu -> ' + login + ': value=' + r.value + ' reason=' + r.reason,
                'color:#4caf50;font-weight:bold');
            return r;
        });
    };
    window.ITP_RATE = _w.ITP_RATE;
    // Tum takip edilen kisiler icin tek seferde dene
    _w.ITP_RATE_ALL = async function () {
        const logins = Object.keys(trackerData);
        console.log('[ITP RATE] ' + logins.length + ' kisi deneniyor...');
        for (const l of logins) {
            const r = await fetchWeeklyRateDetailed(l);
            console.log('  ' + l + ' -> ' + (r.value !== null ? r.value + '%' : 'YOK (' + r.reason + ')'));
        }
    };
    window.ITP_RATE_ALL = _w.ITP_RATE_ALL;

    // ==================== v2.33: COKLU KOPYA KORUMASI ====================
    // Tampermonkey'de eski bir surum etkin kalirsa iki kopya ayni localStorage
    // kaydina yazar; farkli MIN_PER_SNAP degerleriyle "Toplam 15 dk ama periyot
    // 5 dk" gibi tutarsiz tablolar cikiyordu. Burada her kopya kendini duyurur;
    // farkli surumden ikinci bir kopya gorulurse YENI olan devam eder, eski
    // olan yazmayi tamamen birakir ve ekranda uyari gosterir.
    const ITP_VERSION = '2.45';
    const INSTANCE_KEY = 'itp_instances_v1';
    const INSTANCE_ID = Math.random().toString(36).slice(2) + '-' + Date.now();
    const INSTANCE_TTL_MS = 25 * 1000;
    let standDown = false;

    function verNum(v) {
        const p = String(v).split('.').map(Number);
        return (p[0] || 0) * 10000 + (p[1] || 0) * 100 + (p[2] || 0);
    }

    function readInstances() {
        try {
            const o = JSON.parse(localStorage.getItem(INSTANCE_KEY) || '{}') || {};
            const now = Date.now();
            Object.keys(o).forEach(function (k) {
                if (!o[k] || (now - o[k].at) > INSTANCE_TTL_MS) delete o[k];
            });
            return o;
        } catch (e) { return {}; }
    }

    function heartbeat() {
        try {
            const o = readInstances();
            o[INSTANCE_ID] = { v: ITP_VERSION, at: Date.now() };
            localStorage.setItem(INSTANCE_KEY, JSON.stringify(o));

            // v2.34: KAZANANI TEK BASINA SEC.
            // Once surum (buyuk olan kazanir), esitlikte instance id'si kucuk
            // olan (yani once yuklenen) kazanir. Boylece ayni surumden iki kopya
            // olsa bile sadece biri yazar; kullanicinin mudahalesi gerekmez.
            let winner = { id: INSTANCE_ID, v: ITP_VERSION };
            Object.keys(o).forEach(function (k) {
                const cand = { id: k, v: o[k].v };
                const dv = verNum(cand.v) - verNum(winner.v);
                if (dv > 0 || (dv === 0 && cand.id < winner.id)) winner = cand;
            });

            const otherVers = Object.keys(o)
                .filter(function (k) { return k !== INSTANCE_ID; })
                .map(function (k) { return o[k].v; })
                .filter(function (v, i, a) { return a.indexOf(v) === i; });

            if (winner.id !== INSTANCE_ID) {
                if (!standDown) {
                    standDown = true;
                    isTracking = false;
                    console.error('[ITP] \u26d4 Bu kopya (v' + ITP_VERSION + ') devre disi \u2014 sayfada ' +
                        'v' + winner.v + ' aktif. Veri bozulmasin diye yazma kapatildi.');
                }
                showDuplicateWarning('Bu kopya (v' + ITP_VERSION + ') durduruldu, v' + winner.v +
                    ' calisiyor. Takip sorunsuz devam ediyor; Tampermonkey\'den fazla kopyayi silebilirsin.');
            } else if (otherVers.length > 0) {
                showDuplicateWarning('Bu sayfada ' + (otherVers.length + 1) + ' kopya var (v' +
                    ITP_VERSION + ' + v' + otherVers.join(', v') + '). Sadece bu kopya yaziyor, ' +
                    'veri bozulmuyor \u2014 ama Tampermonkey\'den fazlalari silmek iyi olur.');
            } else {
                hideDuplicateWarning();
            }
        } catch (e) { }
    }

    function showDuplicateWarning(msg) {
        let el = document.getElementById('itp-dup-warn');
        if (!el) {
            el = document.createElement('div');
            el.id = 'itp-dup-warn';
            el.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;' +
                'background:#8d6e00;color:#fff;font:600 13px/1.4 system-ui,sans-serif;' +
                'padding:10px 16px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.5);';
            document.body.appendChild(el);
        }
        el.textContent = '\u26a0\ufe0f ' + msg;
    }

    function hideDuplicateWarning() {
        const el = document.getElementById('itp-dup-warn');
        if (el) el.remove();
    }

    heartbeat();
    setInterval(heartbeat, 10 * 1000);
    startBgTicker();
    document.addEventListener('click', startKeepAlive, true);
    document.addEventListener('keydown', startKeepAlive, true);

    if (document.readyState === 'complete') init();
    else window.addEventListener('load', init);

})();
